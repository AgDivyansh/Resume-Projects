import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { ToastProvider } from '@/contexts/ToastContext';
import AppShell from '@/components/layout/AppShell';
import RouteGuard from '@/components/RouteGuard';
import LoginPage from '@/pages/LoginPage';
import StudentDashboard from '@/pages/student/StudentDashboard';
import JobsPage from '@/pages/student/JobsPage';
import CompaniesPage from '@/pages/student/CompaniesPage';
import CompanyDetailPage from '@/pages/student/CompanyDetailPage';
import AlumniConnectPage from '@/pages/student/AlumniConnectPage';
import StudentProfilePage from '@/pages/student/StudentProfilePage';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import JobManagementPage from '@/pages/admin/JobManagementPage';
import StudentsManagementPage from '@/pages/admin/StudentsManagementPage';
import AdminCompaniesPage from '@/pages/admin/AdminCompaniesPage';
import AdminAnalyticsPage from '@/pages/admin/AdminAnalyticsPage';
import AdminProfilePage from '@/pages/admin/AdminProfilePage';

function AppContent() {
  return (
    <Routes>
      <Route path="/" element={<LoginPage />} />

      {/* Student Routes */}
      <Route
        path="/dashboard"
        element={
          <RouteGuard allowedRole="student">
            <AppShell>
              <StudentDashboard />
            </AppShell>
          </RouteGuard>
        }
      />
      <Route
        path="/jobs"
        element={
          <RouteGuard allowedRole="student">
            <AppShell>
              <JobsPage />
            </AppShell>
          </RouteGuard>
        }
      />
      <Route
        path="/companies"
        element={
          <RouteGuard allowedRole="student">
            <AppShell>
              <CompaniesPage />
            </AppShell>
          </RouteGuard>
        }
      />
      <Route
        path="/companies/:id"
        element={
          <RouteGuard allowedRole="student">
            <AppShell>
              <CompanyDetailPage />
            </AppShell>
          </RouteGuard>
        }
      />
      <Route
        path="/alumni"
        element={
          <RouteGuard allowedRole="student">
            <AppShell>
              <AlumniConnectPage />
            </AppShell>
          </RouteGuard>
        }
      />
      <Route
        path="/profile"
        element={
          <RouteGuard allowedRole="student">
            <AppShell>
              <StudentProfilePage />
            </AppShell>
          </RouteGuard>
        }
      />

      {/* Admin Routes */}
      <Route
        path="/admin"
        element={
          <RouteGuard allowedRole="admin">
            <AppShell>
              <AdminDashboard />
            </AppShell>
          </RouteGuard>
        }
      />
      <Route
        path="/admin/jobs"
        element={
          <RouteGuard allowedRole="admin">
            <AppShell>
              <JobManagementPage />
            </AppShell>
          </RouteGuard>
        }
      />
      <Route
        path="/admin/students"
        element={
          <RouteGuard allowedRole="admin">
            <AppShell>
              <StudentsManagementPage />
            </AppShell>
          </RouteGuard>
        }
      />
      <Route
        path="/admin/companies"
        element={
          <RouteGuard allowedRole="admin">
            <AppShell>
              <AdminCompaniesPage />
            </AppShell>
          </RouteGuard>
        }
      />
      <Route
        path="/admin/analytics"
        element={
          <RouteGuard allowedRole="admin">
            <AppShell>
              <AdminAnalyticsPage />
            </AppShell>
          </RouteGuard>
        }
      />
      <Route
        path="/admin/profile"
        element={
          <RouteGuard allowedRole="admin">
            <AppShell>
              <AdminProfilePage />
            </AppShell>
          </RouteGuard>
        }
      />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <ToastProvider>
          <AppContent />
        </ToastProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

import { Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

interface RouteGuardProps {
  children: React.ReactNode;
  allowedRole: 'student' | 'admin';
}

export default function RouteGuard({ children, allowedRole }: RouteGuardProps) {
  const { user, isStudent, isAdmin } = useAuth();

  if (!user) {
    return <Navigate to="/" replace />;
  }

  if (allowedRole === 'student' && !isStudent()) {
    return <Navigate to="/admin" replace />;
  }

  if (allowedRole === 'admin' && !isAdmin()) {
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
}

import { useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import MobileNav from './MobileNav';
import TopBar from './TopBar';

const pageTitles: Record<string, string> = {
  '/dashboard': 'Dashboard',
  '/jobs': 'Jobs',
  '/companies': 'Companies',
  '/alumni': 'Alumni Connect',
  '/profile': 'My Profile',
  '/admin': 'Admin Dashboard',
  '/admin/jobs': 'Job Management',
  '/admin/students': 'Students',
  '/admin/companies': 'Companies',
  '/admin/analytics': 'Analytics',
  '/admin/profile': 'Admin Profile',
};

export default function AppShell({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const title = pageTitles[location.pathname] || 'CareerTrack';

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop Sidebar */}
      <Sidebar />

      {/* Main Content Area */}
      <div className="lg:ml-[260px] min-h-screen flex flex-col">
        <TopBar title={title} />
        <main className="flex-1 p-4 lg:p-8 pb-24 lg:pb-8 overflow-x-hidden">
          {children}
        </main>
      </div>

      {/* Mobile Bottom Nav */}
      <MobileNav />
    </div>
  );
}

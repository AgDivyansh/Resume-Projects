import { useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Briefcase,
  Building2,
  Users,
  User,
  GraduationCap,
  BarChart3,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const studentNavItems = [
  { label: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' },
  { label: 'Jobs', icon: Briefcase, path: '/jobs' },
  { label: 'Companies', icon: Building2, path: '/companies' },
  { label: 'Alumni', icon: Users, path: '/alumni' },
  { label: 'Profile', icon: User, path: '/profile' },
];

const adminNavItems = [
  { label: 'Dashboard', icon: LayoutDashboard, path: '/admin' },
  { label: 'Jobs', icon: Briefcase, path: '/admin/jobs' },
  { label: 'Students', icon: GraduationCap, path: '/admin/students' },
  { label: 'Analytics', icon: BarChart3, path: '/admin/analytics' },
  { label: 'Profile', icon: User, path: '/admin/profile' },
];

export default function MobileNav() {
  const location = useLocation();
  const navigate = useNavigate();
  const { isStudent, isAdmin } = useAuth();

  const navItems = isStudent() ? studentNavItems : isAdmin() ? adminNavItems : [];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 h-16 bg-card border-t border-border z-50 flex items-center justify-around safe-area-pb">
      {navItems.map((item) => {
        const isActive = location.pathname === item.path;
        const Icon = item.icon;
        return (
          <button
            key={item.path}
            onClick={() => navigate(item.path)}
            className={`flex flex-col items-center justify-center gap-0.5 w-full h-full transition-colors duration-200 ${
              isActive ? 'text-primary' : 'text-muted-foreground'
            }`}
          >
            <Icon className="w-5 h-5" />
            <span className="text-[10px] font-medium">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  LayoutDashboard,
  Briefcase,
  Building2,
  Users,
  User,
  GraduationCap,
  BarChart3,
  Sun,
  Moon,
  BriefcaseMedical,
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { useState } from 'react';

const studentNavItems = [
  { label: 'Dashboard', icon: LayoutDashboard, path: '/dashboard' },
  { label: 'Jobs', icon: Briefcase, path: '/jobs' },
  { label: 'Companies', icon: Building2, path: '/companies' },
  { label: 'Alumni Connect', icon: Users, path: '/alumni' },
  { label: 'Profile', icon: User, path: '/profile' },
];

const adminNavItems = [
  { label: 'Dashboard', icon: LayoutDashboard, path: '/admin' },
  { label: 'Job Management', icon: Briefcase, path: '/admin/jobs' },
  { label: 'Students', icon: GraduationCap, path: '/admin/students' },
  { label: 'Companies', icon: Building2, path: '/admin/companies' },
  { label: 'Analytics', icon: BarChart3, path: '/admin/analytics' },
  { label: 'Profile', icon: User, path: '/admin/profile' },
];

export default function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout, isStudent, isAdmin } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [collapsed] = useState(false);

  const navItems = isStudent() ? studentNavItems : isAdmin() ? adminNavItems : [];
  const activeIndex = navItems.findIndex(item => location.pathname === item.path);

  return (
    <aside className="hidden lg:flex flex-col w-[260px] h-screen bg-card border-r border-border shadow-nav fixed left-0 top-0 z-40 transition-all duration-200">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-5 h-16 border-b border-border">
        <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
          <BriefcaseMedical className="w-4 h-4 text-primary-foreground" />
        </div>
        <span className="font-display text-lg font-bold text-primary">CareerTrack</span>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 overflow-y-auto">
        <div className="relative flex flex-col gap-1">
          {/* Active indicator */}
          {activeIndex >= 0 && (
            <motion.div
              layoutId="activeNav"
              className="absolute left-0 w-[3px] bg-primary rounded-full"
              style={{
                height: '60%',
                top: `${activeIndex * 44 + (44 * 0.2)}px`,
              }}
              transition={{ type: 'spring', stiffness: 400, damping: 30 }}
            />
          )}
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`
                  flex items-center gap-3 h-11 px-3 rounded-lg text-sm font-medium transition-all duration-200 w-full
                  ${isActive
                    ? 'text-primary bg-primary/10'
                    : 'text-muted-foreground hover:text-foreground hover:bg-primary/5'
                  }
                `}
              >
                <Icon className="w-[18px] h-[18px] flex-shrink-0" />
                {!collapsed && <span>{item.label}</span>}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Dark Mode Toggle */}
      <div className="px-4 py-3 border-t border-border">
        <button
          onClick={toggleTheme}
          className="flex items-center gap-3 w-full h-10 px-3 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-primary/5 transition-all duration-200"
        >
          {theme === 'dark' ? <Sun className="w-[18px] h-[18px]" /> : <Moon className="w-[18px] h-[18px]" />}
          <span>Dark Mode</span>
          <div className={`
            ml-auto w-9 h-5 rounded-full relative transition-colors duration-200
            ${theme === 'dark' ? 'bg-primary' : 'bg-muted'}
          `}>
            <div className={`
              absolute top-0.5 w-4 h-4 rounded-full bg-white shadow-sm transition-transform duration-200
              ${theme === 'dark' ? 'translate-x-4' : 'translate-x-0.5'}
            `} />
          </div>
        </button>
      </div>

      {/* User Profile */}
      <div className="px-4 py-3 border-t border-border">
        <button
          onClick={() => navigate(isStudent() ? '/profile' : '/admin/profile')}
          className="flex items-center gap-3 w-full p-2 rounded-lg hover:bg-primary/5 transition-colors"
        >
          <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold text-sm flex-shrink-0">
            {user?.name?.charAt(0) || 'U'}
          </div>
          <div className="flex-1 min-w-0 text-left">
            <p className="text-sm font-medium truncate">{user?.name || 'User'}</p>
            <span className={`
              inline-block text-[11px] font-medium px-2 py-0.5 rounded mt-0.5
              ${isStudent() ? 'bg-primary/10 text-primary' : 'bg-ct-green/10 text-ct-green'}
            `}>
              {isStudent() ? 'Student' : 'Admin'}
            </span>
          </div>
        </button>
        <button
          onClick={logout}
          className="w-full mt-2 text-xs text-muted-foreground hover:text-foreground transition-colors text-left px-2"
        >
          Sign Out
        </button>
      </div>
    </aside>
  );
}

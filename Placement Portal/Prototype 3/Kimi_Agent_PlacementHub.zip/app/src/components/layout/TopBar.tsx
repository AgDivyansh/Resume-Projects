import { useNavigate } from 'react-router-dom';
import { Search, Bell, Sun, Moon } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';

export default function TopBar({ title }: { title: string }) {
  const navigate = useNavigate();
  const { user, isStudent } = useAuth();
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="sticky top-0 z-30 h-16 flex items-center justify-between px-4 lg:px-8 bg-background/80 backdrop-blur-md border-b border-border/50">
      {/* Left: Title */}
      <div className="flex items-center gap-3">
        <h1 className="font-display text-xl lg:text-2xl font-semibold text-foreground">{title}</h1>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-2">
        {/* Dark mode toggle (mobile only) */}
        <button
          onClick={toggleTheme}
          className="lg:hidden w-10 h-10 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-primary/5 transition-colors"
        >
          {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>

        {/* Search */}
        <button className="w-10 h-10 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-primary/5 transition-colors">
          <Search className="w-5 h-5" />
        </button>

        {/* Notifications */}
        <button className="relative w-10 h-10 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-primary/5 transition-colors">
          <Bell className="w-5 h-5" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-ct-red rounded-full" />
        </button>

        {/* Avatar */}
        <button
          onClick={() => navigate(isStudent() ? '/profile' : '/admin/profile')}
          className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold text-sm hover:bg-primary/20 transition-colors"
        >
          {user?.name?.charAt(0) || 'U'}
        </button>
      </div>
    </header>
  );
}

import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'admin';
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  isStudent: () => boolean;
  isAdmin: () => boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(() => {
    const stored = localStorage.getItem('careertrack_user');
    return stored ? JSON.parse(stored) : null;
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem('careertrack_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('careertrack_user');
    }
  }, [user]);

  const login = useCallback((email: string, password: string): boolean => {
    if (email === 'divyansh@gmail.com' && password === 'student123') {
      const studentUser: User = {
        id: 'st_001',
        name: 'Divyansh Sharma',
        email: 'divyansh@gmail.com',
        role: 'student',
      };
      setUser(studentUser);
      navigate('/dashboard');
      return true;
    }
    if (email === 'divyansh@admin.com' && password === 'admin123') {
      const adminUser: User = {
        id: 'ad_001',
        name: 'Divyansh Sharma',
        email: 'divyansh@admin.com',
        role: 'admin',
      };
      setUser(adminUser);
      navigate('/admin');
      return true;
    }
    return false;
  }, [navigate]);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem('careertrack_user');
    navigate('/');
  }, [navigate]);

  const isStudent = useCallback(() => user?.role === 'student', [user]);
  const isAdmin = useCallback(() => user?.role === 'admin', [user]);

  return (
    <AuthContext.Provider value={{ user, login, logout, isStudent, isAdmin }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}

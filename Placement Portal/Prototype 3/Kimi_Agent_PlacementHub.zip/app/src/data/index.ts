export interface Student {
  id: string;
  name: string;
  rollNumber: string;
  personalEmail: string;
  collegeEmail: string;
  phone: string;
  tenthPercentage: number;
  twelfthPercentage: number;
  cgpa: number;
  branch: string;
  yearOfPassing: number;
  backlogs: number;
  resumeUrl: string;
  role: 'student';
}

export interface Admin {
  id: string;
  name: string;
  email: string;
  phone: string;
  collegeName: string;
  designation: string;
  role: 'admin';
}

export interface JobEligibility {
  minTenth: number;
  minTwelfth: number;
  minCgpa: number;
  maxBacklogs: number;
  branches: string[];
  yearOfPassing: number;
}

export interface InterviewRound {
  name: string;
  type: string;
}

export interface JobPosting {
  id: string;
  companyName: string;
  role: string;
  location: string;
  packageMin: number;
  packageMax: number;
  industry: string;
  description: string;
  deadline: string;
  eligibility: JobEligibility;
  rounds: InterviewRound[];
  status: string;
  postedDate: string;
  applicationsCount: number;
  rating: number;
  reviewCount: number;
}

export interface ApplicationRound {
  name: string;
  status: 'pending' | 'upcoming' | 'in_progress' | 'cleared' | 'rejected';
  date: string | null;
}

export interface StudentApplication {
  id: string;
  jobId: string;
  studentId: string;
  status: 'applied' | 'under_review' | 'shortlisted' | 'rejected' | 'offer_received';
  currentRound: number;
  appliedDate: string;
  rounds: ApplicationRound[];
}

export interface CompanyReview {
  studentName: string;
  rating: number;
  text: string;
  date: string;
}

export interface SelectedStudent {
  name: string;
  role: string;
  package: number;
  year: number;
  avatar: string;
}

export interface Company {
  id: string;
  name: string;
  industry: string;
  avgPackage: number;
  highestPackage: number;
  totalPlaced: number;
  openRoles: number;
  rating: number;
  reviewCount: number;
  historicalData: {
    year: number;
    role: string;
    package: number;
    rounds: number;
    studentsHired: number;
  }[];
  interviewRounds: string[];
  reviews: CompanyReview[];
  selectedStudents: SelectedStudent[];
}

export interface Alumni {
  id: string;
  name: string;
  company: string;
  role: string;
  package: number;
  year: number;
  avatar: string;
  online: boolean;
  callScheduled: boolean;
  callDate?: string;
  callTime?: string;
  callType?: 'voice' | 'video';
  callApproved?: boolean;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  content: string;
  timestamp: string;
}

export interface Notification {
  id: string;
  type: 'shortlist' | 'deadline' | 'new_job' | 'interview';
  message: string;
  time: string;
  read: boolean;
}

// Logged-in Student
export const currentStudent: Student = {
  id: 'st_001',
  name: 'Divyansh Sharma',
  rollNumber: '2021CS045',
  personalEmail: 'divyansh@gmail.com',
  collegeEmail: 'divyansh@college.edu',
  phone: '+91 98765 43210',
  tenthPercentage: 82,
  twelfthPercentage: 79,
  cgpa: 8.2,
  branch: 'CSE',
  yearOfPassing: 2025,
  backlogs: 0,
  resumeUrl: '/resume.pdf',
  role: 'student',
};

// Logged-in Admin
export const currentAdmin: Admin = {
  id: 'ad_001',
  name: 'Divyansh Sharma',
  email: 'divyansh@admin.com',
  phone: '+91 98765 43211',
  collegeName: 'ABC Engineering College',
  designation: 'Placement Coordinator',
  role: 'admin',
};

// Job Postings
export const jobPostings: JobPosting[] = [
  {
    id: 'job_001',
    companyName: 'Google',
    role: 'Software Development Engineer',
    location: 'Bangalore, Hyderabad',
    packageMin: 18,
    packageMax: 28,
    industry: 'MNC / Tech',
    description: 'Design, develop, test, deploy, maintain and improve software solutions. Work on large-scale distributed systems serving billions of users.',
    deadline: '2025-02-15',
    eligibility: { minTenth: 85, minTwelfth: 80, minCgpa: 8.0, maxBacklogs: 0, branches: ['CSE', 'IT'], yearOfPassing: 2025 },
    rounds: [{ name: 'Online Assessment', type: 'Aptitude' }, { name: 'Technical Interview 1', type: 'Technical' }, { name: 'Technical Interview 2', type: 'Technical' }, { name: 'HR Interview', type: 'HR' }],
    status: 'active',
    postedDate: '2025-01-20',
    applicationsCount: 156,
    rating: 4.6,
    reviewCount: 42,
  },
  {
    id: 'job_002',
    companyName: 'Microsoft',
    role: 'Software Engineer',
    location: 'Hyderabad, Noida',
    packageMin: 15,
    packageMax: 22,
    industry: 'MNC / Tech',
    description: 'Build cloud services and developer tools. Work with Azure, .NET, and cutting-edge web technologies.',
    deadline: '2025-02-20',
    eligibility: { minTenth: 80, minTwelfth: 75, minCgpa: 7.5, maxBacklogs: 0, branches: ['CSE', 'IT', 'ECE'], yearOfPassing: 2025 },
    rounds: [{ name: 'Online Coding', type: 'Coding' }, { name: 'Technical Interview', type: 'Technical' }, { name: 'AA Interview', type: 'HR' }],
    status: 'active',
    postedDate: '2025-01-22',
    applicationsCount: 203,
    rating: 4.5,
    reviewCount: 38,
  },
  {
    id: 'job_003',
    companyName: 'Amazon',
    role: 'SDE - I',
    location: 'Bangalore, Chennai, Delhi',
    packageMin: 16,
    packageMax: 24,
    industry: 'MNC / Tech',
    description: 'Develop scalable solutions for Amazon\'s e-commerce platform. Work on high-availability distributed systems.',
    deadline: '2025-02-10',
    eligibility: { minTenth: 85, minTwelfth: 80, minCgpa: 8.5, maxBacklogs: 0, branches: ['CSE', 'IT'], yearOfPassing: 2025 },
    rounds: [{ name: 'Online Assessment', type: 'Aptitude' }, { name: 'Coding Interview', type: 'Coding' }, { name: 'System Design', type: 'Technical' }, { name: 'Bar Raiser', type: 'HR' }],
    status: 'active',
    postedDate: '2025-01-18',
    applicationsCount: 189,
    rating: 4.3,
    reviewCount: 56,
  },
  {
    id: 'job_004',
    companyName: 'Flipkart',
    role: 'Software Development Engineer',
    location: 'Bangalore',
    packageMin: 14,
    packageMax: 20,
    industry: 'Startup / E-commerce',
    description: 'Build next-gen e-commerce experiences. Work with microservices, React, and cloud-native technologies.',
    deadline: '2025-02-25',
    eligibility: { minTenth: 75, minTwelfth: 70, minCgpa: 7.0, maxBacklogs: 0, branches: ['CSE', 'IT'], yearOfPassing: 2025 },
    rounds: [{ name: 'Online Coding', type: 'Coding' }, { name: 'Machine Coding', type: 'Coding' }, { name: 'Technical Interview', type: 'Technical' }, { name: 'HR Interview', type: 'HR' }],
    status: 'active',
    postedDate: '2025-01-25',
    applicationsCount: 134,
    rating: 4.4,
    reviewCount: 29,
  },
  {
    id: 'job_005',
    companyName: 'Paytm',
    role: 'Backend Engineer',
    location: 'Noida',
    packageMin: 12,
    packageMax: 18,
    industry: 'Fintech',
    description: 'Build payment systems and financial products. Work with Java, Spring Boot, and distributed databases.',
    deadline: '2025-03-01',
    eligibility: { minTenth: 70, minTwelfth: 65, minCgpa: 6.5, maxBacklogs: 1, branches: ['CSE', 'IT'], yearOfPassing: 2025 },
    rounds: [{ name: 'Online Test', type: 'Aptitude' }, { name: 'Technical Round 1', type: 'Technical' }, { name: 'Technical Round 2', type: 'Technical' }, { name: 'HR Round', type: 'HR' }],
    status: 'active',
    postedDate: '2025-01-28',
    applicationsCount: 98,
    rating: 4.1,
    reviewCount: 22,
  },
  {
    id: 'job_006',
    companyName: 'Infosys',
    role: 'Systems Engineer',
    location: 'Multiple Locations',
    packageMin: 3.6,
    packageMax: 5.0,
    industry: 'MNC / IT Services',
    description: 'Entry-level software engineering role. Training provided in Java, .NET, or Python.',
    deadline: '2025-03-15',
    eligibility: { minTenth: 60, minTwelfth: 60, minCgpa: 6.0, maxBacklogs: 2, branches: ['CSE', 'IT', 'ECE', 'EEE', 'MECH', 'CIVIL'], yearOfPassing: 2025 },
    rounds: [{ name: 'Online Test', type: 'Aptitude' }, { name: 'Technical Interview', type: 'Technical' }, { name: 'HR Interview', type: 'HR' }],
    status: 'active',
    postedDate: '2025-02-01',
    applicationsCount: 456,
    rating: 3.8,
    reviewCount: 89,
  },
  {
    id: 'job_007',
    companyName: 'TCS',
    role: 'Ninja Developer',
    location: 'Pan India',
    packageMin: 3.36,
    packageMax: 4.5,
    industry: 'MNC / IT Services',
    description: 'Software development role for freshers. Work on enterprise applications for global clients.',
    deadline: '2025-03-20',
    eligibility: { minTenth: 60, minTwelfth: 60, minCgpa: 6.0, maxBacklogs: 2, branches: ['CSE', 'IT', 'ECE', 'EEE', 'MECH', 'CIVIL'], yearOfPassing: 2025 },
    rounds: [{ name: 'NQT', type: 'Aptitude' }, { name: 'Technical Interview', type: 'Technical' }, { name: 'Manager Interview', type: 'HR' }],
    status: 'active',
    postedDate: '2025-02-03',
    applicationsCount: 523,
    rating: 3.7,
    reviewCount: 112,
  },
  {
    id: 'job_008',
    companyName: 'Zerodha',
    role: 'Software Engineer',
    location: 'Bangalore',
    packageMin: 20,
    packageMax: 30,
    industry: 'Fintech / Startup',
    description: 'Work on India\'s largest stock brokerage platform. Build trading systems and financial tools.',
    deadline: '2025-02-28',
    eligibility: { minTenth: 85, minTwelfth: 85, minCgpa: 8.5, maxBacklogs: 0, branches: ['CSE', 'IT'], yearOfPassing: 2025 },
    rounds: [{ name: 'Coding Challenge', type: 'Coding' }, { name: 'System Design', type: 'Technical' }, { name: 'Culture Fit', type: 'HR' }],
    status: 'active',
    postedDate: '2025-01-30',
    applicationsCount: 87,
    rating: 4.7,
    reviewCount: 15,
  },
  {
    id: 'job_009',
    companyName: "BYJU'S",
    role: 'Product Analyst',
    location: 'Bangalore',
    packageMin: 8,
    packageMax: 12,
    industry: 'EdTech',
    description: 'Analyze user behavior and product metrics. Work with data to drive product decisions.',
    deadline: '2025-03-05',
    eligibility: { minTenth: 70, minTwelfth: 70, minCgpa: 7.0, maxBacklogs: 1, branches: ['CSE', 'IT', 'ECE'], yearOfPassing: 2025 },
    rounds: [{ name: 'Aptitude Test', type: 'Aptitude' }, { name: 'Case Study', type: 'Technical' }, { name: 'Product Interview', type: 'Technical' }, { name: 'HR Interview', type: 'HR' }],
    status: 'active',
    postedDate: '2025-02-05',
    applicationsCount: 67,
    rating: 3.5,
    reviewCount: 31,
  },
  {
    id: 'job_010',
    companyName: 'Goldman Sachs',
    role: 'Software Engineer - Analyst',
    location: 'Bangalore, Hyderabad',
    packageMin: 22,
    packageMax: 32,
    industry: 'Finance / Investment Banking',
    description: 'Build trading platforms and risk management systems. Work with cutting-edge financial technology.',
    deadline: '2025-02-18',
    eligibility: { minTenth: 90, minTwelfth: 90, minCgpa: 8.5, maxBacklogs: 0, branches: ['CSE', 'IT'], yearOfPassing: 2025 },
    rounds: [{ name: 'HackerRank', type: 'Coding' }, { name: 'Technical Interview 1', type: 'Technical' }, { name: 'Technical Interview 2', type: 'Technical' }, { name: 'Behavioral', type: 'HR' }],
    status: 'active',
    postedDate: '2025-01-15',
    applicationsCount: 112,
    rating: 4.5,
    reviewCount: 19,
  },
];

// Student Applications
export const studentApplications: StudentApplication[] = [
  { id: 'app_001', jobId: 'job_001', studentId: 'st_001', status: 'shortlisted', currentRound: 2, appliedDate: '2025-01-21', rounds: [{ name: 'Online Assessment', status: 'cleared', date: '2025-01-25' }, { name: 'Technical Interview 1', status: 'in_progress', date: null }] },
  { id: 'app_002', jobId: 'job_002', studentId: 'st_001', status: 'applied', currentRound: 0, appliedDate: '2025-01-23', rounds: [{ name: 'Online Coding', status: 'pending', date: null }] },
  { id: 'app_003', jobId: 'job_004', studentId: 'st_001', status: 'rejected', currentRound: 1, appliedDate: '2025-01-26', rounds: [{ name: 'Online Coding', status: 'cleared', date: '2025-01-28' }, { name: 'Machine Coding', status: 'rejected', date: '2025-01-30' }] },
  { id: 'app_004', jobId: 'job_006', studentId: 'st_001', status: 'applied', currentRound: 0, appliedDate: '2025-02-02', rounds: [{ name: 'Online Test', status: 'pending', date: null }] },
  { id: 'app_005', jobId: 'job_007', studentId: 'st_001', status: 'applied', currentRound: 0, appliedDate: '2025-02-04', rounds: [{ name: 'NQT', status: 'upcoming', date: '2025-02-15' }] },
];

// Companies
export const companies: Company[] = [
  {
    id: 'comp_001',
    name: 'Google',
    industry: 'MNC / Tech',
    avgPackage: 22,
    highestPackage: 45,
    totalPlaced: 24,
    openRoles: 3,
    rating: 4.6,
    reviewCount: 42,
    historicalData: [
      { year: 2024, role: 'SDE', package: 22, rounds: 4, studentsHired: 8 },
      { year: 2024, role: 'Data Engineer', package: 20, rounds: 4, studentsHired: 4 },
      { year: 2023, role: 'SDE', package: 20, rounds: 4, studentsHired: 6 },
      { year: 2023, role: 'UX Engineer', package: 18, rounds: 3, studentsHired: 3 },
      { year: 2022, role: 'SDE', package: 18, rounds: 4, studentsHired: 5 },
    ],
    interviewRounds: ['Online Assessment', 'Technical Interview 1', 'Technical Interview 2', 'HR Interview'],
    reviews: [
      { studentName: 'Rahul Verma', rating: 5, text: 'Amazing experience! The interviewers were very friendly. Focus on DSA and system design.', date: '2024-08-15' },
      { studentName: 'Priya Singh', rating: 4, text: 'Tough coding rounds but fair process. Make sure to practice LeetCode hard problems.', date: '2024-07-20' },
    ],
    selectedStudents: [
      { name: 'Rahul Verma', role: 'SDE', package: 22, year: 2024, avatar: 'RV' },
      { name: 'Priya Singh', role: 'Data Engineer', package: 20, year: 2024, avatar: 'PS' },
      { name: 'Amit Kumar', role: 'SDE', package: 20, year: 2023, avatar: 'AK' },
    ],
  },
  {
    id: 'comp_002',
    name: 'Microsoft',
    industry: 'MNC / Tech',
    avgPackage: 18,
    highestPackage: 25,
    totalPlaced: 32,
    openRoles: 4,
    rating: 4.5,
    reviewCount: 38,
    historicalData: [
      { year: 2024, role: 'Software Engineer', package: 18, rounds: 3, studentsHired: 12 },
      { year: 2023, role: 'Software Engineer', package: 16, rounds: 3, studentsHired: 10 },
      { year: 2022, role: 'Software Engineer', package: 15, rounds: 3, studentsHired: 10 },
    ],
    interviewRounds: ['Online Coding', 'Technical Interview', 'AA Interview'],
    reviews: [
      { studentName: 'Neha Gupta', rating: 5, text: 'Great company culture! The AA round is unique, be prepared with your stories.', date: '2024-09-01' },
    ],
    selectedStudents: [
      { name: 'Neha Gupta', role: 'Software Engineer', package: 18, year: 2024, avatar: 'NG' },
      { name: 'Suresh Patel', role: 'Software Engineer', package: 18, year: 2024, avatar: 'SP' },
    ],
  },
  {
    id: 'comp_003',
    name: 'Amazon',
    industry: 'MNC / Tech',
    avgPackage: 18,
    highestPackage: 35,
    totalPlaced: 28,
    openRoles: 5,
    rating: 4.3,
    reviewCount: 56,
    historicalData: [
      { year: 2024, role: 'SDE - I', package: 18, rounds: 4, studentsHired: 10 },
      { year: 2023, role: 'SDE - I', package: 16, rounds: 4, studentsHired: 8 },
      { year: 2022, role: 'SDE - I', package: 15, rounds: 4, studentsHired: 10 },
    ],
    interviewRounds: ['Online Assessment', 'Coding Interview', 'System Design', 'Bar Raiser'],
    reviews: [
      { studentName: 'Ananya Reddy', rating: 4, text: 'Very structured process. The bar raiser round is challenging but fair.', date: '2024-08-20' },
    ],
    selectedStudents: [
      { name: 'Ananya Reddy', role: 'SDE - I', package: 18, year: 2024, avatar: 'AR' },
    ],
  },
  {
    id: 'comp_004',
    name: 'Flipkart',
    industry: 'Startup / E-commerce',
    avgPackage: 16,
    highestPackage: 22,
    totalPlaced: 18,
    openRoles: 3,
    rating: 4.4,
    reviewCount: 29,
    historicalData: [
      { year: 2024, role: 'SDE', package: 16, rounds: 4, studentsHired: 6 },
      { year: 2023, role: 'SDE', package: 14, rounds: 4, studentsHired: 5 },
      { year: 2022, role: 'SDE', package: 12, rounds: 4, studentsHired: 7 },
    ],
    interviewRounds: ['Online Coding', 'Machine Coding', 'Technical Interview', 'HR Interview'],
    reviews: [
      { studentName: 'Vikram Joshi', rating: 5, text: 'Amazing work culture! Machine coding round is the most important one.', date: '2024-07-15' },
    ],
    selectedStudents: [
      { name: 'Vikram Joshi', role: 'SDE', package: 16, year: 2023, avatar: 'VJ' },
    ],
  },
];

// Alumni
export const alumni: Alumni[] = [
  { id: 'alum_001', name: 'Rahul Verma', company: 'Google', role: 'SDE', package: 22, year: 2024, avatar: 'RV', online: true, callScheduled: true, callDate: '2025-02-10', callTime: '14:00', callType: 'voice', callApproved: true },
  { id: 'alum_002', name: 'Priya Singh', company: 'Microsoft', role: 'Data Engineer', package: 20, year: 2024, avatar: 'PS', online: false, callScheduled: false },
  { id: 'alum_003', name: 'Amit Kumar', company: 'Google', role: 'SDE', package: 20, year: 2023, avatar: 'AK', online: true, callScheduled: true, callDate: '2025-02-12', callTime: '16:30', callType: 'video', callApproved: false },
  { id: 'alum_004', name: 'Neha Gupta', company: 'Microsoft', role: 'Software Engineer', package: 18, year: 2024, avatar: 'NG', online: true, callScheduled: false },
  { id: 'alum_005', name: 'Suresh Patel', company: 'Microsoft', role: 'Software Engineer', package: 18, year: 2024, avatar: 'SP', online: false, callScheduled: false },
  { id: 'alum_006', name: 'Ananya Reddy', company: 'Amazon', role: 'SDE', package: 18, year: 2024, avatar: 'AR', online: true, callScheduled: false },
  { id: 'alum_007', name: 'Vikram Joshi', company: 'Flipkart', role: 'SDE', package: 16, year: 2023, avatar: 'VJ', online: false, callScheduled: false },
  { id: 'alum_008', name: 'Deepika Shah', company: 'Goldman Sachs', role: 'Analyst', package: 25, year: 2024, avatar: 'DS', online: true, callScheduled: false },
];

// Chat Messages
export const chatMessages: ChatMessage[] = [
  { id: 'msg_001', senderId: 'alum_001', content: 'Hi Divyansh! How can I help you today?', timestamp: '2025-02-05T10:00:00Z' },
  { id: 'msg_002', senderId: 'st_001', content: 'Hey Rahul! I\'m preparing for Google interviews. Any tips?', timestamp: '2025-02-05T10:05:00Z' },
  { id: 'msg_003', senderId: 'alum_001', content: 'Sure! Focus on LeetCode mediums and hards. Their interviews heavily test problem-solving approach.', timestamp: '2025-02-05T10:08:00Z' },
  { id: 'msg_004', senderId: 'alum_001', content: 'Also, practice system design — they ask at least one design question in the later rounds.', timestamp: '2025-02-05T10:09:00Z' },
  { id: 'msg_005', senderId: 'st_001', content: 'Thanks! How many rounds are there typically?', timestamp: '2025-02-05T10:15:00Z' },
  { id: 'msg_006', senderId: 'alum_001', content: '4 rounds total: 1 online assessment, 2 technical interviews, and 1 HR round. The technical rounds are the toughest.', timestamp: '2025-02-05T10:20:00Z' },
];

// Notifications
export const notifications: Notification[] = [
  { id: 'notif_001', type: 'shortlist', message: 'Google shortlisted you for Round 2', time: '2 hours ago', read: false },
  { id: 'notif_002', type: 'deadline', message: 'Microsoft application deadline is tomorrow', time: '5 hours ago', read: false },
  { id: 'notif_003', type: 'new_job', message: 'Amazon posted a new SDE role - 16-24 LPA', time: '1 day ago', read: true },
  { id: 'notif_004', type: 'interview', message: 'Infosys interview scheduled for Friday, Feb 14', time: '2 days ago', read: true },
];

// Weekly activity data
export const weeklyActivityData = [
  { day: 'Mon', count: 2 },
  { day: 'Tue', count: 1 },
  { day: 'Wed', count: 3 },
  { day: 'Thu', count: 0 },
  { day: 'Fri', count: 4 },
  { day: 'Sat', count: 1 },
  { day: 'Sun', count: 2 },
];

// Helper function to check eligibility
export function checkEligibility(student: Student, job: JobPosting): boolean {
  if (student.tenthPercentage < job.eligibility.minTenth) return false;
  if (student.twelfthPercentage < job.eligibility.minTwelfth) return false;
  if (student.cgpa < job.eligibility.minCgpa) return false;
  if (student.backlogs > job.eligibility.maxBacklogs) return false;
  if (!job.eligibility.branches.includes(student.branch)) return false;
  if (student.yearOfPassing !== job.eligibility.yearOfPassing) return false;
  return true;
}

// Admin stats data
export const adminStatsData = {
  totalStudents: 2450,
  activeJobs: 24,
  totalPlacements: 186,
  companiesVisited: 48,
};

// Placement trend data
export const placementTrendData = [
  { month: 'Aug', count: 12 },
  { month: 'Sep', count: 25 },
  { month: 'Oct', count: 38 },
  { month: 'Nov', count: 45 },
  { month: 'Dec', count: 32 },
  { month: 'Jan', count: 18 },
  { month: 'Feb', count: 16 },
];

// Company placements data
export const companyPlacementsData = [
  { company: 'Infosys', count: 45 },
  { company: 'TCS', count: 38 },
  { company: 'Wipro', count: 22 },
  { company: 'Accenture', count: 18 },
  { company: 'Microsoft', count: 12 },
  { company: 'Amazon', count: 10 },
  { company: 'Google', count: 8 },
  { company: 'Flipkart', count: 6 },
];

// Branch distribution data
export const branchDistributionData = [
  { name: 'CSE', value: 42 },
  { name: 'IT', value: 25 },
  { name: 'ECE', value: 18 },
  { name: 'EEE', value: 8 },
  { name: 'MECH', value: 4 },
  { name: 'CIVIL', value: 3 },
];

// Package distribution data
export const packageDistributionData = [
  { range: '0-5 LPA', count: 85 },
  { range: '5-10 LPA', count: 52 },
  { range: '10-15 LPA', count: 28 },
  { range: '15-20 LPA', count: 15 },
  { range: '20+ LPA', count: 6 },
];

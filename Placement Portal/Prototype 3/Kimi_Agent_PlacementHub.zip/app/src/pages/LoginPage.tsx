import { useState } from 'react';
import { motion } from 'framer-motion';
import { Briefcase, Mail, Lock, Eye, EyeOff, GraduationCap, ShieldCheck } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/contexts/ToastContext';

type UserRole = 'student' | 'admin';

export default function LoginPage() {
  const { login } = useAuth();
  const { addToast } = useToast();
  const [role, setRole] = useState<UserRole>('student');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const [isLoading, setIsLoading] = useState(false);

  const validate = () => {
    const newErrors: { email?: string; password?: string } = {};
    if (!email) newErrors.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(email)) newErrors.email = 'Invalid email format';
    if (!password) newErrors.password = 'Password is required';
    else if (password.length < 6) newErrors.password = 'Password must be at least 6 characters';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    const success = login(email, password);
    if (!success) {
      addToast('error', 'Invalid credentials. Please try again.');
    }
    setIsLoading(false);
  };

  const fillDemoCredentials = (type: UserRole) => {
    if (type === 'student') {
      setEmail('divyansh@gmail.com');
      setPassword('student123');
    } else {
      setEmail('divyansh@admin.com');
      setPassword('admin123');
    }
    setRole(type);
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Hero */}
      <div className="hidden lg:flex lg:w-[55%] relative overflow-hidden bg-gradient-to-br from-primary/20 via-ct-primary-light to-teal-100 dark:from-primary/30 dark:via-primary/10 dark:to-teal-900/20">
        {/* Animated mesh blobs */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute w-[500px] h-[500px] rounded-full bg-primary/30 blur-[100px] -top-20 -left-20 animate-mesh-1" />
          <div className="absolute w-[400px] h-[400px] rounded-full bg-teal-400/30 blur-[80px] top-1/3 right-0 animate-mesh-2" />
          <div className="absolute w-[450px] h-[450px] rounded-full bg-blue-400/20 blur-[90px] bottom-0 left-1/4 animate-mesh-3" />
        </div>

        {/* Content */}
        <div className="relative z-10 flex flex-col justify-center px-16 py-12">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h1 className="font-display text-5xl font-bold text-white mb-4 drop-shadow-lg">
              Your Career Journey,<br />Organized
            </h1>
            <p className="text-lg text-white/80 mb-10 max-w-md">
              Track applications, connect with alumni, and land your dream job — all in one place.
            </p>
          </motion.div>

          {/* Floating illustration elements */}
          <div className="relative h-64">
            <motion.div
              className="absolute left-0 top-0 bg-white/90 dark:bg-card/90 rounded-2xl shadow-lg p-4 w-48"
              animate={{ y: [-4, 4, -4] }}
              transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
            >
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-lg bg-ct-green/20 flex items-center justify-center">
                  <Briefcase className="w-4 h-4 text-ct-green" />
                </div>
                <span className="text-sm font-medium">Google Applied</span>
              </div>
              <div className="h-2 bg-ct-green rounded-full w-3/4" />
            </motion.div>

            <motion.div
              className="absolute right-8 top-8 bg-white/90 dark:bg-card/90 rounded-2xl shadow-lg p-4 w-44"
              animate={{ y: [4, -4, 4] }}
              transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                  <GraduationCap className="w-4 h-4 text-primary" />
                </div>
                <span className="text-sm font-medium">12 Eligible</span>
              </div>
              <div className="flex gap-1">
                {[1, 2, 3].map(i => (
                  <div key={i} className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-[10px] font-bold text-primary">
                    {String.fromCharCode(64 + i)}
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              className="absolute left-16 bottom-0 bg-white/90 dark:bg-card/90 rounded-2xl shadow-lg p-4 w-40"
              animate={{ y: [-6, 2, -6] }}
              transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
            >
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-ct-secondary/20 flex items-center justify-center text-ct-secondary font-bold text-sm">
                  4.6
                </div>
                <div>
                  <div className="text-sm font-medium">Google</div>
                  <div className="text-xs text-muted-foreground">42 Reviews</div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Floating stat pills */}
          <motion.div
            className="flex gap-3 mt-8"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            {['150+ Companies', '2,500+ Placements', '500+ Alumni'].map((stat, i) => (
              <motion.span
                key={stat}
                className="bg-white/80 dark:bg-card/80 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium shadow-sm"
                animate={{ y: [-2, 2, -2] }}
                transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut', delay: i * 0.5 }}
              >
                {stat}
              </motion.span>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12 bg-background">
        <motion.div
          initial={{ x: 40, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="w-full max-w-[420px]"
        >
          {/* Logo */}
          <div className="flex items-center justify-center gap-2.5 mb-8">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
              <Briefcase className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-display text-2xl font-bold text-primary">CareerTrack</span>
          </div>

          <div className="bg-card rounded-2xl shadow-card p-6 lg:p-10">
            <h2 className="font-display text-2xl font-bold text-center mb-1">Welcome back!</h2>
            <p className="text-muted-foreground text-center text-sm mb-6">Sign in to your account</p>

            {/* Role Selector */}
            <div className="flex gap-2 p-1 bg-muted rounded-xl mb-6">
              <button
                type="button"
                onClick={() => setRole('student')}
                className={`flex-1 flex items-center justify-center gap-2 h-11 rounded-lg text-sm font-medium transition-all duration-200 ${
                  role === 'student'
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <GraduationCap className="w-4 h-4" />
                Student
              </button>
              <button
                type="button"
                onClick={() => setRole('admin')}
                className={`flex-1 flex items-center justify-center gap-2 h-11 rounded-lg text-sm font-medium transition-all duration-200 ${
                  role === 'admin'
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                Admin
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Email */}
              <div>
                <label className="block text-sm font-medium mb-1.5">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => { setEmail(e.target.value); setErrors(prev => ({ ...prev, email: undefined })); }}
                    placeholder="you@example.com"
                    className={`w-full h-11 pl-10 pr-4 rounded-xl border bg-background text-sm transition-all duration-200 focus:outline-none focus:ring-[3px] focus:ring-primary/15 ${
                      errors.email ? 'border-ct-red' : 'border-border focus:border-primary'
                    }`}
                  />
                </div>
                {errors.email && (
                  <motion.p
                    initial={{ y: -4, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="text-ct-red text-xs mt-1"
                  >
                    {errors.email}
                  </motion.p>
                )}
              </div>

              {/* Password */}
              <div>
                <label className="block text-sm font-medium mb-1.5">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => { setPassword(e.target.value); setErrors(prev => ({ ...prev, password: undefined })); }}
                    placeholder="Enter password"
                    className={`w-full h-11 pl-10 pr-10 rounded-xl border bg-background text-sm transition-all duration-200 focus:outline-none focus:ring-[3px] focus:ring-primary/15 ${
                      errors.password ? 'border-ct-red' : 'border-border focus:border-primary'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
                {errors.password && (
                  <motion.p
                    initial={{ y: -4, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="text-ct-red text-xs mt-1"
                  >
                    {errors.password}
                  </motion.p>
                )}
              </div>

              {/* Forgot Password */}
              <div className="text-right">
                <button type="button" className="text-xs text-primary hover:underline">
                  Forgot Password?
                </button>
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full h-11 bg-primary text-primary-foreground rounded-xl font-medium text-sm hover:bg-ct-primary-hover hover:-translate-y-px active:scale-[0.98] transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  'Sign In'
                )}
              </button>
            </form>

            {/* Divider */}
            <div className="flex items-center gap-3 my-6">
              <div className="flex-1 h-px bg-border" />
              <span className="text-xs text-muted-foreground">or continue with</span>
              <div className="flex-1 h-px bg-border" />
            </div>

            {/* Demo Login Buttons */}
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => fillDemoCredentials('student')}
                className="h-10 rounded-xl border border-border text-sm font-medium text-muted-foreground hover:border-primary hover:text-primary hover:bg-primary/5 transition-all duration-200"
              >
                Demo Student
              </button>
              <button
                type="button"
                onClick={() => fillDemoCredentials('admin')}
                className="h-10 rounded-xl border border-border text-sm font-medium text-muted-foreground hover:border-primary hover:text-primary hover:bg-primary/5 transition-all duration-200"
              >
                Demo Admin
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search } from 'lucide-react';
import { companies } from '@/data';
import StarRating from '@/components/ui/StarRating';

const cardVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.4, ease: 'easeOut' as const },
  }),
};

export default function AdminCompaniesPage() {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCompanies = companies.filter(c =>
    !searchQuery ||
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.industry.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <motion.div
        variants={cardVariants}
        initial="hidden"
        animate="visible"
        className="relative"
      >
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input
          type="text"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder="Search companies..."
          className="w-full h-12 pl-12 pr-4 rounded-2xl border border-border bg-card shadow-card text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
        />
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {filteredCompanies.map((company, i) => (
          <motion.div
            key={company.id}
            custom={i}
            variants={cardVariants}
            initial="hidden"
            animate="visible"
            className="bg-card rounded-2xl shadow-card p-6 hover:shadow-card-hover transition-shadow"
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary font-semibold text-xl flex-shrink-0">
                {company.name.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-lg">{company.name}</h3>
                <span className="inline-block bg-primary/10 text-primary px-2.5 py-0.5 rounded-md text-xs font-medium mt-1">
                  {company.industry}
                </span>
                <div className="flex items-center gap-2 mt-2">
                  <StarRating rating={company.rating} size={14} />
                  <span className="text-sm font-medium">{company.rating}</span>
                  <span className="text-xs text-muted-foreground">({company.reviewCount} reviews)</span>
                </div>
                <div className="grid grid-cols-3 gap-2 mt-4">
                  <div className="text-center p-2 bg-muted rounded-lg">
                    <p className="font-semibold text-sm">{company.avgPackage} LPA</p>
                    <p className="text-[10px] text-muted-foreground">Avg</p>
                  </div>
                  <div className="text-center p-2 bg-muted rounded-lg">
                    <p className="font-semibold text-sm">{company.totalPlaced}</p>
                    <p className="text-[10px] text-muted-foreground">Placed</p>
                  </div>
                  <div className="text-center p-2 bg-muted rounded-lg">
                    <p className="font-semibold text-sm">{company.openRoles}</p>
                    <p className="text-[10px] text-muted-foreground">Open</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

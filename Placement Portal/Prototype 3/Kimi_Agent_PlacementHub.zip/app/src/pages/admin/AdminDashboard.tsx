import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Users,
  Briefcase,
  CheckCircle,
  Building2,
  Plus,
  Upload,
  FileBarChart,
  ArrowRight,
  Pencil,
  Trash2,
} from 'lucide-react';
import {
  jobPostings,
  adminStatsData,
} from '@/data';
import { useToast } from '@/contexts/ToastContext';
import Modal from '@/components/ui/Modal';
import { useState } from 'react';

const cardVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.4, ease: 'easeOut' as const },
  }),
};

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { addToast } = useToast();
  const [deleteJobId, setDeleteJobId] = useState<string | null>(null);

  const recentJobs = jobPostings.slice(0, 5);

  const stats = [
    { label: 'Total Students', value: adminStatsData.totalStudents, change: '+120 this month', icon: Users, iconColor: 'text-primary', iconBg: 'bg-primary/10' },
    { label: 'Active Jobs', value: adminStatsData.activeJobs, change: '+3 this week', icon: Briefcase, iconColor: 'text-ct-orange', iconBg: 'bg-ct-orange/10' },
    { label: 'Total Placements', value: adminStatsData.totalPlacements, change: '+42 this month', icon: CheckCircle, iconColor: 'text-ct-green', iconBg: 'bg-ct-green/10' },
    { label: 'Companies Visited', value: adminStatsData.companiesVisited, change: '+5 this semester', icon: Building2, iconColor: 'text-ct-secondary', iconBg: 'bg-ct-secondary/10' },
  ];

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            custom={i}
            variants={cardVariants}
            initial="hidden"
            animate="visible"
            className="bg-card rounded-2xl shadow-card p-6 hover:shadow-card-hover transition-shadow"
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`w-10 h-10 rounded-xl ${stat.iconBg} flex items-center justify-center`}>
                <stat.icon className={`w-5 h-5 ${stat.iconColor}`} />
              </div>
              <span className="text-xs text-ct-green font-medium">{stat.change}</span>
            </div>
            <p className="text-muted-foreground text-sm">{stat.label}</p>
            <p className="font-display text-3xl font-bold mt-1">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Quick Actions */}
      <motion.div
        custom={4}
        variants={cardVariants}
        initial="hidden"
        animate="visible"
        className="flex gap-3 overflow-x-auto pb-1"
      >
        <button
          onClick={() => navigate('/admin/jobs')}
          className="inline-flex items-center gap-2 px-5 h-11 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-ct-primary-hover transition-colors flex-shrink-0"
        >
          <Plus className="w-4 h-4" /> Post New Job
        </button>
        <button className="inline-flex items-center gap-2 px-5 h-11 border border-border rounded-xl text-sm font-medium text-muted-foreground hover:text-foreground hover:border-primary transition-colors flex-shrink-0">
          <Upload className="w-4 h-4" /> Upload Student Data
        </button>
        <button className="inline-flex items-center gap-2 px-5 h-11 border border-border rounded-xl text-sm font-medium text-muted-foreground hover:text-foreground hover:border-primary transition-colors flex-shrink-0">
          <FileBarChart className="w-4 h-4" /> Generate Report
        </button>
      </motion.div>

      {/* Recent Job Postings */}
      <motion.div
        custom={5}
        variants={cardVariants}
        initial="hidden"
        animate="visible"
        className="bg-card rounded-2xl shadow-card p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xl font-semibold">Recent Job Postings</h3>
          <button
            onClick={() => navigate('/admin/jobs')}
            className="text-sm text-primary hover:underline flex items-center gap-1"
          >
            View All <ArrowRight className="w-4 h-4" />
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-muted-foreground text-left border-b border-border">
                <th className="pb-3 font-medium">Company</th>
                <th className="pb-3 font-medium">Role</th>
                <th className="pb-3 font-medium">Deadline</th>
                <th className="pb-3 font-medium">Applications</th>
                <th className="pb-3 font-medium">Status</th>
                <th className="pb-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {recentJobs.map(job => (
                <tr key={job.id} className="border-b border-border/50 hover:bg-primary/5 transition-colors">
                  <td className="py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-semibold text-xs">
                        {job.companyName.charAt(0)}
                      </div>
                      <span className="font-medium">{job.companyName}</span>
                    </div>
                  </td>
                  <td className="py-3">{job.role}</td>
                  <td className="py-3 text-muted-foreground">{job.deadline}</td>
                  <td className="py-3">{job.applicationsCount}</td>
                  <td className="py-3">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-ct-green/10 text-ct-green">
                      <span className="w-1.5 h-1.5 rounded-full bg-ct-green" /> Active
                    </span>
                  </td>
                  <td className="py-3">
                    <div className="flex items-center gap-1">
                      <button className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors">
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDeleteJobId(job.id)}
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-ct-red hover:bg-ct-red/10 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Recent Placements */}
      <motion.div
        custom={6}
        variants={cardVariants}
        initial="hidden"
        animate="visible"
        className="bg-card rounded-2xl shadow-card p-6"
      >
        <h3 className="font-display text-xl font-semibold mb-4">Recent Placements</h3>
        <div className="flex gap-4 overflow-x-auto pb-2">
          {[
            { name: 'Rahul Verma', company: 'Google', role: 'SDE', package: 22, avatar: 'RV', color: 'bg-blue-100 text-blue-700' },
            { name: 'Priya Singh', company: 'Microsoft', role: 'Data Engineer', package: 20, avatar: 'PS', color: 'bg-purple-100 text-purple-700' },
            { name: 'Amit Kumar', company: 'Google', role: 'SDE', package: 20, avatar: 'AK', color: 'bg-green-100 text-green-700' },
            { name: 'Neha Gupta', company: 'Microsoft', role: 'Software Engineer', package: 18, avatar: 'NG', color: 'bg-orange-100 text-orange-700' },
            { name: 'Ananya Reddy', company: 'Amazon', role: 'SDE', package: 18, avatar: 'AR', color: 'bg-pink-100 text-pink-700' },
          ].map((student, i) => (
            <div key={i} className="flex-shrink-0 w-48 bg-muted rounded-xl p-4">
              <div className={`w-10 h-10 rounded-full ${student.color} flex items-center justify-center font-semibold text-sm mb-2`}>
                {student.avatar}
              </div>
              <p className="font-medium text-sm truncate">{student.name}</p>
              <p className="text-xs text-muted-foreground">{student.company}</p>
              <p className="text-xs text-muted-foreground">{student.role}</p>
              <p className="text-xs text-ct-green font-medium mt-1">{student.package} LPA</p>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={!!deleteJobId}
        onClose={() => setDeleteJobId(null)}
        title="Delete Job Posting?"
      >
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">This action cannot be undone. The job posting will be permanently removed.</p>
          <div className="flex gap-3">
            <button
              onClick={() => setDeleteJobId(null)}
              className="flex-1 h-11 border border-border rounded-xl text-sm font-medium hover:bg-primary/5 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                addToast('success', 'Job posting deleted');
                setDeleteJobId(null);
              }}
              className="flex-1 h-11 bg-ct-red text-white rounded-xl text-sm font-medium hover:bg-red-600 transition-colors"
            >
              Delete
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, CheckCircle, Pencil, Save, X } from 'lucide-react';
import { currentAdmin } from '@/data';
import Modal from '@/components/ui/Modal';
import OTPInput from '@/components/ui/OTPInput';
import { useToast } from '@/contexts/ToastContext';

export default function AdminProfilePage() {
  const { addToast } = useToast();
  const [formData, setFormData] = useState({ ...currentAdmin });
  const [editingField, setEditingField] = useState<string | null>(null);
  const [showOTPModal, setShowOTPModal] = useState(false);
  const [otpValue, setOtpValue] = useState('');
  const [pendingField, setPendingField] = useState<string | null>(null);
  const [pendingValue, setPendingValue] = useState('');

  const handleEdit = (field: string) => {
    setEditingField(field);
  };

  const handleSaveField = (field: string) => {
    setPendingField(field);
    setPendingValue(formData[field as keyof typeof formData] as string);
    setShowOTPModal(true);
    setEditingField(null);
  };

  const handleVerifyOTP = () => {
    if (otpValue.length === 6) {
      if (pendingField) {
        setFormData(prev => ({ ...prev, [pendingField]: pendingValue }));
        addToast('success', `${pendingField} updated successfully!`);
      }
      setShowOTPModal(false);
      setOtpValue('');
      setPendingField(null);
      setPendingValue('');
    } else {
      addToast('error', 'Please enter a valid 6-digit OTP');
    }
  };

  const handleSaveProfile = () => {
    addToast('success', 'Profile updated successfully!');
  };

  const fields = [
    { key: 'name', label: 'Name', type: 'text', editable: true },
    { key: 'email', label: 'College Email', type: 'email', editable: true, verify: true },
    { key: 'phone', label: 'Phone Number', type: 'tel', editable: true, verify: true },
    { key: 'collegeName', label: 'College Name', type: 'text', editable: true },
    { key: 'designation', label: 'Designation', type: 'text', editable: true },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="max-w-2xl mx-auto"
    >
      <div className="bg-card rounded-2xl shadow-card p-6 lg:p-10">
        <h2 className="font-display text-2xl font-bold mb-8 text-center">Admin Profile</h2>

        {/* Avatar */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center text-primary font-display text-3xl font-bold mb-3">
            {formData.name.charAt(0)}
          </div>
          <button className="text-sm text-primary hover:underline flex items-center gap-1">
            <Upload className="w-4 h-4" /> Change Photo
          </button>
        </div>

        {/* Form Fields */}
        <div className="space-y-4">
          {fields.map(field => (
            <div key={field.key}>
              <label className="block text-sm font-medium mb-1.5">{field.label}</label>
              <div className="flex gap-2">
                <input
                  type={field.type}
                  value={formData[field.key as keyof typeof formData]}
                  onChange={e => setFormData(prev => ({ ...prev, [field.key]: e.target.value }))}
                  disabled={field.verify && editingField !== field.key}
                  className="flex-1 h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 disabled:opacity-60 disabled:bg-muted"
                />
                {field.verify && (
                  <>
                    {editingField === field.key ? (
                      <>
                        <button
                          onClick={() => handleSaveField(field.key)}
                          className="w-11 h-11 rounded-xl bg-primary text-primary-foreground flex items-center justify-center hover:bg-ct-primary-hover transition-colors flex-shrink-0"
                        >
                          <Save className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setEditingField(null)}
                          className="w-11 h-11 rounded-xl border border-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => handleEdit(field.key)}
                        className="w-11 h-11 rounded-xl border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary transition-colors flex-shrink-0"
                        title="Change (OTP required)"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                    )}
                  </>
                )}
              </div>
              {field.verify && editingField !== field.key && (
                <div className="flex items-center gap-1 mt-1">
                  <CheckCircle className="w-3 h-3 text-ct-green" />
                  <span className="text-xs text-ct-green">Verified</span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Save Button */}
        <button
          onClick={handleSaveProfile}
          className="w-full h-12 bg-primary text-primary-foreground rounded-xl font-medium mt-8 hover:bg-ct-primary-hover hover:-translate-y-px active:scale-[0.98] transition-all"
        >
          Save Changes
        </button>
      </div>

      {/* OTP Modal */}
      <Modal
        isOpen={showOTPModal}
        onClose={() => { setShowOTPModal(false); setOtpValue(''); }}
        title="Verify OTP"
      >
        <div className="space-y-6">
          <p className="text-sm text-muted-foreground text-center">
            Enter the 6-digit OTP sent to your {pendingField === 'phone' ? 'phone number' : 'email'}
          </p>
          <OTPInput value={otpValue} onChange={setOtpValue} />
          <button
            onClick={handleVerifyOTP}
            className="w-full h-11 bg-primary text-primary-foreground rounded-xl font-medium text-sm hover:bg-ct-primary-hover transition-colors"
          >
            Verify
          </button>
          <p className="text-xs text-center text-muted-foreground">
            Didn&apos;t receive? <button className="text-primary hover:underline">Resend OTP</button>
          </p>
        </div>
      </Modal>
    </motion.div>
  );
}

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  X,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { jobPostings, type JobPosting } from '@/data';
import Modal from '@/components/ui/Modal';
import { useToast } from '@/contexts/ToastContext';

const cardVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.4, ease: 'easeOut' as const },
  }),
};

type JobFormTab = 'basic' | 'eligibility' | 'process';

export default function JobManagementPage() {
  const { addToast } = useToast();
  const [jobs, setJobs] = useState<JobPosting[]>(jobPostings);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createTab, setCreateTab] = useState<JobFormTab>('basic');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [deleteJobId, setDeleteJobId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    companyName: '',
    role: '',
    description: '',
    location: '',
    packageMin: '',
    packageMax: '',
    industry: '',
    deadline: '',
    minTenth: '',
    minTwelfth: '',
    minCgpa: '',
    maxBacklogs: '0',
    branches: [] as string[],
    yearOfPassing: '2025',
    rounds: [{ name: '', type: 'Aptitude' }],
  });

  const itemsPerPage = 5;
  const filteredJobs = jobs.filter(j =>
    j.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    j.role.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const totalPages = Math.ceil(filteredJobs.length / itemsPerPage);
  const paginatedJobs = filteredJobs.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handleCreateJob = () => {
    if (!formData.companyName || !formData.role) {
      addToast('error', 'Please fill in company name and role');
      return;
    }
    const newJob: JobPosting = {
      id: `job_${Date.now()}`,
      companyName: formData.companyName,
      role: formData.role,
      location: formData.location || 'Not specified',
      packageMin: Number(formData.packageMin) || 0,
      packageMax: Number(formData.packageMax) || 0,
      industry: formData.industry || 'Other',
      description: formData.description || 'No description provided.',
      deadline: formData.deadline || 'TBD',
      eligibility: {
        minTenth: Number(formData.minTenth) || 0,
        minTwelfth: Number(formData.minTwelfth) || 0,
        minCgpa: Number(formData.minCgpa) || 0,
        maxBacklogs: Number(formData.maxBacklogs) || 0,
        branches: formData.branches.length > 0 ? formData.branches : ['CSE', 'IT'],
        yearOfPassing: Number(formData.yearOfPassing) || 2025,
      },
      rounds: formData.rounds.filter(r => r.name).map(r => ({ name: r.name, type: r.type })),
      status: 'active',
      postedDate: new Date().toISOString().split('T')[0],
      applicationsCount: 0,
      rating: 0,
      reviewCount: 0,
    };
    setJobs(prev => [newJob, ...prev]);
    addToast('success', 'Job posted successfully!');
    setShowCreateModal(false);
    setFormData({
      companyName: '', role: '', description: '', location: '', packageMin: '', packageMax: '',
      industry: '', deadline: '', minTenth: '', minTwelfth: '', minCgpa: '', maxBacklogs: '0',
      branches: [], yearOfPassing: '2025', rounds: [{ name: '', type: 'Aptitude' }],
    });
  };

  const handleDelete = () => {
    if (deleteJobId) {
      setJobs(prev => prev.filter(j => j.id !== deleteJobId));
      addToast('success', 'Job deleted successfully');
      setDeleteJobId(null);
    }
  };

  const addRound = () => {
    setFormData(prev => ({ ...prev, rounds: [...prev.rounds, { name: '', type: 'Aptitude' }] }));
  };

  const updateRound = (index: number, field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      rounds: prev.rounds.map((r, i) => i === index ? { ...r, [field]: value } : r),
    }));
  };

  const branchesList = ['CSE', 'IT', 'ECE', 'EEE', 'MECH', 'CIVIL'];
  const roundTypes = ['Aptitude', 'Technical', 'HR', 'Coding', 'Group Discussion'];

  return (
    <div className="space-y-6">
      {/* Action Bar */}
      <motion.div
        variants={cardVariants}
        initial="hidden"
        animate="visible"
        className="flex flex-col sm:flex-row sm:items-center justify-between gap-4"
      >
        <div className="flex items-center gap-3">
          <h2 className="font-display text-2xl font-bold">Job Postings</h2>
          <span className="bg-primary/10 text-primary px-3 py-1 rounded-lg text-sm font-medium">
            {jobs.length}
          </span>
        </div>
        <div className="flex gap-3">
          <div className="relative flex-1 sm:flex-none">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search jobs..."
              className="w-full sm:w-64 h-10 pl-9 pr-4 rounded-xl border border-border bg-card text-sm focus:outline-none focus:border-primary"
            />
          </div>
          <button
            onClick={() => setShowCreateModal(true)}
            className="inline-flex items-center gap-2 px-4 h-10 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-ct-primary-hover transition-colors"
          >
            <Plus className="w-4 h-4" /> Create New Job
          </button>
        </div>
      </motion.div>

      {/* Job Table */}
      <motion.div
        variants={cardVariants}
        custom={1}
        initial="hidden"
        animate="visible"
        className="bg-card rounded-2xl shadow-card overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-muted-foreground text-left border-b border-border bg-muted/50">
                <th className="px-6 py-4 font-medium">Company</th>
                <th className="px-6 py-4 font-medium">Role</th>
                <th className="px-6 py-4 font-medium">Package</th>
                <th className="px-6 py-4 font-medium">Deadline</th>
                <th className="px-6 py-4 font-medium">Applications</th>
                <th className="px-6 py-4 font-medium">Status</th>
                <th className="px-6 py-4 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {paginatedJobs.map(job => (
                <tr key={job.id} className="border-b border-border/50 hover:bg-primary/5 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-semibold text-sm">
                        {job.companyName.charAt(0)}
                      </div>
                      <span className="font-medium">{job.companyName}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">{job.role}</td>
                  <td className="px-6 py-4">{job.packageMin}-{job.packageMax} LPA</td>
                  <td className="px-6 py-4 text-muted-foreground">{job.deadline}</td>
                  <td className="px-6 py-4">{job.applicationsCount}</td>
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-ct-green/10 text-ct-green">
                      <span className="w-1.5 h-1.5 rounded-full bg-ct-green" /> Active
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1">
                      <button className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors">
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDeleteJobId(job.id)}
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-ct-red hover:bg-ct-red/10 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-6 py-4 border-t border-border">
            <p className="text-sm text-muted-foreground">
              Showing {(currentPage - 1) * itemsPerPage + 1} to {Math.min(currentPage * itemsPerPage, filteredJobs.length)} of {filteredJobs.length}
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="w-9 h-9 rounded-lg border border-border flex items-center justify-center text-muted-foreground hover:text-foreground disabled:opacity-40 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  className={`w-9 h-9 rounded-lg flex items-center justify-center text-sm font-medium transition-colors ${
                    currentPage === page
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:text-foreground hover:bg-primary/5'
                  }`}
                >
                  {page}
                </button>
              ))}
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="w-9 h-9 rounded-lg border border-border flex items-center justify-center text-muted-foreground hover:text-foreground disabled:opacity-40 transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </motion.div>

      {/* Create Job Modal */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title="Create New Job"
        maxWidth="640px"
      >
        {/* Tabs */}
        <div className="flex gap-1 p-1 bg-muted rounded-xl mb-6">
          {(['basic', 'eligibility', 'process'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setCreateTab(tab)}
              className={`flex-1 h-10 rounded-lg text-sm font-medium capitalize transition-all ${
                createTab === tab
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {tab === 'process' ? 'Process' : tab === 'basic' ? 'Basic Info' : 'Eligibility'}
            </button>
          ))}
        </div>

        <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-2">
          <AnimatePresence mode="wait">
            {createTab === 'basic' && (
              <motion.div
                key="basic"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="space-y-4"
              >
                <div>
                  <label className="block text-sm font-medium mb-1.5">Company Name</label>
                  <input
                    type="text"
                    value={formData.companyName}
                    onChange={e => setFormData(prev => ({ ...prev, companyName: e.target.value }))}
                    className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Role Title</label>
                  <input
                    type="text"
                    value={formData.role}
                    onChange={e => setFormData(prev => ({ ...prev, role: e.target.value }))}
                    className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Job Description</label>
                  <textarea
                    value={formData.description}
                    onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    rows={4}
                    className="w-full px-4 py-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary resize-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Location</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={e => setFormData(prev => ({ ...prev, location: e.target.value }))}
                    placeholder="e.g. Bangalore, Hyderabad"
                    className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Min Package (LPA)</label>
                    <input
                      type="number"
                      value={formData.packageMin}
                      onChange={e => setFormData(prev => ({ ...prev, packageMin: e.target.value }))}
                      className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Max Package (LPA)</label>
                    <input
                      type="number"
                      value={formData.packageMax}
                      onChange={e => setFormData(prev => ({ ...prev, packageMax: e.target.value }))}
                      className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Industry</label>
                  <select
                    value={formData.industry}
                    onChange={e => setFormData(prev => ({ ...prev, industry: e.target.value }))}
                    className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
                  >
                    <option value="">Select industry</option>
                    <option value="MNC / Tech">MNC / Tech</option>
                    <option value="Startup / E-commerce">Startup / E-commerce</option>
                    <option value="Fintech">Fintech</option>
                    <option value="EdTech">EdTech</option>
                    <option value="Finance / Investment Banking">Finance</option>
                    <option value="MNC / IT Services">IT Services</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Application Deadline</label>
                  <input
                    type="date"
                    value={formData.deadline}
                    onChange={e => setFormData(prev => ({ ...prev, deadline: e.target.value }))}
                    className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
                  />
                </div>
              </motion.div>
            )}

            {createTab === 'eligibility' && (
              <motion.div
                key="eligibility"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="space-y-4"
              >
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1.5">10th Min %</label>
                    <input
                      type="number"
                      value={formData.minTenth}
                      onChange={e => setFormData(prev => ({ ...prev, minTenth: e.target.value }))}
                      className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">12th Min %</label>
                    <input
                      type="number"
                      value={formData.minTwelfth}
                      onChange={e => setFormData(prev => ({ ...prev, minTwelfth: e.target.value }))}
                      className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Min CGPA</label>
                    <input
                      type="number"
                      step="0.1"
                      value={formData.minCgpa}
                      onChange={e => setFormData(prev => ({ ...prev, minCgpa: e.target.value }))}
                      className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5">Max Backlogs</label>
                    <input
                      type="number"
                      value={formData.maxBacklogs}
                      onChange={e => setFormData(prev => ({ ...prev, maxBacklogs: e.target.value }))}
                      className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Allowed Branches</label>
                  <div className="flex flex-wrap gap-2">
                    {branchesList.map(branch => (
                      <button
                        key={branch}
                        onClick={() => {
                          setFormData(prev => ({
                            ...prev,
                            branches: prev.branches.includes(branch)
                              ? prev.branches.filter(b => b !== branch)
                              : [...prev.branches, branch],
                          }));
                        }}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                          formData.branches.includes(branch)
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted text-muted-foreground hover:text-foreground'
                        }`}
                      >
                        {branch}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1.5">Year of Passing</label>
                  <input
                    type="number"
                    value={formData.yearOfPassing}
                    onChange={e => setFormData(prev => ({ ...prev, yearOfPassing: e.target.value }))}
                    className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
                  />
                </div>
              </motion.div>
            )}

            {createTab === 'process' && (
              <motion.div
                key="process"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                className="space-y-4"
              >
                {formData.rounds.map((round, i) => (
                  <div key={i} className="flex gap-3 items-start">
                    <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-semibold flex-shrink-0 mt-2">
                      {i + 1}
                    </div>
                    <div className="flex-1 grid grid-cols-2 gap-3">
                      <input
                        type="text"
                        value={round.name}
                        onChange={e => updateRound(i, 'name', e.target.value)}
                        placeholder="Round name"
                        className="h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
                      />
                      <select
                        value={round.type}
                        onChange={e => updateRound(i, 'type', e.target.value)}
                        className="h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
                      >
                        {roundTypes.map(t => <option key={t} value={t}>{t}</option>)}
                      </select>
                    </div>
                    {i > 0 && (
                      <button
                        onClick={() => setFormData(prev => ({ ...prev, rounds: prev.rounds.filter((_, idx) => idx !== i) }))}
                        className="w-7 h-7 rounded-lg flex items-center justify-center text-muted-foreground hover:text-ct-red mt-2"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
                <button
                  onClick={addRound}
                  className="w-full h-10 border-2 border-dashed border-border rounded-xl text-sm text-muted-foreground hover:text-primary hover:border-primary transition-colors"
                >
                  + Add Round
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer */}
        <div className="flex gap-3 mt-6 pt-4 border-t border-border">
          <button
            onClick={() => setShowCreateModal(false)}
            className="flex-1 h-11 border border-border rounded-xl text-sm font-medium hover:bg-primary/5 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleCreateJob}
            className="flex-1 h-11 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:bg-ct-primary-hover transition-colors"
          >
            Publish Job
          </button>
        </div>
      </Modal>

      {/* Delete Confirmation */}
      <Modal
        isOpen={!!deleteJobId}
        onClose={() => setDeleteJobId(null)}
        title="Delete Job Posting?"
      >
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">This action cannot be undone.</p>
          <div className="flex gap-3">
            <button
              onClick={() => setDeleteJobId(null)}
              className="flex-1 h-11 border border-border rounded-xl text-sm font-medium hover:bg-primary/5 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleDelete}
              className="flex-1 h-11 bg-ct-red text-white rounded-xl text-sm font-medium hover:bg-red-600 transition-colors"
            >
              Delete
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

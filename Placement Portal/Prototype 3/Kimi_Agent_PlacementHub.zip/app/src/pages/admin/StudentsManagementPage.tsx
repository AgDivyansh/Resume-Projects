import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Search,
  Download,
  IndianRupee,
  Briefcase,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import Modal from '@/components/ui/Modal';

// Mock students data
const studentsData = [
  { id: 'st_001', rollNo: '2021CS001', name: 'Rahul Verma', branch: 'CSE', cgpa: 9.2, tenth: 95, twelfth: 92, backlogs: 0, placed: true, company: 'Google', role: 'SDE' },
  { id: 'st_002', rollNo: '2021CS002', name: 'Priya Singh', branch: 'CSE', cgpa: 8.8, tenth: 90, twelfth: 88, backlogs: 0, placed: true, company: 'Microsoft', role: 'Data Engineer' },
  { id: 'st_003', rollNo: '2021CS003', name: 'Amit Kumar', branch: 'CSE', cgpa: 8.5, tenth: 88, twelfth: 85, backlogs: 0, placed: true, company: 'Google', role: 'SDE' },
  { id: 'st_004', rollNo: '2021IT001', name: 'Neha Gupta', branch: 'IT', cgpa: 8.7, tenth: 91, twelfth: 89, backlogs: 0, placed: true, company: 'Microsoft', role: 'Software Engineer' },
  { id: 'st_005', rollNo: '2021CS045', name: 'Divyansh Sharma', branch: 'CSE', cgpa: 8.2, tenth: 82, twelfth: 79, backlogs: 0, placed: false, company: '', role: '' },
  { id: 'st_006', rollNo: '2021ECE001', name: 'Suresh Patel', branch: 'ECE', cgpa: 7.9, tenth: 85, twelfth: 80, backlogs: 0, placed: true, company: 'Microsoft', role: 'Software Engineer' },
  { id: 'st_007', rollNo: '2021CS005', name: 'Ananya Reddy', branch: 'CSE', cgpa: 8.9, tenth: 93, twelfth: 91, backlogs: 0, placed: true, company: 'Amazon', role: 'SDE' },
  { id: 'st_008', rollNo: '2021IT002', name: 'Vikram Joshi', branch: 'IT', cgpa: 8.1, tenth: 84, twelfth: 81, backlogs: 1, placed: true, company: 'Flipkart', role: 'SDE' },
  { id: 'st_009', rollNo: '2021MECH001', name: 'Deepika Shah', branch: 'MECH', cgpa: 7.5, tenth: 80, twelfth: 78, backlogs: 0, placed: true, company: 'Goldman Sachs', role: 'Analyst' },
  { id: 'st_010', rollNo: '2021CS006', name: 'Arjun Nair', branch: 'CSE', cgpa: 7.8, tenth: 78, twelfth: 76, backlogs: 1, placed: false, company: '', role: '' },
];

const branches = ['All', 'CSE', 'IT', 'ECE', 'EEE', 'MECH', 'CIVIL'];

export default function StudentsManagementPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBranch, setSelectedBranch] = useState('All');
  const [placedFilter, setPlacedFilter] = useState<'all' | 'placed' | 'unplaced'>('all');
  const [selectedStudent, setSelectedStudent] = useState<typeof studentsData[0] | null>(null);

  const filteredStudents = studentsData.filter(s => {
    const matchesSearch = s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.rollNo.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesBranch = selectedBranch === 'All' || s.branch === selectedBranch;
    const matchesPlaced = placedFilter === 'all' ||
      (placedFilter === 'placed' && s.placed) ||
      (placedFilter === 'unplaced' && !s.placed);
    return matchesSearch && matchesBranch && matchesPlaced;
  });

  return (
    <div className="space-y-6">
      {/* Filter Bar */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="bg-card rounded-2xl shadow-card p-4"
      >
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by name or roll number..."
              className="w-full h-10 pl-9 pr-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
            />
          </div>
          <div className="flex gap-3">
            <select
              value={selectedBranch}
              onChange={e => setSelectedBranch(e.target.value)}
              className="h-10 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
            >
              {branches.map(b => <option key={b} value={b}>{b}</option>)}
            </select>
            <div className="flex p-1 bg-muted rounded-lg">
              {(['all', 'placed', 'unplaced'] as const).map(filter => (
                <button
                  key={filter}
                  onClick={() => setPlacedFilter(filter)}
                  className={`px-4 py-1.5 rounded-md text-xs font-medium capitalize transition-all ${
                    placedFilter === filter
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
            <button className="inline-flex items-center gap-2 px-4 h-10 border border-border rounded-xl text-sm font-medium text-muted-foreground hover:text-foreground hover:border-primary transition-colors">
              <Download className="w-4 h-4" /> Export
            </button>
          </div>
        </div>
      </motion.div>

      {/* Students Table */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.1 }}
        className="bg-card rounded-2xl shadow-card overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-muted-foreground text-left border-b border-border bg-muted/50">
                <th className="px-6 py-4 font-medium">Roll No</th>
                <th className="px-6 py-4 font-medium">Name</th>
                <th className="px-6 py-4 font-medium">Branch</th>
                <th className="px-6 py-4 font-medium">CGPA</th>
                <th className="px-6 py-4 font-medium">10th %</th>
                <th className="px-6 py-4 font-medium">12th %</th>
                <th className="px-6 py-4 font-medium">Backlogs</th>
                <th className="px-6 py-4 font-medium">Status</th>
                <th className="px-6 py-4 font-medium">Company</th>
              </tr>
            </thead>
            <tbody>
              {filteredStudents.map(student => (
                <tr
                  key={student.id}
                  onClick={() => setSelectedStudent(student)}
                  className="border-b border-border/50 hover:bg-primary/5 transition-colors cursor-pointer"
                >
                  <td className="px-6 py-4 font-medium">{student.rollNo}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-semibold">
                        {student.name.charAt(0)}
                      </div>
                      {student.name}
                    </div>
                  </td>
                  <td className="px-6 py-4">{student.branch}</td>
                  <td className="px-6 py-4 font-medium">{student.cgpa}</td>
                  <td className="px-6 py-4">{student.tenth}%</td>
                  <td className="px-6 py-4">{student.twelfth}%</td>
                  <td className="px-6 py-4">{student.backlogs}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium ${
                      student.placed
                        ? 'bg-ct-green/10 text-ct-green'
                        : 'bg-ct-orange/10 text-ct-orange'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${student.placed ? 'bg-ct-green' : 'bg-ct-orange'}`} />
                      {student.placed ? 'Placed' : 'Unplaced'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-muted-foreground">{student.company || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Student Detail Modal */}
      <Modal
        isOpen={!!selectedStudent}
        onClose={() => setSelectedStudent(null)}
        title={selectedStudent?.name}
      >
        {selectedStudent && (
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center text-primary font-display text-2xl font-bold">
                {selectedStudent.name.charAt(0)}
              </div>
              <div>
                <h3 className="font-semibold text-lg">{selectedStudent.name}</h3>
                <p className="text-sm text-muted-foreground">{selectedStudent.rollNo} • {selectedStudent.branch}</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="bg-muted rounded-xl p-4 text-center">
                <p className="font-display text-2xl font-bold">{selectedStudent.tenth}%</p>
                <p className="text-xs text-muted-foreground">10th</p>
              </div>
              <div className="bg-muted rounded-xl p-4 text-center">
                <p className="font-display text-2xl font-bold">{selectedStudent.twelfth}%</p>
                <p className="text-xs text-muted-foreground">12th</p>
              </div>
              <div className="bg-muted rounded-xl p-4 text-center">
                <p className="font-display text-2xl font-bold">{selectedStudent.cgpa}</p>
                <p className="text-xs text-muted-foreground">CGPA</p>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-3">Placement Status</h4>
              <div className="flex items-center gap-3">
                <span className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium ${
                  selectedStudent.placed
                    ? 'bg-ct-green/10 text-ct-green'
                    : 'bg-ct-orange/10 text-ct-orange'
                }`}>
                  {selectedStudent.placed ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                  {selectedStudent.placed ? 'Placed' : 'Unplaced'}
                </span>
                {selectedStudent.placed && (
                  <>
                    <span className="text-sm text-muted-foreground">
                      <Briefcase className="w-4 h-4 inline mr-1" />
                      {selectedStudent.company}
                    </span>
                    <span className="text-sm text-ct-green font-medium">
                      <IndianRupee className="w-4 h-4 inline" />
                      Package received
                    </span>
                  </>
                )}
              </div>
            </div>

            {selectedStudent.placed && (
              <div>
                <h4 className="font-semibold mb-3">Applied Jobs</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-muted rounded-xl">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary text-xs font-semibold">
                        {selectedStudent.company.charAt(0)}
                      </div>
                      <span className="text-sm font-medium">{selectedStudent.company}</span>
                    </div>
                    <span className="bg-ct-green/10 text-ct-green px-2.5 py-1 rounded-md text-xs font-medium">Selected</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}

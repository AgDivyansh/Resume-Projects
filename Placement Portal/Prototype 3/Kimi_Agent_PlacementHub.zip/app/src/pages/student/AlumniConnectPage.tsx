import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Search,
  Phone,
  Video,
  Send,
  Calendar,
  MessageSquare,
  ChevronLeft,
} from 'lucide-react';
import { alumni, chatMessages } from '@/data';
import type { ChatMessage } from '@/data';
import Modal from '@/components/ui/Modal';
import { useToast } from '@/contexts/ToastContext';

const pastelColors = [
  'bg-blue-100 text-blue-700',
  'bg-green-100 text-green-700',
  'bg-purple-100 text-purple-700',
  'bg-orange-100 text-orange-700',
  'bg-pink-100 text-pink-700',
  'bg-teal-100 text-teal-700',
  'bg-indigo-100 text-indigo-700',
  'bg-rose-100 text-rose-700',
];

export default function AlumniConnectPage() {
  const { addToast } = useToast();
  const [selectedAlumniId, setSelectedAlumniId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [messageInput, setMessageInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>(chatMessages);
  const [showCallRequestModal, setShowCallRequestModal] = useState(false);
  const [callRequestForm, setCallRequestForm] = useState({
    type: 'voice' as 'voice' | 'video',
    date: '',
    time: '',
    note: '',
  });
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const selectedAlumni = alumni.find(a => a.id === selectedAlumniId);

  const filteredAlumni = alumni.filter(a =>
    a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.company.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const alumniMessages = messages.filter(
    m => m.senderId === selectedAlumniId || m.senderId === 'st_001'
  );

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [alumniMessages]);

  const handleSendMessage = () => {
    if (!messageInput.trim() || !selectedAlumniId) return;
    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      senderId: 'st_001',
      content: messageInput.trim(),
      timestamp: new Date().toISOString(),
    };
    setMessages(prev => [...prev, newMsg]);
    setMessageInput('');
  };

  const handleCallRequest = () => {
    if (!callRequestForm.date || !callRequestForm.time) {
      addToast('error', 'Please select date and time');
      return;
    }
    addToast('success', `Call request sent to ${selectedAlumni?.name}!`);
    setShowCallRequestModal(false);
    setCallRequestForm({ type: 'voice', date: '', time: '', note: '' });
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="h-[calc(100vh-8rem)] -mx-4 lg:-mx-8 -mt-4 lg:-mt-8">
      <div className="flex h-full">
        {/* Alumni List Sidebar */}
        <div className={`w-full lg:w-80 bg-card border-r border-border flex flex-col ${selectedAlumniId ? 'hidden lg:flex' : 'flex'}`}>
          {/* Search */}
          <div className="p-4 border-b border-border">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search alumni..."
                className="w-full h-10 pl-9 pr-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </div>
          </div>

          {/* Alumni List */}
          <div className="flex-1 overflow-y-auto">
            {filteredAlumni.map((alum, i) => (
              <button
                key={alum.id}
                onClick={() => setSelectedAlumniId(alum.id)}
                className={`w-full flex items-center gap-3 p-4 text-left transition-colors border-b border-border/50 ${
                  selectedAlumniId === alum.id
                    ? 'bg-primary/10 border-l-[3px] border-l-primary'
                    : 'hover:bg-primary/5 border-l-[3px] border-l-transparent'
                }`}
              >
                <div className="relative flex-shrink-0">
                  <div className={`w-11 h-11 rounded-full flex items-center justify-center font-semibold text-sm ${pastelColors[i % pastelColors.length]}`}>
                    {alum.avatar}
                  </div>
                  <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-card ${alum.online ? 'bg-ct-green' : 'bg-muted-foreground'}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{alum.name}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="bg-primary/10 text-primary px-1.5 py-0.5 rounded text-[10px] font-medium">
                      {alum.company}
                    </span>
                    <span className="text-ct-green text-[10px] font-medium">{alum.package} LPA</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Chat Area */}
        <div className={`flex-1 flex flex-col bg-background ${selectedAlumniId ? 'flex' : 'hidden lg:flex'}`}>
          {selectedAlumni ? (
            <>
              {/* Chat Header */}
              <div className="flex items-center gap-3 px-4 lg:px-6 py-3 border-b border-border bg-card">
                <button
                  onClick={() => setSelectedAlumniId(null)}
                  className="lg:hidden w-8 h-8 flex items-center justify-center text-muted-foreground"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold text-sm ${pastelColors[alumni.indexOf(selectedAlumni) % pastelColors.length]}`}>
                  {selectedAlumni.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{selectedAlumni.name}</p>
                  <div className="flex items-center gap-2">
                    <span className="bg-primary/10 text-primary px-1.5 py-0.5 rounded text-[10px] font-medium">
                      {selectedAlumni.company}
                    </span>
                    <span className="text-ct-green text-[10px] font-medium">{selectedAlumni.package} LPA</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {selectedAlumni.callScheduled && selectedAlumni.callApproved ? (
                    <>
                      <button
                        onClick={() => addToast('info', `Starting ${selectedAlumni.callType} call with ${selectedAlumni.name}...`)}
                        className="w-9 h-9 rounded-lg flex items-center justify-center text-primary bg-primary/10 hover:bg-primary/20 transition-colors"
                        title={`${selectedAlumni.callType} call scheduled for ${selectedAlumni.callDate} at ${selectedAlumni.callTime}`}
                      >
                        {selectedAlumni.callType === 'voice' ? <Phone className="w-4 h-4" /> : <Video className="w-4 h-4" />}
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={() => setShowCallRequestModal(true)}
                        className="w-9 h-9 rounded-lg flex items-center justify-center text-muted-foreground bg-muted hover:text-foreground hover:bg-primary/10 transition-colors opacity-40"
                        title="Schedule a call first"
                      >
                        <Phone className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setShowCallRequestModal(true)}
                        className="w-9 h-9 rounded-lg flex items-center justify-center text-muted-foreground bg-muted hover:text-foreground hover:bg-primary/10 transition-colors opacity-40"
                        title="Schedule a call first"
                      >
                        <Video className="w-4 h-4" />
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto px-4 lg:px-6 py-4 space-y-4">
                {alumniMessages.map((msg) => {
                  const isSent = msg.senderId === 'st_001';
                  return (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, x: isSent ? 20 : -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, type: 'spring' }}
                      className={`flex ${isSent ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[70%] px-4 py-2.5 rounded-2xl ${
                        isSent
                          ? 'bg-primary text-primary-foreground rounded-br-sm'
                          : 'bg-card text-foreground rounded-bl-sm shadow-sm border border-border'
                      }`}>
                        <p className="text-sm">{msg.content}</p>
                        <p className={`text-[10px] mt-1 ${isSent ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>
                          {formatTime(msg.timestamp)}
                        </p>
                      </div>
                    </motion.div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              {/* Input Area */}
              <div className="px-4 lg:px-6 py-3 border-t border-border bg-card">
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    value={messageInput}
                    onChange={e => setMessageInput(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Type a message..."
                    className="flex-1 h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                  />
                  <button
                    onClick={handleSendMessage}
                    disabled={!messageInput.trim()}
                    className="w-11 h-11 rounded-xl bg-primary text-primary-foreground flex items-center justify-center hover:bg-ct-primary-hover active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </>
          ) : (
            /* Empty State */
            <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
              <MessageSquare className="w-16 h-16 mb-4 opacity-30" />
              <p className="text-lg font-medium">Select an alumni to start chatting</p>
              <p className="text-sm mt-1">Connect with placed seniors for guidance</p>
            </div>
          )}
        </div>
      </div>

      {/* Call Request Modal */}
      <Modal
        isOpen={showCallRequestModal}
        onClose={() => setShowCallRequestModal(false)}
        title="Schedule a Call"
      >
        <div className="space-y-4">
          {/* Call Type */}
          <div>
            <label className="block text-sm font-medium mb-2">Call Type</label>
            <div className="flex gap-3">
              <button
                onClick={() => setCallRequestForm(prev => ({ ...prev, type: 'voice' }))}
                className={`flex-1 flex items-center justify-center gap-2 h-12 rounded-xl border text-sm font-medium transition-all ${
                  callRequestForm.type === 'voice'
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border text-muted-foreground hover:text-foreground'
                }`}
              >
                <Phone className="w-4 h-4" /> Voice Call
              </button>
              <button
                onClick={() => setCallRequestForm(prev => ({ ...prev, type: 'video' }))}
                className={`flex-1 flex items-center justify-center gap-2 h-12 rounded-xl border text-sm font-medium transition-all ${
                  callRequestForm.type === 'video'
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border text-muted-foreground hover:text-foreground'
                }`}
              >
                <Video className="w-4 h-4" /> Video Call
              </button>
            </div>
          </div>

          {/* Date */}
          <div>
            <label className="block text-sm font-medium mb-2">Date</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="date"
                value={callRequestForm.date}
                onChange={e => setCallRequestForm(prev => ({ ...prev, date: e.target.value }))}
                className="w-full h-11 pl-10 pr-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
              />
            </div>
          </div>

          {/* Time */}
          <div>
            <label className="block text-sm font-medium mb-2">Time</label>
            <select
              value={callRequestForm.time}
              onChange={e => setCallRequestForm(prev => ({ ...prev, time: e.target.value }))}
              className="w-full h-11 px-4 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary"
            >
              <option value="">Select time slot</option>
              {['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '12:00', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00'].map(time => (
                <option key={time} value={time}>{time}</option>
              ))}
            </select>
          </div>

          {/* Note */}
          <div>
            <label className="block text-sm font-medium mb-2">Message (Optional)</label>
            <textarea
              value={callRequestForm.note}
              onChange={e => setCallRequestForm(prev => ({ ...prev, note: e.target.value }))}
              placeholder="Add a note..."
              rows={3}
              className="w-full px-4 py-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary resize-none"
            />
          </div>

          <button
            onClick={handleCallRequest}
            className="w-full h-11 bg-primary text-primary-foreground rounded-xl font-medium text-sm hover:bg-ct-primary-hover transition-colors"
          >
            Send Request
          </button>
        </div>
      </Modal>
    </div>
  );
}

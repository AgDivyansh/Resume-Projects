import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, ArrowRight, IndianRupee, Users, Briefcase, Building2 } from 'lucide-react';
import { companies } from '@/data';
import StarRating from '@/components/ui/StarRating';

const cardVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.4, ease: 'easeOut' as const },
  }),
};

export default function CompaniesPage() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCompanies = useMemo(() => {
    if (!searchQuery.trim()) return companies;
    const q = searchQuery.toLowerCase();
    return companies.filter(c =>
      c.name.toLowerCase().includes(q) ||
      c.industry.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <motion.div
        variants={cardVariants}
        initial="hidden"
        animate="visible"
        className="relative"
      >
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input
          type="text"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder="Search companies..."
          className="w-full h-12 pl-12 pr-4 rounded-2xl border border-border bg-card shadow-card text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
        />
      </motion.div>

      {/* Company Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {filteredCompanies.map((company, i) => (
          <motion.div
            key={company.id}
            custom={i}
            variants={cardVariants}
            initial="hidden"
            animate="visible"
            onClick={() => navigate(`/companies/${company.id}`)}
            className="bg-card rounded-2xl shadow-card p-6 cursor-pointer hover:shadow-card-hover hover:scale-[1.005] active:scale-[0.995] transition-all duration-250"
          >
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center text-primary font-semibold text-xl flex-shrink-0">
                {company.name.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-semibold text-lg">{company.name}</h3>
                    <span className="inline-block bg-primary/10 text-primary px-2.5 py-0.5 rounded-md text-xs font-medium mt-1">
                      {company.industry}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 mt-2">
                  <StarRating rating={company.rating} size={16} />
                  <span className="text-sm font-medium">{company.rating}</span>
                  <span className="text-xs text-muted-foreground">({company.reviewCount} reviews)</span>
                </div>

                <div className="grid grid-cols-3 gap-3 mt-4">
                  <div className="text-center p-2 bg-muted rounded-lg">
                    <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground mb-0.5">
                      <IndianRupee className="w-3 h-3" /> Avg
                    </div>
                    <p className="font-semibold text-sm">{company.avgPackage} LPA</p>
                  </div>
                  <div className="text-center p-2 bg-muted rounded-lg">
                    <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground mb-0.5">
                      <IndianRupee className="w-3 h-3" /> High
                    </div>
                    <p className="font-semibold text-sm">{company.highestPackage} LPA</p>
                  </div>
                  <div className="text-center p-2 bg-muted rounded-lg">
                    <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground mb-0.5">
                      <Users className="w-3 h-3" /> Placed
                    </div>
                    <p className="font-semibold text-sm">{company.totalPlaced}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-4">
                  <span className="text-xs text-muted-foreground">
                    <Briefcase className="w-3 h-3 inline mr-1" />
                    {company.openRoles} open roles
                  </span>
                  <span className="text-sm text-primary font-medium flex items-center gap-1">
                    View Details <ArrowRight className="w-4 h-4" />
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {filteredCompanies.length === 0 && (
        <div className="text-center py-16">
          <Building2 className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No companies found</p>
        </div>
      )}
    </div>
  );
}

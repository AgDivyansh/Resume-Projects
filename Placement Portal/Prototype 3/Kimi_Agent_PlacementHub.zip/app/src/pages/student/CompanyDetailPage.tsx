import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Star,
  IndianRupee,
  Users,
  Briefcase,
  ArrowLeft,
  PenLine,
  Send,
} from 'lucide-react';
import { companies } from '@/data';
import StarRating from '@/components/ui/StarRating';
import Modal from '@/components/ui/Modal';
import { useToast } from '@/contexts/ToastContext';

const cardVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.4, ease: 'easeOut' as const },
  }),
};

export default function CompanyDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToast } = useToast();
  const company = companies.find(c => c.id === id);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [reviewForm, setReviewForm] = useState({ rating: 0, experience: '', tips: '' });

  if (!company) {
    return (
      <div className="text-center py-16">
        <p className="text-muted-foreground">Company not found</p>
        <button onClick={() => navigate('/companies')} className="text-primary mt-4">Go back</button>
      </div>
    );
  }

  const handleSubmitReview = () => {
    if (reviewForm.rating === 0) {
      addToast('error', 'Please select a rating');
      return;
    }
    addToast('success', 'Review submitted successfully!');
    setShowReviewModal(false);
    setReviewForm({ rating: 0, experience: '', tips: '' });
  };

  const pastelColors = [
    'bg-blue-100 text-blue-700',
    'bg-green-100 text-green-700',
    'bg-purple-100 text-purple-700',
    'bg-orange-100 text-orange-700',
    'bg-pink-100 text-pink-700',
    'bg-teal-100 text-teal-700',
  ];

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <button
        onClick={() => navigate('/companies')}
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Companies
      </button>

      {/* Header Section */}
      <motion.div
        variants={cardVariants}
        initial="hidden"
        animate="visible"
        className="bg-card rounded-2xl shadow-card p-6 lg:p-8"
      >
        <div className="flex flex-col sm:flex-row items-start gap-4">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center text-primary font-semibold text-2xl flex-shrink-0">
            {company.name.charAt(0)}
          </div>
          <div className="flex-1">
            <h1 className="font-display text-2xl lg:text-3xl font-bold">{company.name}</h1>
            <div className="flex flex-wrap items-center gap-3 mt-2">
              <span className="bg-primary/10 text-primary px-3 py-1 rounded-lg text-sm font-medium">
                {company.industry}
              </span>
              <div className="flex items-center gap-1.5">
                <StarRating rating={company.rating} size={16} />
                <span className="text-sm font-medium">{company.rating}</span>
                <span className="text-xs text-muted-foreground">({company.reviewCount} reviews)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          {[
            { label: 'Avg Package', value: `${company.avgPackage} LPA`, icon: IndianRupee },
            { label: 'Highest Package', value: `${company.highestPackage} LPA`, icon: IndianRupee },
            { label: 'Total Placed', value: `${company.totalPlaced}`, icon: Users },
            { label: 'Open Roles', value: `${company.openRoles}`, icon: Briefcase },
          ].map((stat, i) => (
            <div key={i} className="bg-muted rounded-xl p-4 text-center">
              <stat.icon className="w-5 h-5 text-primary mx-auto mb-1" />
              <p className="font-display text-xl font-bold">{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Historical Data */}
      <motion.div
        variants={cardVariants}
        custom={1}
        initial="hidden"
        animate="visible"
        className="bg-card rounded-2xl shadow-card p-6"
      >
        <h2 className="font-display text-xl font-semibold mb-4">Past Recruitment Data</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-muted-foreground text-left border-b border-border">
                <th className="pb-3 font-medium">Year</th>
                <th className="pb-3 font-medium">Role</th>
                <th className="pb-3 font-medium">Package</th>
                <th className="pb-3 font-medium">Rounds</th>
                <th className="pb-3 font-medium">Hired</th>
              </tr>
            </thead>
            <tbody>
              {company.historicalData.map((row, i) => (
                <tr key={i} className="border-b border-border/50 hover:bg-primary/5 transition-colors">
                  <td className="py-3">{row.year}</td>
                  <td className="py-3">{row.role}</td>
                  <td className="py-3 font-medium">{row.package} LPA</td>
                  <td className="py-3">{row.rounds}</td>
                  <td className="py-3">{row.studentsHired}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Interview Process */}
      <motion.div
        variants={cardVariants}
        custom={2}
        initial="hidden"
        animate="visible"
        className="bg-card rounded-2xl shadow-card p-6"
      >
        <h2 className="font-display text-xl font-semibold mb-4">Interview Process</h2>
        <div className="relative pl-6">
          <div className="absolute left-[11px] top-2 bottom-2 w-0.5 bg-primary/20" />
          {company.interviewRounds.map((round, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.15, duration: 0.3 }}
              className="relative flex items-start gap-4 mb-6 last:mb-0"
            >
              <div className="absolute -left-6 w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-semibold z-10">
                {i + 1}
              </div>
              <div>
                <h4 className="font-medium">{round}</h4>
                <p className="text-xs text-muted-foreground mt-0.5">Round {i + 1} of {company.interviewRounds.length}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Selected Students */}
      <motion.div
        variants={cardVariants}
        custom={3}
        initial="hidden"
        animate="visible"
        className="bg-card rounded-2xl shadow-card p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl font-semibold">Students Selected</h2>
          <span className="bg-primary/10 text-primary px-3 py-1 rounded-lg text-sm font-medium">
            {company.selectedStudents.length}
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {company.selectedStudents.map((student, i) => (
            <div
              key={i}
              onClick={() => navigate('/alumni')}
              className="flex items-center gap-3 p-4 bg-muted rounded-xl cursor-pointer hover:bg-primary/5 transition-colors"
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold text-sm ${pastelColors[i % pastelColors.length]}`}>
                {student.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">{student.name}</p>
                <p className="text-xs text-muted-foreground">{student.role}</p>
              </div>
              <div className="text-right flex-shrink-0">
                <p className="text-xs text-ct-green font-medium">{student.package} LPA</p>
                <p className="text-xs text-muted-foreground">{student.year}</p>
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Reviews */}
      <motion.div
        variants={cardVariants}
        custom={4}
        initial="hidden"
        animate="visible"
        className="bg-card rounded-2xl shadow-card p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl font-semibold">Student Reviews</h2>
          <button
            onClick={() => setShowReviewModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2 border border-primary text-primary rounded-xl text-sm font-medium hover:bg-primary/5 transition-colors"
          >
            <PenLine className="w-4 h-4" /> Write a Review
          </button>
        </div>
        <div className="space-y-4">
          {company.reviews.map((review, i) => (
            <div key={i} className="p-4 bg-muted rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold text-xs ${pastelColors[i % pastelColors.length]}`}>
                    {review.studentName.split(' ').map(n => n[0]).join('')}
                  </div>
                  <span className="font-medium text-sm">{review.studentName}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-ct-secondary text-ct-secondary" />
                  <span className="text-sm font-medium">{review.rating}</span>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">{review.text}</p>
              <p className="text-xs text-muted-foreground mt-2">{review.date}</p>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Review Modal */}
      <Modal
        isOpen={showReviewModal}
        onClose={() => setShowReviewModal(false)}
        title="Write a Review"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Rating</label>
            <StarRating
              rating={reviewForm.rating}
              size={28}
              interactive
              onChange={(rating) => setReviewForm(prev => ({ ...prev, rating }))}
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Your Experience</label>
            <textarea
              value={reviewForm.experience}
              onChange={e => setReviewForm(prev => ({ ...prev, experience: e.target.value }))}
              placeholder="Share your interview experience..."
              rows={4}
              className="w-full px-4 py-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 resize-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Tips for Juniors</label>
            <textarea
              value={reviewForm.tips}
              onChange={e => setReviewForm(prev => ({ ...prev, tips: e.target.value }))}
              placeholder="Any advice for juniors preparing for this company?"
              rows={3}
              className="w-full px-4 py-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 resize-none"
            />
          </div>
          <button
            onClick={handleSubmitReview}
            className="w-full h-11 bg-primary text-primary-foreground rounded-xl font-medium text-sm hover:bg-ct-primary-hover transition-colors flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" /> Submit Review
          </button>
        </div>
      </Modal>
    </div>
  );
}

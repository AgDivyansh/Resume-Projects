import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  MapPin,
  IndianRupee,
  Building2,
  Clock,
  Filter,
  Check,
  Search,
  Briefcase,
} from 'lucide-react';
import {
  currentStudent,
  jobPostings,
  studentApplications,
  checkEligibility,
  type JobPosting,
} from '@/data';
import Modal from '@/components/ui/Modal';
import StarRating from '@/components/ui/StarRating';
import { useToast } from '@/contexts/ToastContext';

const cardVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.4, ease: 'easeOut' as const },
  }),
};

const locations = ['Bangalore', 'Hyderabad', 'Delhi', 'Chennai', 'Pune', 'Noida', 'Remote', 'Pan India'];
const industries = ['MNC / Tech', 'Startup / E-commerce', 'Fintech', 'MNC / IT Services', 'EdTech', 'Finance / Investment Banking', 'Fintech / Startup'];


export default function JobsPage() {
  const { addToast } = useToast();
  const [activeTab, setActiveTab] = useState<'all' | 'applied' | 'saved'>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedJob, setSelectedJob] = useState<JobPosting | null>(null);
  const [appliedJobIds, setAppliedJobIds] = useState<string[]>(
    studentApplications.map(a => a.jobId)
  );

  const [filters, setFilters] = useState({
    locations: [] as string[],
    minPackage: '',
    maxPackage: '',
    industries: [] as string[],
    roles: [] as string[],
    eligibleOnly: false,
  });

  const toggleFilter = (type: 'locations' | 'industries' | 'roles', value: string) => {
    setFilters(prev => ({
      ...prev,
      [type]: prev[type].includes(value)
        ? prev[type].filter(v => v !== value)
        : [...prev[type], value],
    }));
  };

  const filteredJobs = useMemo(() => {
    let jobs = jobPostings;

    if (activeTab === 'applied') {
      jobs = jobs.filter(j => appliedJobIds.includes(j.id));
    }

    if (filters.locations.length > 0) {
      jobs = jobs.filter(j =>
        filters.locations.some(loc => j.location.toLowerCase().includes(loc.toLowerCase()))
      );
    }
    if (filters.industries.length > 0) {
      jobs = jobs.filter(j => filters.industries.includes(j.industry));
    }
    if (filters.roles.length > 0) {
      jobs = jobs.filter(j => filters.roles.some(r => j.role.toLowerCase().includes(r.toLowerCase())));
    }
    if (filters.minPackage) {
      jobs = jobs.filter(j => j.packageMax >= Number(filters.minPackage));
    }
    if (filters.maxPackage) {
      jobs = jobs.filter(j => j.packageMin <= Number(filters.maxPackage));
    }
    if (filters.eligibleOnly) {
      jobs = jobs.filter(j => checkEligibility(currentStudent, j));
    }

    return jobs;
  }, [activeTab, filters, appliedJobIds]);

  const isApplied = (jobId: string) => appliedJobIds.includes(jobId);

  const handleApply = (job: JobPosting) => {
    if (!checkEligibility(currentStudent, job)) return;
    setAppliedJobIds(prev => [...prev, job.id]);
    addToast('success', `Applied to ${job.companyName} - ${job.role}`);
  };

  const getEligibilityReason = (job: JobPosting) => {
    const s = currentStudent;
    if (s.tenthPercentage < job.eligibility.minTenth) return `10th: ${s.tenthPercentage}% < ${job.eligibility.minTenth}%`;
    if (s.twelfthPercentage < job.eligibility.minTwelfth) return `12th: ${s.twelfthPercentage}% < ${job.eligibility.minTwelfth}%`;
    if (s.cgpa < job.eligibility.minCgpa) return `CGPA: ${s.cgpa} < ${job.eligibility.minCgpa}`;
    if (s.backlogs > job.eligibility.maxBacklogs) return `Backlogs: ${s.backlogs} > ${job.eligibility.maxBacklogs}`;
    if (!job.eligibility.branches.includes(s.branch)) return `Branch: ${s.branch} not allowed`;
    return 'Not eligible';
  };

  return (
    <div className="space-y-6">
      {/* Filter Bar */}
      <motion.div
        variants={cardVariants}
        initial="hidden"
        animate="visible"
        className="bg-card rounded-2xl shadow-card p-4"
      >
        <div className="flex flex-col sm:flex-row sm:items-center gap-4">
          {/* Tabs */}
          <div className="flex gap-1 p-1 bg-muted rounded-lg">
            {(['all', 'applied', 'saved'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                  activeTab === tab
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search jobs..."
              className="w-full h-10 pl-9 pr-4 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
            />
          </div>

          {/* Filter Button */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`inline-flex items-center gap-2 h-10 px-4 rounded-lg border text-sm font-medium transition-all duration-200 ${
              showFilters ? 'border-primary text-primary bg-primary/5' : 'border-border text-muted-foreground hover:text-foreground'
            }`}
          >
            <Filter className="w-4 h-4" />
            Filters
          </button>
        </div>

        {/* Filter Panel */}
        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="overflow-hidden"
            >
              <div className="pt-4 mt-4 border-t border-border space-y-4">
                {/* Location */}
                <div>
                  <p className="text-sm font-medium mb-2">Location</p>
                  <div className="flex flex-wrap gap-2">
                    {locations.map(loc => (
                      <button
                        key={loc}
                        onClick={() => toggleFilter('locations', loc)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                          filters.locations.includes(loc)
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted text-muted-foreground hover:text-foreground'
                        }`}
                      >
                        {loc}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Package */}
                <div>
                  <p className="text-sm font-medium mb-2">Package Range (LPA)</p>
                  <div className="flex gap-3 items-center">
                    <input
                      type="number"
                      placeholder="Min"
                      value={filters.minPackage}
                      onChange={e => setFilters(prev => ({ ...prev, minPackage: e.target.value }))}
                      className="w-24 h-9 px-3 rounded-lg border border-border bg-background text-sm focus:outline-none focus:border-primary"
                    />
                    <span className="text-muted-foreground">to</span>
                    <input
                      type="number"
                      placeholder="Max"
                      value={filters.maxPackage}
                      onChange={e => setFilters(prev => ({ ...prev, maxPackage: e.target.value }))}
                      className="w-24 h-9 px-3 rounded-lg border border-border bg-background text-sm focus:outline-none focus:border-primary"
                    />
                  </div>
                </div>

                {/* Industry */}
                <div>
                  <p className="text-sm font-medium mb-2">Industry</p>
                  <div className="flex flex-wrap gap-2">
                    {industries.map(ind => (
                      <button
                        key={ind}
                        onClick={() => toggleFilter('industries', ind)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                          filters.industries.includes(ind)
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted text-muted-foreground hover:text-foreground'
                        }`}
                      >
                        {ind}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Eligible Only */}
                <label className="flex items-center gap-2 cursor-pointer">
                  <div
                    onClick={() => setFilters(prev => ({ ...prev, eligibleOnly: !prev.eligibleOnly }))}
                    className={`w-9 h-5 rounded-full relative transition-colors cursor-pointer ${
                      filters.eligibleOnly ? 'bg-primary' : 'bg-muted'
                    }`}
                  >
                    <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${
                      filters.eligibleOnly ? 'translate-x-4' : 'translate-x-0.5'
                    }`} />
                  </div>
                  <span className="text-sm">Show only eligible jobs</span>
                </label>

                {/* Reset */}
                <button
                  onClick={() => setFilters({ locations: [], minPackage: '', maxPackage: '', industries: [], roles: [], eligibleOnly: false })}
                  className="text-sm text-primary hover:underline"
                >
                  Reset all filters
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Job Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {filteredJobs.map((job, i) => {
          const eligible = checkEligibility(currentStudent, job);
          const applied = isApplied(job.id);

          return (
            <motion.div
              key={job.id}
              custom={i}
              variants={cardVariants}
              initial="hidden"
              animate="visible"
              onClick={() => setSelectedJob(job)}
              className="bg-card rounded-2xl shadow-card p-6 cursor-pointer hover:shadow-card-hover hover:scale-[1.005] active:scale-[0.995] transition-all duration-250"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary font-semibold text-lg flex-shrink-0">
                  {job.companyName.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-semibold">{job.companyName}</h3>
                      <p className="text-sm text-muted-foreground">{job.role}</p>
                    </div>
                    <StarRating rating={job.rating} size={14} />
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mt-3">
                    <span className="inline-flex items-center gap-1 bg-primary/10 text-primary px-2.5 py-1 rounded-md text-xs font-medium">
                      <MapPin className="w-3 h-3" /> {job.location.split(',')[0]}
                    </span>
                    <span className="inline-flex items-center gap-1 bg-primary/10 text-primary px-2.5 py-1 rounded-md text-xs font-medium">
                      <IndianRupee className="w-3 h-3" /> {job.packageMin}-{job.packageMax} LPA
                    </span>
                    <span className="inline-flex items-center gap-1 bg-primary/10 text-primary px-2.5 py-1 rounded-md text-xs font-medium">
                      <Building2 className="w-3 h-3" /> {job.industry}
                    </span>
                  </div>

                  {/* Description */}
                  <p className="text-sm text-muted-foreground mt-3 line-clamp-2">{job.description}</p>

                  {/* Footer */}
                  <div className="flex items-center justify-between mt-4">
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {job.deadline}
                      </span>
                      <span>{job.applicationsCount} applied</span>
                    </div>

                    {/* Apply Button - Clicking this should NOT open the detail modal */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (applied) return;
                        if (eligible) handleApply(job);
                      }}
                      disabled={!eligible || applied}
                      title={!eligible ? getEligibilityReason(job) : applied ? 'Already applied' : 'Click to apply'}
                      className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
                        applied
                          ? 'bg-ct-green/10 text-ct-green cursor-default'
                          : eligible
                          ? 'bg-primary text-primary-foreground hover:bg-ct-primary-hover hover:-translate-y-px active:scale-[0.98]'
                          : 'border border-border text-muted-foreground opacity-45 cursor-not-allowed'
                      }`}
                    >
                      {applied ? (
                        <span className="flex items-center gap-1">
                          <Check className="w-4 h-4" /> Applied
                        </span>
                      ) : eligible ? (
                        'Apply Now'
                      ) : (
                        'Not Eligible'
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {filteredJobs.length === 0 && (
        <div className="text-center py-16">
          <Briefcase className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No jobs match your filters</p>
        </div>
      )}

      {/* Job Detail Modal */}
      <Modal
        isOpen={!!selectedJob}
        onClose={() => setSelectedJob(null)}
        title={selectedJob?.companyName}
        maxWidth="640px"
      >
        {selectedJob && (
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center text-primary font-semibold text-xl">
                {selectedJob.companyName.charAt(0)}
              </div>
              <div>
                <h3 className="font-semibold text-lg">{selectedJob.role}</h3>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <StarRating rating={selectedJob.rating} size={14} />
                  <span>({selectedJob.reviewCount} reviews)</span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <span className="inline-flex items-center gap-1 bg-primary/10 text-primary px-3 py-1.5 rounded-lg text-sm">
                <MapPin className="w-4 h-4" /> {selectedJob.location}
              </span>
              <span className="inline-flex items-center gap-1 bg-primary/10 text-primary px-3 py-1.5 rounded-lg text-sm">
                <IndianRupee className="w-4 h-4" /> {selectedJob.packageMin}-{selectedJob.packageMax} LPA
              </span>
              <span className="inline-flex items-center gap-1 bg-primary/10 text-primary px-3 py-1.5 rounded-lg text-sm">
                <Building2 className="w-4 h-4" /> {selectedJob.industry}
              </span>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Job Description</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">{selectedJob.description}</p>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Eligibility Criteria</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>10th: Minimum {selectedJob.eligibility.minTenth}%</li>
                <li>12th: Minimum {selectedJob.eligibility.minTwelfth}%</li>
                <li>CGPA: Minimum {selectedJob.eligibility.minCgpa}</li>
                <li>Max Backlogs: {selectedJob.eligibility.maxBacklogs}</li>
                <li>Branches: {selectedJob.eligibility.branches.join(', ')}</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Selection Process</h4>
              <div className="space-y-2">
                {selectedJob.rounds.map((round, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-semibold">
                      {i + 1}
                    </div>
                    <span className="text-sm">{round.name}</span>
                    <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded">{round.type}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-border">
              <div className="text-sm text-muted-foreground">
                Deadline: <span className="font-medium text-foreground">{selectedJob.deadline}</span>
              </div>
              <button
                onClick={() => {
                  if (!isApplied(selectedJob.id) && checkEligibility(currentStudent, selectedJob)) {
                    handleApply(selectedJob);
                    setSelectedJob(null);
                  }
                }}
                disabled={!checkEligibility(currentStudent, selectedJob) || isApplied(selectedJob.id)}
                className={`px-6 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                  isApplied(selectedJob.id)
                    ? 'bg-ct-green/10 text-ct-green'
                    : checkEligibility(currentStudent, selectedJob)
                    ? 'bg-primary text-primary-foreground hover:bg-ct-primary-hover'
                    : 'border border-border text-muted-foreground opacity-45 cursor-not-allowed'
                }`}
              >
                {isApplied(selectedJob.id) ? 'Applied' : checkEligibility(currentStudent, selectedJob) ? 'Apply Now' : 'Not Eligible'}
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

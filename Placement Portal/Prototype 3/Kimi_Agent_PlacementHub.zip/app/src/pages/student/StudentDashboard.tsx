import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Briefcase,
  CheckCircle,
  Calendar,
  ArrowRight,
  MapPin,
} from 'lucide-react';
import {
  currentStudent,
  jobPostings,
  studentApplications,
  weeklyActivityData,
  notifications,
  checkEligibility,
} from '@/data';
import Modal from '@/components/ui/Modal';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';

const cardVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.4, ease: 'easeOut' as const },
  }),
};

export default function StudentDashboard() {
  const navigate = useNavigate();
  const [selectedStat, setSelectedStat] = useState<string | null>(null);

  const appliedJobs = useMemo(() => {
    return studentApplications.map(app => {
      const job = jobPostings.find(j => j.id === app.jobId);
      return { ...app, job };
    }).filter(item => item.job);
  }, []);

  const eligibleJobs = useMemo(() => {
    return jobPostings.filter(job => checkEligibility(currentStudent, job));
  }, []);

  const upcomingDrives = useMemo(() => {
    return jobPostings.filter(job => {
      const deadline = new Date(job.deadline);
      const now = new Date();
      const diffDays = Math.ceil((deadline.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      return diffDays > 0 && diffDays <= 30;
    }).sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime());
  }, []);

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      applied: 'bg-primary/10 text-primary',
      under_review: 'bg-ct-orange/15 text-ct-orange',
      shortlisted: 'bg-ct-green/15 text-ct-green',
      rejected: 'bg-ct-red/15 text-ct-red',
      offer_received: 'bg-ct-green text-white',
    };
    const labels: Record<string, string> = {
      applied: 'Applied',
      under_review: 'Under Review',
      shortlisted: 'Shortlisted',
      rejected: 'Rejected',
      offer_received: 'Offer Received',
    };
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-md text-xs font-medium ${styles[status] || ''}`}>
        {labels[status] || status}
      </span>
    );
  };

  const stats = [
    {
      key: 'applied',
      label: 'Applied Jobs',
      value: appliedJobs.length,
      change: '+2 this week',
      icon: Briefcase,
      iconColor: 'text-primary',
      iconBg: 'bg-primary/10',
      changeColor: 'text-ct-green',
      data: appliedJobs,
    },
    {
      key: 'eligible',
      label: 'Eligible Jobs',
      value: eligibleJobs.length,
      change: '+5 new',
      icon: CheckCircle,
      iconColor: 'text-ct-green',
      iconBg: 'bg-ct-green/10',
      changeColor: 'text-ct-green',
      data: eligibleJobs,
    },
    {
      key: 'upcoming',
      label: 'Upcoming Drives',
      value: upcomingDrives.length,
      change: '3 this week',
      icon: Calendar,
      iconColor: 'text-ct-orange',
      iconBg: 'bg-ct-orange/10',
      changeColor: 'text-ct-orange',
      data: upcomingDrives,
    },
  ];

  const renderStatModalContent = () => {
    if (!selectedStat) return null;
    const stat = stats.find(s => s.key === selectedStat);
    if (!stat) return null;

    if (selectedStat === 'applied') {
      return (
        <div className="space-y-3 max-h-[60vh] overflow-y-auto">
          {appliedJobs.map((item) => (
            <div
              key={item.id}
              onClick={() => { setSelectedStat(null); navigate(`/jobs`); }}
              className="flex items-center gap-3 p-3 rounded-xl hover:bg-primary/5 cursor-pointer transition-colors"
            >
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold text-sm flex-shrink-0">
                {item.job?.companyName.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">{item.job?.companyName}</p>
                <p className="text-xs text-muted-foreground truncate">{item.job?.role}</p>
              </div>
              {getStatusBadge(item.status)}
              <span className="text-xs text-muted-foreground">{item.appliedDate}</span>
            </div>
          ))}
        </div>
      );
    }

    if (selectedStat === 'eligible') {
      return (
        <div className="space-y-3 max-h-[60vh] overflow-y-auto">
          {eligibleJobs.map((job) => (
            <div
              key={job.id}
              onClick={() => { setSelectedStat(null); navigate('/jobs'); }}
              className="flex items-center gap-3 p-3 rounded-xl hover:bg-primary/5 cursor-pointer transition-colors"
            >
              <div className="w-10 h-10 rounded-full bg-ct-green/10 flex items-center justify-center text-ct-green font-semibold text-sm flex-shrink-0">
                {job.companyName.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">{job.companyName}</p>
                <p className="text-xs text-muted-foreground truncate">{job.role}</p>
              </div>
              <span className="text-xs text-ct-green font-medium">Eligible</span>
            </div>
          ))}
        </div>
      );
    }

    if (selectedStat === 'upcoming') {
      return (
        <div className="space-y-3 max-h-[60vh] overflow-y-auto">
          {upcomingDrives.map((job) => (
            <div
              key={job.id}
              onClick={() => { setSelectedStat(null); navigate('/jobs'); }}
              className="flex items-center gap-3 p-3 rounded-xl hover:bg-primary/5 cursor-pointer transition-colors"
            >
              <div className="w-10 h-10 rounded-full bg-ct-orange/10 flex items-center justify-center text-ct-orange font-semibold text-sm flex-shrink-0">
                {job.companyName.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">{job.companyName}</p>
                <p className="text-xs text-muted-foreground truncate">{job.role}</p>
              </div>
              <span className="text-xs text-ct-orange font-medium">{job.deadline}</span>
            </div>
          ))}
        </div>
      );
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <motion.div
        custom={0}
        variants={cardVariants}
        initial="hidden"
        animate="visible"
        className="bg-gradient-to-r from-primary/10 to-primary/5 rounded-2xl p-6 lg:p-8"
      >
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h2 className="font-display text-2xl lg:text-3xl font-bold mb-1">
              Welcome back, {currentStudent.name.split(' ')[0]}!
            </h2>
            <p className="text-muted-foreground">You have {upcomingDrives.length} upcoming drives this week.</p>
          </div>
          <div className="flex gap-3">
            {[
              { label: `${appliedJobs.length} Applied`, color: 'bg-primary' },
              { label: `${eligibleJobs.length} Eligible`, color: 'bg-ct-green' },
              { label: `${upcomingDrives.length} Upcoming`, color: 'bg-ct-orange' },
            ].map(stat => (
              <span key={stat.label} className="inline-flex items-center gap-1.5 bg-card px-3 py-1.5 rounded-lg text-xs font-medium shadow-sm">
                <span className={`w-2 h-2 rounded-full ${stat.color}`} />
                {stat.label}
              </span>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.key}
            custom={i + 1}
            variants={cardVariants}
            initial="hidden"
            animate="visible"
            onClick={() => setSelectedStat(stat.key)}
            className="bg-card rounded-2xl shadow-card p-6 cursor-pointer hover:shadow-card-hover hover:scale-[1.005] active:scale-[0.995] transition-all duration-250"
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`w-10 h-10 rounded-xl ${stat.iconBg} flex items-center justify-center`}>
                <stat.icon className={`w-5 h-5 ${stat.iconColor}`} />
              </div>
              <span className={`text-xs font-medium ${stat.changeColor}`}>{stat.change}</span>
            </div>
            <p className="text-muted-foreground text-sm">{stat.label}</p>
            <p className="font-display text-4xl font-bold mt-1">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Applications List */}
      <motion.div
        custom={4}
        variants={cardVariants}
        initial="hidden"
        animate="visible"
      >
        <h3 className="font-display text-xl font-semibold mb-4">Your Applications</h3>
        <div className="space-y-3">
          {appliedJobs.map((item, i) => (
            <motion.div
              key={item.id}
              custom={i + 5}
              variants={cardVariants}
              initial="hidden"
              animate="visible"
              onClick={() => navigate('/jobs')}
              className="bg-card rounded-2xl shadow-card p-5 flex items-center gap-4 cursor-pointer hover:shadow-card-hover transition-all duration-250 group"
            >
              <div className="w-11 h-11 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold flex-shrink-0">
                {item.job?.companyName.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-sm">{item.job?.companyName}</h4>
                <p className="text-muted-foreground text-sm truncate">{item.job?.role}</p>
                <p className="text-muted-foreground text-xs flex items-center gap-1 mt-0.5">
                  <MapPin className="w-3 h-3" /> {item.job?.location}
                </p>
              </div>
              <div className="flex items-center gap-3 flex-shrink-0">
                {getStatusBadge(item.status)}
                <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:translate-x-1 transition-transform" />
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Weekly Activity + Notifications */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          custom={9}
          variants={cardVariants}
          initial="hidden"
          animate="visible"
          className="bg-card rounded-2xl shadow-card p-6"
        >
          <h3 className="font-display text-xl font-semibold mb-4">Weekly Activity</h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={weeklyActivityData} barSize={32}>
              <XAxis
                dataKey="day"
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
              />
              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }}
                allowDecimals={false}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '12px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                  fontSize: '13px',
                }}
              />
              <Bar dataKey="count" radius={[8, 8, 0, 0]}>
                {weeklyActivityData.map((_, index) => (
                  <Cell key={`cell-${index}`} fill="hsl(var(--primary) / 0.8)" />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div
          custom={10}
          variants={cardVariants}
          initial="hidden"
          animate="visible"
          className="bg-card rounded-2xl shadow-card p-6"
        >
          <h3 className="font-display text-xl font-semibold mb-4">Recent Updates</h3>
          <div className="space-y-4">
            {notifications.map(notif => (
              <div key={notif.id} className="flex items-start gap-3">
                <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                  notif.type === 'shortlist' ? 'bg-ct-green' :
                  notif.type === 'deadline' ? 'bg-ct-orange' :
                  notif.type === 'new_job' ? 'bg-primary' :
                  'bg-ct-secondary'
                }`} />
                <div className="flex-1">
                  <p className="text-sm">{notif.message}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{notif.time}</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Stat Detail Modal */}
      <Modal
        isOpen={!!selectedStat}
        onClose={() => setSelectedStat(null)}
        title={stats.find(s => s.key === selectedStat)?.label}
      >
        {renderStatModalContent()}
      </Modal>
    </div>
  );
}

# CareerTrack — Technical Specification

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| react | ^19.0.0 | UI framework |
| react-dom | ^19.0.0 | React DOM renderer |
| react-router-dom | ^7.0.0 | Client-side routing with route guards |
| framer-motion | ^12.0.0 | Animations, gestures, AnimatePresence for modals |
| recharts | ^2.15.0 | Admin analytics charts (Area, Bar, Pie) |
| lucide-react | ^0.460.0 | Icon library |
| tailwindcss | ^3.4.0 | Utility-first CSS |
| postcss | ^8.4.0 | CSS processing |
| autoprefixer | ^10.4.0 | CSS vendor prefixes |
| typescript | ^5.6.0 | Type safety |
| @types/react | ^19.0.0 | React type definitions |
| @types/react-dom | ^19.0.0 | ReactDOM type definitions |
| vite | ^6.0.0 | Build tool |
| @vitejs/plugin-react | ^4.0.0 | Vite React plugin |

## Component Inventory

### Layout Components

| Component | Source | Reuse |
|-----------|--------|-------|
| Sidebar | Custom | Shared — desktop nav, role-aware items |
| MobileNav | Custom | Shared — bottom tab bar on mobile |
| TopBar | Custom | Shared — page title + actions |
| AppShell | Custom | Shared — wraps Sidebar + TopBar + content |

### Page Components (Student)

| Component | Route |
|-----------|-------|
| LoginPage | / |
| StudentDashboard | /dashboard |
| JobsPage | /jobs |
| JobDetailSheet | Modal triggered from JobsPage |
| CompaniesPage | /companies |
| CompanyDetailPage | /companies/:id |
| AlumniConnectPage | /alumni |
| StudentProfilePage | /profile |

### Page Components (Admin)

| Component | Route |
|-----------|-------|
| AdminDashboard | /admin |
| JobManagementPage | /admin/jobs |
| CreateJobModal | Modal triggered from JobManagementPage |
| StudentsManagementPage | /admin/students |
| AdminProfilePage | /admin/profile |

### Reusable Components

| Component | Source | Used By |
|-----------|--------|---------|
| Card | Custom | Dashboard, Jobs, Companies — all card surfaces |
| StatCard | Custom | Dashboard stat rows, Admin dashboard |
| Badge | Custom | Status indicators, tags, industry labels |
| Button | Custom | All pages — primary, outline, ghost, disabled states |
| Input | Custom | Forms, search, OTP inputs |
| Modal | Custom + framer-motion | OTP, Job Detail, Call Request, Delete Confirm, Review Form |
| BottomSheet | Custom + framer-motion | Mobile modal alternative |
| Toast | Custom + framer-motion | Global toast notifications |
| Avatar | Custom | Alumni list, student cards, profile |
| StarRating | Custom | Company ratings, review display |
| Timeline | Custom | Company interview rounds |
| OTPInput | Custom | 6-digit OTP verification |
| DataTable | Custom | Admin job/student tables |
| FilterPanel | Custom | Jobs page filters |
| DarkModeToggle | Custom | Sidebar bottom |
| EmptyState | Custom | Chat empty state |
| CallRequestModal | Custom | Alumni connect call scheduling |

### Chart Components (Admin Analytics)

| Component | Source |
|-----------|--------|
| PlacementTrendChart | Recharts AreaChart |
| CompanyPlacementsChart | Recharts horizontal BarChart |
| BranchDistributionChart | Recharts PieChart (donut) |
| PackageDistributionChart | Recharts vertical BarChart |

## Animation Implementation

| Animation | Library | Implementation | Complexity |
|-----------|---------|----------------|------------|
| Login hero SVG float | CSS keyframes | translateY(-8px↔8px), 4s ease-in-out, staggered delays per element | Low |
| Login mesh gradient | CSS keyframes | 3 absolutely-positioned gradient blobs, animate position+scale, 12s cycle | Low |
| Login card slide-in | framer-motion | initial={{x:40,opacity:0}} animate={{x:0,opacity:1}} transition={{duration:0.5,delay:0.2}} | Low |
| Card entrance stagger | framer-motion | staggerChildren:0.06 on container, children: initial={{y:16,opacity:0}} | Medium |
| Modal enter/exit | framer-motion AnimatePresence | backdrop: opacity 0→1 200ms; content: scale(0.95→1) + opacity, spring | Medium |
| Toast slide | framer-motion | enter: translateX(120%→0) 400ms ease-out; exit: translateX(0→120%) 300ms ease-in | Low |
| Bottom sheet (mobile) | framer-motion | slide up from bottom, 300ms spring | Low |
| Button hover/active | CSS transitions | hover: translateY(-1px) 200ms; active: scale(0.98) 100ms | Low |
| Nav active indicator | framer-motion layoutId | layoutId="activeNav" on pill element, auto-transitions between items | Low |
| Status badge pulse | CSS keyframes | box-shadow expand+fade, scale 1→1.05→1, 2s infinite | Low |
| OTP input auto-focus | React ref | onInput: focus next ref; onBackspace: focus previous ref | Medium |
| Message slide-in | framer-motion | sent: translateX(20→0); received: translateX(-20→0), 300ms spring | Low |
| Chart bar hover | Recharts | Cell fill opacity transition, 150ms | Low |

## State & Logic Plan

### Global State (React Context)

1. **AuthContext**
   - user: { id, name, email, role } | null
   - login(email, password): validates against hardcoded creds, persists to localStorage
   - logout(): clears localStorage, redirects to /
   - isStudent(): boolean
   - isAdmin(): boolean

2. **ThemeContext**
   - theme: "light" | "dark"
   - toggleTheme(): toggles, persists to localStorage
   - Applies data-theme attribute to HTML element

3. **ToastContext**
   - toasts: array of { id, type, message }
   - addToast(type, message): adds toast with auto-dismiss after 4s
   - removeToast(id): manual dismiss

### Local State (useState/useReducer per page)

1. **StudentDashboard**
   - selectedStatCard: "applied" | "eligible" | "upcoming" | null
   - showStatModal: boolean
   - weeklyActivityData: static array for chart

2. **JobsPage**
   - activeTab: "all" | "applied" | "saved"
   - showFilters: boolean
   - filters: { locations[], packageMin, packageMax, roles[], industries[], eligibleOnly }
   - selectedJob: Job | null (for detail modal)
   - appliedJobIds: string[] (from student applications)

3. **CompaniesPage**
   - searchQuery: string
   - selectedCompany: Company | null

4. **CompanyDetailPage**
   - showReviewModal: boolean
   - reviewForm: { rating, experience, tips }

5. **AlumniConnectPage**
   - selectedAlumniId: string | null
   - messageInput: string
   - messages: Message[] (localStorage-backed)
   - showCallRequestModal: boolean
   - callRequestForm: { type, date, time, message }

6. **Admin JobManagement**
   - showCreateModal: boolean
   - createTab: "basic" | "eligibility" | "process"
   - jobForm: full job creation form state
   - deleteConfirmId: string | null
   - searchQuery: string
   - currentPage: number

7. **Profile Pages**
   - editingField: "email" | "phone" | null
   - showOTPModal: boolean
   - otpValue: string
   - formData: user profile fields

### Data Flow

- All mock data imported from `src/data/` as static TS exports
- Application state (applied jobs, messages, call requests) stored in localStorage
- On mount: load from localStorage if present, else initialize from mock data
- On mutation: update localStorage to persist across soft refreshes
- OTP flow: simulated — any 6-digit input succeeds
- Eligibility: computed via `checkEligibility(student, job)` helper on render
- Role-based routing: Route guards check auth context, redirect unauthorized

### Routing Structure

```
/                    → LoginPage (public)
/dashboard           → StudentDashboard (student only)
/jobs                → JobsPage (student only)
/companies           → CompaniesPage (student only)
/companies/:id       → CompanyDetailPage (student only)
/alumni              → AlumniConnectPage (student only)
/profile             → StudentProfilePage (student only)
/admin               → AdminDashboard (admin only)
/admin/jobs          → JobManagementPage (admin only)
/admin/students      → StudentsManagementPage (admin only)
/admin/profile       → AdminProfilePage (admin only)
```

## Other Key Decisions

- **CSS Custom Properties for theming**: All color tokens defined as CSS variables on :root and [data-theme="dark"]. Components reference var(--color-primary) etc. This avoids prop-drilling theme or complex context usage in styled components.
- **No shadcn/ui**: The design.md specifies custom components with precise styling. shadcn components would require heavy override. Custom components with Tailwind are simpler and match the design exactly.
- **Charts lazy-loaded**: Recharts is a heavy dependency. Import chart components via React.lazy() so they're only loaded on admin analytics pages.
- **Mobile-first responsive**: All layouts designed for 375px first, then expand. Bottom sheet used instead of modal on mobile. Tables convert to card lists.
- **localStorage as "database"**: Application mutations (apply, chat, schedule call, create job) persist to localStorage. Full reset on hard refresh by design — this is a demo/frontend-only app.

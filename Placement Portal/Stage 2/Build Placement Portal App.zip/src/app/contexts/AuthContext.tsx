import { createContext, useContext, useState, useEffect } from "react";

export type UserRole = "student" | "admin";

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  rollNo?: string;
  cgpa?: number;
  tenth?: number;
  twelfth?: number;
  resume?: string;
  profileComplete?: number;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for demo
const mockUsers: Record<string, User> = {
  "divyansh@gmail.com": {
    id: "1",
    name: "Divyansh Kumar",
    email: "divyansh@gmail.com",
    role: "student",
    phone: "+91 98765 43210",
    rollNo: "2021CSE001",
    cgpa: 8.5,
    tenth: 92,
    twelfth: 88,
    resume: "resume_divyansh.pdf",
    profileComplete: 85,
  },
  "divyansh@admin.com": {
    id: "2",
    name: "Admin User",
    email: "divyansh@admin.com",
    role: "admin",
    phone: "+91 98765 00000",
  },
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem("user");
    return saved ? JSON.parse(saved) : null;
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem("user", JSON.stringify(user));
    } else {
      localStorage.removeItem("user");
    }
  }, [user]);

  const login = async (email: string, password: string) => {
    // Mock login - in real app, this would call API
    await new Promise((resolve) => setTimeout(resolve, 500));

    const mockUser = mockUsers[email];
    if (mockUser && password === "password") {
      setUser(mockUser);
    } else {
      throw new Error("Invalid credentials");
    }
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        isAuthenticated: !!user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return context;
}

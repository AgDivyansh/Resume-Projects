import { mockAnalytics } from "../../services/mockData";
import { Card } from "../../components/ui/card";
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { TrendingUp, Users, Award, Briefcase } from "lucide-react";
import { motion } from "motion/react";

const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444"];

export function AnalyticsPage() {
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-zinc-900 dark:text-white mb-2">
          Analytics Dashboard
        </h1>
        <p className="text-zinc-600 dark:text-zinc-400">
          Insights and trends from placement data
        </p>
      </div>

      {/* Stats Overview */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 md:grid-cols-4 gap-4"
      >
        <motion.div variants={itemVariants}>
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-950 flex items-center justify-center">
                <Users className="w-5 h-5 text-blue-600" />
              </div>
              <h3 className="text-sm text-zinc-600 dark:text-zinc-400">
                Total Applications
              </h3>
            </div>
            <p className="text-3xl font-bold text-zinc-900 dark:text-white">
              {mockAnalytics.totalApplications}
            </p>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-green-100 dark:bg-green-950 flex items-center justify-center">
                <Briefcase className="w-5 h-5 text-green-600" />
              </div>
              <h3 className="text-sm text-zinc-600 dark:text-zinc-400">Active Jobs</h3>
            </div>
            <p className="text-3xl font-bold text-zinc-900 dark:text-white">
              {mockAnalytics.totalJobs}
            </p>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-violet-100 dark:bg-violet-950 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-violet-600" />
              </div>
              <h3 className="text-sm text-zinc-600 dark:text-zinc-400">
                Selection Rate
              </h3>
            </div>
            <p className="text-3xl font-bold text-zinc-900 dark:text-white">
              {mockAnalytics.selectionRate}%
            </p>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg bg-amber-100 dark:bg-amber-950 flex items-center justify-center">
                <Award className="w-5 h-5 text-amber-600" />
              </div>
              <h3 className="text-sm text-zinc-600 dark:text-zinc-400">
                Avg Package
              </h3>
            </div>
            <p className="text-3xl font-bold text-zinc-900 dark:text-white">
              {mockAnalytics.avgPackage}
            </p>
          </Card>
        </motion.div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Trends */}
        <Card className="p-6">
          <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-6">
            Monthly Application Trends
          </h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={mockAnalytics.monthlyTrends}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="month" stroke="#71717a" />
              <YAxis stroke="#71717a" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#ffffff",
                  border: "1px solid #e5e7eb",
                  borderRadius: "8px",
                }}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="applications"
                stroke="#3b82f6"
                strokeWidth={2}
                name="Applications"
              />
              <Line
                type="monotone"
                dataKey="selections"
                stroke="#10b981"
                strokeWidth={2}
                name="Selections"
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Company Performance */}
        <Card className="p-6">
          <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-6">
            Company-wise Applications
          </h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={mockAnalytics.companyTrends}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="company" stroke="#71717a" />
              <YAxis stroke="#71717a" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#ffffff",
                  border: "1px solid #e5e7eb",
                  borderRadius: "8px",
                }}
              />
              <Legend />
              <Bar dataKey="applicants" fill="#3b82f6" name="Applicants" />
              <Bar dataKey="selected" fill="#10b981" name="Selected" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Branch Distribution */}
        <Card className="p-6">
          <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-6">
            Branch-wise Applications
          </h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={mockAnalytics.branchWise}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={(entry) => `${entry.branch}: ${entry.applications}`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="applications"
              >
                {mockAnalytics.branchWise.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "#ffffff",
                  border: "1px solid #e5e7eb",
                  borderRadius: "8px",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        {/* Branch Performance Table */}
        <Card className="p-6">
          <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-6">
            Branch Performance
          </h2>
          <div className="space-y-4">
            {mockAnalytics.branchWise.map((branch, index) => (
              <div key={branch.branch}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    />
                    <span className="font-medium text-zinc-900 dark:text-white">
                      {branch.branch}
                    </span>
                  </div>
                  <div className="flex gap-6 text-sm">
                    <div>
                      <span className="text-zinc-500">Applied:</span>{" "}
                      <span className="font-semibold text-zinc-900 dark:text-white">
                        {branch.applications}
                      </span>
                    </div>
                    <div>
                      <span className="text-zinc-500">Selected:</span>{" "}
                      <span className="font-semibold text-green-600">
                        {branch.selected}
                      </span>
                    </div>
                    <div>
                      <span className="text-zinc-500">Rate:</span>{" "}
                      <span className="font-semibold text-blue-600">
                        {((branch.selected / branch.applications) * 100).toFixed(1)}%
                      </span>
                    </div>
                  </div>
                </div>
                <div className="h-2 bg-zinc-200 dark:bg-zinc-800 rounded-full overflow-hidden">
                  <div
                    className="h-full transition-all"
                    style={{
                      width: `${(branch.selected / branch.applications) * 100}%`,
                      backgroundColor: COLORS[index % COLORS.length],
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

import { mockJobs, mockAnalytics } from "../../services/mockData";
import { Card } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Link } from "react-router";
import {
  Users,
  Briefcase,
  TrendingUp,
  Award,
  ArrowRight,
  Eye,
} from "lucide-react";
import { motion } from "motion/react";

export function AdminDashboard() {
  const recentJobs = mockJobs.slice(0, 5);

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-zinc-900 dark:text-white mb-2">
          Admin Dashboard
        </h1>
        <p className="text-zinc-600 dark:text-zinc-400">
          Placement overview and management
        </p>
      </div>

      {/* Stats Grid */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        <motion.div variants={itemVariants}>
          <Card className="p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-950 flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
            <h3 className="text-2xl font-bold text-zinc-900 dark:text-white">
              {mockAnalytics.totalApplications}
            </h3>
            <p className="text-sm text-zinc-600 dark:text-zinc-400">
              Total Applications
            </p>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center">
                <Briefcase className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
              </div>
            </div>
            <h3 className="text-2xl font-bold text-zinc-900 dark:text-white">
              {mockAnalytics.totalJobs}
            </h3>
            <p className="text-sm text-zinc-600 dark:text-zinc-400">Active Jobs</p>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-violet-100 dark:bg-violet-950 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-violet-600 dark:text-violet-400" />
              </div>
            </div>
            <h3 className="text-2xl font-bold text-zinc-900 dark:text-white">
              {mockAnalytics.selectionRate}%
            </h3>
            <p className="text-sm text-zinc-600 dark:text-zinc-400">Selection Rate</p>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-amber-100 dark:bg-amber-950 flex items-center justify-center">
                <Award className="w-6 h-6 text-amber-600 dark:text-amber-400" />
              </div>
            </div>
            <h3 className="text-2xl font-bold text-zinc-900 dark:text-white">
              {mockAnalytics.avgPackage}
            </h3>
            <p className="text-sm text-zinc-600 dark:text-zinc-400">Avg Package</p>
          </Card>
        </motion.div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Jobs */}
        <div className="lg:col-span-2">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-zinc-900 dark:text-white">
                Recent Jobs
              </h2>
              <Link to="/admin/jobs">
                <Button variant="ghost" size="sm">
                  View All <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>

            <div className="space-y-3">
              {recentJobs.map((job, index) => (
                <motion.div
                  key={job.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="p-4 bg-zinc-50 dark:bg-zinc-900 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="text-3xl">{job.logo}</div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-zinc-900 dark:text-white">
                          {job.company}
                        </h3>
                        <span className="text-sm text-zinc-500">·</span>
                        <span className="text-sm text-zinc-600 dark:text-zinc-400">
                          {job.role}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-zinc-500">
                        <span>{job.applicants} applicants</span>
                        <span>{job.selected} selected</span>
                        <span>Deadline: {new Date(job.deadline).toLocaleDateString()}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-zinc-900 dark:text-white">
                        {job.package}
                      </p>
                      <Button variant="ghost" size="sm">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </Card>
        </div>

        {/* Quick Stats */}
        <div className="space-y-6">
          <Card className="p-6">
            <h3 className="font-semibold text-zinc-900 dark:text-white mb-4">
              Branch-wise Performance
            </h3>
            <div className="space-y-3">
              {mockAnalytics.branchWise.map((branch) => (
                <div key={branch.branch}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-zinc-600 dark:text-zinc-400">
                      {branch.branch}
                    </span>
                    <span className="text-sm font-medium text-zinc-900 dark:text-white">
                      {branch.selected}/{branch.applications}
                    </span>
                  </div>
                  <div className="h-2 bg-zinc-200 dark:bg-zinc-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-teal-500"
                      style={{
                        width: `${(branch.selected / branch.applications) * 100}%`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/20 dark:to-teal-950/20">
            <h3 className="font-semibold text-zinc-900 dark:text-white mb-2">
              View Analytics
            </h3>
            <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4">
              Get detailed insights on placement trends and performance
            </p>
            <Link to="/admin/analytics">
              <Button className="w-full bg-emerald-600 hover:bg-emerald-700">
                View Dashboard <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </Card>
        </div>
      </div>
    </div>
  );
}

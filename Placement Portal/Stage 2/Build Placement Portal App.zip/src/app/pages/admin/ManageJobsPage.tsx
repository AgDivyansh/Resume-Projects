import { useState } from "react";
import { mockJobs } from "../../services/mockData";
import { Card } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Badge } from "../../components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../../components/ui/dialog";
import { Plus, Edit, Trash2, Users, Calendar } from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner";

export function ManageJobsPage() {
  const [jobs] = useState(mockJobs);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleCreateJob = () => {
    toast.success("Job created successfully!");
    setIsDialogOpen(false);
  };

  const handleDelete = (jobId: string) => {
    toast.success("Job deleted successfully!");
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-zinc-900 dark:text-white mb-2">
            Manage Jobs
          </h1>
          <p className="text-zinc-600 dark:text-zinc-400">
            Create and manage placement opportunities
          </p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <Plus className="w-4 h-4 mr-2" />
              Create Job
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Job</DialogTitle>
            </DialogHeader>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleCreateJob();
              }}
              className="space-y-4"
            >
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="company">Company Name</Label>
                  <Input id="company" required />
                </div>
                <div>
                  <Label htmlFor="role">Role</Label>
                  <Input id="role" required />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="package">Package</Label>
                  <Input id="package" placeholder="e.g., ₹12 LPA" required />
                </div>
                <div>
                  <Label htmlFor="location">Location</Label>
                  <Input id="location" required />
                </div>
              </div>

              <div>
                <Label htmlFor="industry">Industry</Label>
                <Input id="industry" required />
              </div>

              <div>
                <Label htmlFor="jd">Job Description</Label>
                <textarea
                  id="jd"
                  className="w-full min-h-[100px] px-3 py-2 bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-md"
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="tenth">Min 10th %</Label>
                  <Input id="tenth" type="number" required />
                </div>
                <div>
                  <Label htmlFor="twelfth">Min 12th %</Label>
                  <Input id="twelfth" type="number" required />
                </div>
                <div>
                  <Label htmlFor="cgpa">Min CGPA</Label>
                  <Input id="cgpa" type="number" step="0.01" required />
                </div>
              </div>

              <div>
                <Label htmlFor="deadline">Application Deadline</Label>
                <Input id="deadline" type="date" required />
              </div>

              <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700">
                Create Job
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Jobs List */}
      <div className="space-y-4">
        {jobs.map((job, index) => (
          <motion.div
            key={job.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-6">
                <div className="text-5xl">{job.logo}</div>

                <div className="flex-1">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="text-xl font-bold text-zinc-900 dark:text-white mb-1">
                        {job.company}
                      </h3>
                      <p className="text-zinc-600 dark:text-zinc-400">{job.role}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(job.id)}
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge variant="secondary">{job.industry}</Badge>
                    <Badge variant="secondary">{job.location}</Badge>
                    <Badge className="bg-green-500 text-white border-none">
                      {job.package}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="w-4 h-4 text-blue-600" />
                      <span className="text-zinc-600 dark:text-zinc-400">
                        {job.applicants} applicants
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="w-4 h-4 text-green-600" />
                      <span className="text-zinc-600 dark:text-zinc-400">
                        {job.selected} selected
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="w-4 h-4 text-orange-600" />
                      <span className="text-zinc-600 dark:text-zinc-400">
                        Deadline: {new Date(job.deadline).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  <div className="p-3 bg-zinc-50 dark:bg-zinc-900 rounded-lg">
                    <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-2">
                      Eligibility Criteria
                    </p>
                    <div className="flex flex-wrap gap-3 text-sm">
                      <span className="text-zinc-900 dark:text-white">
                        10th: ≥{job.eligibility.tenth}%
                      </span>
                      <span className="text-zinc-900 dark:text-white">
                        12th: ≥{job.eligibility.twelfth}%
                      </span>
                      <span className="text-zinc-900 dark:text-white">
                        CGPA: ≥{job.eligibility.cgpa}
                      </span>
                      <span className="text-zinc-900 dark:text-white">
                        Branches: {job.eligibility.branches.join(", ")}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

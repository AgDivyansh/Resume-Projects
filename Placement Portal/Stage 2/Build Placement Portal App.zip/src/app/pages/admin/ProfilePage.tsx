import { useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { Card } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Badge } from "../../components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "../../components/ui/dialog";
import { User, Mail, Phone, Shield, Edit2, Check } from "lucide-react";
import { toast } from "sonner";

export function AdminProfilePage() {
  const { user } = useAuth();
  const [editing, setEditing] = useState(false);
  const [showOTPDialog, setShowOTPDialog] = useState(false);
  const [fieldToEdit, setFieldToEdit] = useState<string | null>(null);
  const [otp, setOtp] = useState("");

  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    phone: user?.phone || "",
  });

  const [tempValue, setTempValue] = useState("");

  const handleEditField = (field: string) => {
    setFieldToEdit(field);
    setTempValue(formData[field as keyof typeof formData] || "");
    setShowOTPDialog(true);
    // Simulate sending OTP
    toast.info("OTP sent to your registered email/phone");
  };

  const handleVerifyOTP = () => {
    // Mock OTP verification
    if (otp === "123456" || otp.length === 6) {
      if (fieldToEdit) {
        setFormData({
          ...formData,
          [fieldToEdit]: tempValue,
        });
      }
      setShowOTPDialog(false);
      setOtp("");
      setFieldToEdit(null);
      toast.success("Field updated successfully!");
    } else {
      toast.error("Invalid OTP. Try 123456 for demo");
    }
  };

  return (
    <div className="p-4 sm:p-6 space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-zinc-900 dark:text-white mb-2">
          Admin Profile
        </h1>
        <p className="text-sm sm:text-base text-zinc-600 dark:text-zinc-400">
          Manage your admin account information
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Info */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-4 sm:p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg sm:text-xl font-bold text-zinc-900 dark:text-white">
                Personal Information
              </h2>
              <Badge className="bg-emerald-500 text-white border-none">
                <Shield className="w-3 h-3 mr-1" />
                Admin
              </Badge>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Full Name</Label>
                <div className="flex gap-2">
                  <Input id="name" value={formData.name} disabled className="flex-1" />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEditField("name")}
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div>
                <Label htmlFor="email">Email Address</Label>
                <div className="flex gap-2">
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    disabled
                    className="flex-1"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEditField("email")}
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-zinc-500 mt-1">
                  Changing email requires OTP verification
                </p>
              </div>

              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <div className="flex gap-2">
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    disabled
                    className="flex-1"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEditField("phone")}
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-zinc-500 mt-1">
                  Changing phone requires OTP verification
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-4 sm:p-6 bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/20 dark:to-teal-950/20">
            <h3 className="font-semibold text-zinc-900 dark:text-white mb-2">
              Security Notice
            </h3>
            <ul className="space-y-2 text-xs sm:text-sm text-zinc-600 dark:text-zinc-400">
              <li className="flex items-start gap-2">
                <span className="text-emerald-600">•</span>
                All profile changes require OTP verification
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-600">•</span>
                OTP will be sent to your registered email/phone
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-600">•</span>
                For demo purposes, use OTP: 123456
              </li>
            </ul>
          </Card>
        </div>

        {/* Profile Summary Sidebar */}
        <div className="space-y-6">
          <Card className="p-6">
            <div className="text-center mb-6">
              <div className="w-24 h-24 mx-auto mb-3 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center text-white text-3xl font-bold">
                {formData.name.charAt(0)}
              </div>
              <h3 className="text-lg font-bold text-zinc-900 dark:text-white">
                {formData.name}
              </h3>
              <Badge className="mt-2 bg-emerald-500 text-white border-none">
                <Shield className="w-3 h-3 mr-1" />
                Administrator
              </Badge>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm">
                <Mail className="w-4 h-4 text-zinc-400" />
                <span className="text-zinc-600 dark:text-zinc-400 truncate">
                  {formData.email}
                </span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <Phone className="w-4 h-4 text-zinc-400" />
                <span className="text-zinc-600 dark:text-zinc-400">
                  {formData.phone || "Not provided"}
                </span>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="font-semibold text-zinc-900 dark:text-white mb-4">
              Admin Permissions
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-600" />
                <span className="text-zinc-600 dark:text-zinc-400">
                  Manage Jobs
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-600" />
                <span className="text-zinc-600 dark:text-zinc-400">
                  View Analytics
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-600" />
                <span className="text-zinc-600 dark:text-zinc-400">
                  Manage Applications
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-600" />
                <span className="text-zinc-600 dark:text-zinc-400">
                  Update Statuses
                </span>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* OTP Verification Dialog */}
      <Dialog open={showOTPDialog} onOpenChange={setShowOTPDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Verify OTP</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="tempValue">New Value</Label>
              <Input
                id="tempValue"
                value={tempValue}
                onChange={(e) => setTempValue(e.target.value)}
                placeholder={`Enter new ${fieldToEdit}`}
              />
            </div>

            <div>
              <Label htmlFor="otp">Enter OTP</Label>
              <Input
                id="otp"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                placeholder="Enter 6-digit OTP"
                maxLength={6}
              />
              <p className="text-xs text-zinc-500 mt-1">
                OTP sent to your registered {fieldToEdit === "email" ? "email" : "phone"}
              </p>
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => {
                  setShowOTPDialog(false);
                  setOtp("");
                  setFieldToEdit(null);
                }}
              >
                Cancel
              </Button>
              <Button
                className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                onClick={handleVerifyOTP}
              >
                Verify & Update
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

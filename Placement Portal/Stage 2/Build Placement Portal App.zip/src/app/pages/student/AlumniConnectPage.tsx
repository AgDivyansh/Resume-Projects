import { useState } from "react";
import { mockAlumni } from "../../services/mockData";
import { Card } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Badge } from "../../components/ui/badge";
import { Search, MessageCircle, Star, CheckCircle, Clock, Phone } from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner";

export function AlumniConnectPage() {
  const [search, setSearch] = useState("");

  const filteredAlumni = mockAlumni.filter(
    (alumni) =>
      alumni.name.toLowerCase().includes(search.toLowerCase()) ||
      alumni.company.toLowerCase().includes(search.toLowerCase())
  );

  const sortedAlumni = [...filteredAlumni].sort((a, b) => b.rating - a.rating);

  return (
    <div className="p-4 sm:p-6 space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-zinc-900 dark:text-white mb-2">
          Alumni Connect
        </h1>
        <p className="text-sm sm:text-base text-zinc-600 dark:text-zinc-400">
          Get guidance from seniors who made it
        </p>
      </div>

      {/* Search */}
      <Card className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
          <Input
            placeholder="Search by name or company..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
      </Card>

      {/* Alumni Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {sortedAlumni.map((alumni, index) => (
          <motion.div
            key={alumni.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <Card className="p-6 hover:shadow-lg transition-all">
              <div className="text-center mb-4">
                <div className="w-20 h-20 mx-auto mb-3 rounded-full bg-gradient-to-br from-blue-500 to-violet-500 flex items-center justify-center text-4xl">
                  {alumni.avatar}
                </div>
                <h3 className="text-lg font-bold text-zinc-900 dark:text-white">
                  {alumni.name}
                </h3>
                <p className="text-sm text-zinc-600 dark:text-zinc-400">
                  Class of {alumni.year}
                </p>
              </div>

              <div className="space-y-3 mb-4">
                <div className="p-3 bg-zinc-50 dark:bg-zinc-900 rounded-lg">
                  <p className="text-xs text-zinc-500 mb-1">Company</p>
                  <p className="font-semibold text-zinc-900 dark:text-white">
                    {alumni.company}
                  </p>
                </div>
                <div className="p-3 bg-zinc-50 dark:bg-zinc-900 rounded-lg">
                  <p className="text-xs text-zinc-500 mb-1">Role</p>
                  <p className="font-semibold text-zinc-900 dark:text-white">
                    {alumni.role}
                  </p>
                </div>
                <div className="p-3 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20 rounded-lg">
                  <p className="text-xs text-zinc-500 mb-1">Package</p>
                  <p className="text-lg font-bold text-green-600">
                    {alumni.package}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-1 text-yellow-500">
                  <Star className="w-4 h-4 fill-current" />
                  <span className="text-sm font-semibold text-zinc-900 dark:text-white">
                    {alumni.rating}
                  </span>
                </div>
                {alumni.available ? (
                  <Badge className="bg-green-500 text-white border-none">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Available
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-zinc-500 border-zinc-300">
                    <Clock className="w-3 h-3 mr-1" />
                    Busy
                  </Badge>
                )}
              </div>

              <div className="space-y-2">
                <Button
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  onClick={() => {
                    toast.success(`Message sent to ${alumni.name}!`);
                  }}
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Send Message
                </Button>

                <Button
                  variant="outline"
                  className="w-full"
                  disabled={!alumni.available}
                  onClick={() => {
                    if (alumni.available) {
                      toast.success(`Call request sent to ${alumni.name}!`);
                    }
                  }}
                >
                  <Phone className="w-4 h-4 mr-2" />
                  {alumni.available ? "Request Call" : "Call Unavailable"}
                </Button>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      {sortedAlumni.length === 0 && (
        <Card className="p-12 text-center">
          <p className="text-zinc-500">No alumni found</p>
        </Card>
      )}

      {/* Info Card */}
      <Card className="p-6 bg-gradient-to-br from-blue-50 to-violet-50 dark:from-blue-950/20 dark:to-violet-950/20">
        <h3 className="font-semibold text-zinc-900 dark:text-white mb-2">
          How it works
        </h3>
        <ul className="space-y-2 text-sm text-zinc-600 dark:text-zinc-400">
          <li className="flex items-start gap-2">
            <span className="text-blue-600">•</span>
            Alumni are sorted by rating (highest first)
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-600">•</span>
            <strong>Text messaging is available for all alumni</strong>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-600">•</span>
            Voice/video calls require approval - send a request first
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-600">•</span>
            Rate alumni after your conversation to help others
          </li>
        </ul>
      </Card>
    </div>
  );
}

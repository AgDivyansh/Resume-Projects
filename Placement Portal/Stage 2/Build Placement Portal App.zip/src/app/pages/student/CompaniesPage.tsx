import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { mockCompanies } from "../../services/mockData";
import { Card } from "../../components/ui/card";
import { Input } from "../../components/ui/input";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Search, TrendingUp, Users, ArrowRight } from "lucide-react";
import { motion } from "motion/react";

export function CompaniesPage() {
  const [search, setSearch] = useState("");
  const navigate = useNavigate();

  const filteredCompanies = mockCompanies.filter((company) =>
    company.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4 sm:p-6 space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-zinc-900 dark:text-white mb-2">
          Companies
        </h1>
        <p className="text-sm sm:text-base text-zinc-600 dark:text-zinc-400">
          Explore companies and their hiring patterns
        </p>
      </div>

      {/* Search */}
      <Card className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
          <Input
            placeholder="Search companies..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
      </Card>

      {/* Companies Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
        {filteredCompanies.map((company, index) => (
          <motion.div
            key={company.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card
              className="p-6 hover:shadow-lg transition-all cursor-pointer"
              onClick={() => navigate(`/student/companies/${company.id}`)}
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="text-5xl">{company.logo}</div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-zinc-900 dark:text-white mb-1">
                    {company.name}
                  </h3>
                  <Badge variant="secondary">{company.industry}</Badge>
                </div>
              </div>

              <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4 line-clamp-2">
                {company.description}
              </p>

              {/* Hiring Stats */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="p-3 bg-zinc-50 dark:bg-zinc-900 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <TrendingUp className="w-4 h-4 text-blue-600" />
                    <span className="text-xs text-zinc-500">Avg Package</span>
                  </div>
                  <p className="text-lg font-bold text-zinc-900 dark:text-white">
                    {company.hiringHistory[0]?.avgPackage || "N/A"}
                  </p>
                </div>
                <div className="p-3 bg-zinc-50 dark:bg-zinc-900 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <Users className="w-4 h-4 text-green-600" />
                    <span className="text-xs text-zinc-500">Selected (2025)</span>
                  </div>
                  <p className="text-lg font-bold text-zinc-900 dark:text-white">
                    {company.hiringHistory[0]?.selected || 0}
                  </p>
                </div>
              </div>

              <Button
                variant="outline"
                className="w-full"
                onClick={(e) => {
                  e.stopPropagation();
                  navigate(`/student/companies/${company.id}`);
                }}
              >
                View Details <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Card>
          </motion.div>
        ))}
      </div>

      {filteredCompanies.length === 0 && (
        <Card className="p-12 text-center">
          <p className="text-zinc-500">No companies found</p>
        </Card>
      )}
    </div>
  );
}

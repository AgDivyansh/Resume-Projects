import { useParams, Link } from "react-router";
import { mockCompanies, mockReviews } from "../../services/mockData";
import { Card } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { ArrowLeft, Building2, TrendingUp, Users, Star } from "lucide-react";
import { motion } from "motion/react";

export function CompanyDetailPage() {
  const { id } = useParams();
  const company = mockCompanies.find((c) => c.id === id);

  if (!company) {
    return (
      <div className="p-6">
        <Card className="p-12 text-center">
          <p className="text-zinc-500">Company not found</p>
        </Card>
      </div>
    );
  }

  const companyReviews = mockReviews.filter((r) => r.company === company.name);

  return (
    <div className="p-6 space-y-6">
      <Link to="/student/companies">
        <Button variant="ghost" size="sm">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Companies
        </Button>
      </Link>

      {/* Company Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="p-8">
          <div className="flex items-start gap-6">
            <div className="text-7xl">{company.logo}</div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-zinc-900 dark:text-white mb-2">
                {company.name}
              </h1>
              <div className="flex items-center gap-3 mb-4">
                <Badge variant="secondary" className="text-base px-3 py-1">
                  <Building2 className="w-4 h-4 mr-2" />
                  {company.industry}
                </Badge>
              </div>
              <p className="text-zinc-600 dark:text-zinc-400 leading-relaxed">
                {company.description}
              </p>
            </div>
          </div>
        </Card>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Hiring History */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6">
            <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-4">
              Hiring History
            </h2>
            <div className="space-y-4">
              {company.hiringHistory.map((history) => (
                <div
                  key={history.year}
                  className="p-4 bg-zinc-50 dark:bg-zinc-900 rounded-lg"
                >
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-bold text-zinc-900 dark:text-white">
                      {history.year}
                    </h3>
                    <div className="flex gap-4">
                      <div className="text-right">
                        <p className="text-sm text-zinc-500">Avg Package</p>
                        <p className="font-semibold text-blue-600">
                          {history.avgPackage}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-zinc-500">Selected</p>
                        <p className="font-semibold text-green-600">
                          {history.selected}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {history.roles.map((role) => (
                      <Badge key={role} variant="outline">
                        {role}
                      </Badge>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Interview Experiences */}
          {companyReviews.length > 0 && (
            <Card className="p-6">
              <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-4">
                Interview Experiences
              </h2>
              <div className="space-y-4">
                {companyReviews.map((review) => (
                  <div
                    key={review.id}
                    className="p-4 bg-zinc-50 dark:bg-zinc-900 rounded-lg"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-semibold text-zinc-900 dark:text-white">
                          {review.studentName}
                        </p>
                        <p className="text-sm text-zinc-500">{review.role}</p>
                      </div>
                      <div className="flex items-center gap-1 text-yellow-500">
                        {Array.from({ length: review.rating }).map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-current" />
                        ))}
                      </div>
                    </div>
                    <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-2">
                      {review.experience}
                    </p>
                    <p className="text-xs text-zinc-500">{review.rounds}</p>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>

        {/* Stats Sidebar */}
        <div className="space-y-6">
          <Card className="p-6">
            <h3 className="font-semibold text-zinc-900 dark:text-white mb-4">
              Quick Stats
            </h3>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-950 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-zinc-500">Latest Avg Package</p>
                  <p className="font-bold text-zinc-900 dark:text-white">
                    {company.hiringHistory[0]?.avgPackage}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-green-100 dark:bg-green-950 flex items-center justify-center">
                  <Users className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-zinc-500">Total Selected</p>
                  <p className="font-bold text-zinc-900 dark:text-white">
                    {company.hiringHistory.reduce(
                      (sum, h) => sum + h.selected,
                      0
                    )}
                  </p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-blue-50 to-violet-50 dark:from-blue-950/20 dark:to-violet-950/20">
            <h3 className="font-semibold text-zinc-900 dark:text-white mb-2">
              Interested?
            </h3>
            <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4">
              Check out current openings from {company.name}
            </p>
            <Link to="/student/jobs">
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                View Jobs
              </Button>
            </Link>
          </Card>
        </div>
      </div>
    </div>
  );
}

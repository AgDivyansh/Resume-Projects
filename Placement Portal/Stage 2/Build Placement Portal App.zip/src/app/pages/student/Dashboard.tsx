import { useAuth } from "../../contexts/AuthContext";
import { mockJobs, mockApplications, checkEligibility } from "../../services/mockData";
import { Card } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Progress } from "../../components/ui/progress";
import { Link, useNavigate } from "react-router";
import {
  Briefcase,
  CheckCircle,
  Clock,
  TrendingUp,
  AlertCircle,
  ArrowRight,
} from "lucide-react";
import { motion } from "motion/react";

const statusColors = {
  applied: "bg-blue-500",
  oa: "bg-yellow-500",
  interview: "bg-purple-500",
  selected: "bg-green-500",
  rejected: "bg-red-500",
};

const statusLabels = {
  applied: "Applied",
  oa: "OA",
  interview: "Interview",
  selected: "Selected",
  rejected: "Rejected",
};

export function StudentDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const appliedJobs = mockApplications.map((app) => ({
    ...app,
    job: mockJobs.find((j) => j.id === app.jobId)!,
  }));

  // Calculate eligible jobs based on student criteria
  const eligibleJobs = mockJobs.filter((job) => {
    const result = checkEligibility(job, {
      tenth: user?.tenth,
      twelfth: user?.twelfth,
      cgpa: user?.cgpa,
    });
    return result.eligible;
  });

  const eligibleJobsCount = eligibleJobs.length;
  const upcomingDrivesCount = mockJobs.filter(
    (j) => new Date(j.deadline) > new Date()
  ).length;

  const missingFields = [];
  if (!user?.resume) missingFields.push("Resume");
  if (!user?.phone) missingFields.push("Phone");
  if (!user?.cgpa) missingFields.push("CGPA");

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  };

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Section */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold text-zinc-900 dark:text-white mb-2">
          Welcome back, {user?.name?.split(" ")[0]}! 👋
        </h1>
        <p className="text-zinc-600 dark:text-zinc-400">
          Here's what's happening with your placements
        </p>
      </motion.div>

      {/* Profile Completeness Alert */}
      {user?.profileComplete !== undefined && user.profileComplete < 100 && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="p-4 bg-gradient-to-r from-orange-50 to-amber-50 dark:from-orange-950/20 dark:to-amber-950/20 border-orange-200 dark:border-orange-900">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <h3 className="font-semibold text-orange-900 dark:text-orange-100 mb-1">
                  Complete your profile
                </h3>
                <p className="text-sm text-orange-700 dark:text-orange-300 mb-3">
                  Missing: {missingFields.join(", ")}
                </p>
                <Progress value={user.profileComplete} className="h-2 mb-2" />
                <div className="flex items-center justify-between">
                  <span className="text-sm text-orange-600">{user.profileComplete}%</span>
                  <Link to="/student/profile">
                    <Button size="sm" variant="outline">
                      Complete Profile
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      )}

      {/* Stats Grid */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
      >
        <motion.div variants={itemVariants}>
          <Link to="/student/jobs?filter=applied">
            <Card className="p-6 hover:shadow-lg transition-all cursor-pointer hover:scale-[1.02]">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-950 flex items-center justify-center">
                  <Briefcase className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
                <Badge variant="secondary">{appliedJobs.length} active</Badge>
              </div>
              <h3 className="text-2xl font-bold text-zinc-900 dark:text-white">
                {appliedJobs.length}
              </h3>
              <p className="text-sm text-zinc-600 dark:text-zinc-400">Applied Jobs</p>
              <p className="text-xs text-blue-600 dark:text-blue-400 mt-2">Click to view →</p>
            </Card>
          </Link>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Link to="/student/jobs?filter=eligible">
            <Card className="p-6 hover:shadow-lg transition-all cursor-pointer hover:scale-[1.02]">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-green-100 dark:bg-green-950 flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-600 dark:text-green-400" />
                </div>
                <Badge variant="secondary">{eligibleJobsCount} available</Badge>
              </div>
              <h3 className="text-2xl font-bold text-zinc-900 dark:text-white">
                {eligibleJobsCount}
              </h3>
              <p className="text-sm text-zinc-600 dark:text-zinc-400">Eligible Jobs</p>
              <p className="text-xs text-green-600 dark:text-green-400 mt-2">Click to view →</p>
            </Card>
          </Link>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Link to="/student/jobs?filter=upcoming">
            <Card className="p-6 hover:shadow-lg transition-all cursor-pointer hover:scale-[1.02]">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-violet-100 dark:bg-violet-950 flex items-center justify-center">
                  <Clock className="w-6 h-6 text-violet-600 dark:text-violet-400" />
                </div>
                <Badge variant="secondary">This month</Badge>
              </div>
              <h3 className="text-2xl font-bold text-zinc-900 dark:text-white">
                {upcomingDrivesCount}
              </h3>
              <p className="text-sm text-zinc-600 dark:text-zinc-400">Upcoming Drives</p>
              <p className="text-xs text-violet-600 dark:text-violet-400 mt-2">Click to view →</p>
            </Card>
          </Link>
        </motion.div>
      </motion.div>

      {/* Applied Jobs Section */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-zinc-900 dark:text-white">
            Your Applications
          </h2>
          <Link to="/student/jobs">
            <Button variant="ghost" size="sm">
              View All <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </Link>
        </div>

        <div className="space-y-3">
          {appliedJobs.map((app, index) => (
            <motion.div
              key={app.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Link to={`/student/jobs/${app.job.id}`}>
                <Card className="p-4 hover:shadow-md transition-all cursor-pointer">
                  <div className="flex items-center gap-4">
                    <div className="text-4xl">{app.job.logo}</div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-zinc-900 dark:text-white">
                          {app.job.company}
                        </h3>
                        <span className="text-sm text-zinc-500">·</span>
                        <span className="text-sm text-zinc-600 dark:text-zinc-400">
                          {app.job.role}
                        </span>
                      </div>
                      <p className="text-sm text-zinc-500">
                        Applied on {new Date(app.appliedDate).toLocaleDateString()}
                      </p>

                      {/* Status Timeline */}
                      <div className="flex items-center gap-2 mt-3">
                        {(["applied", "oa", "interview", "selected"] as const).map(
                          (status, idx) => {
                            const statuses = ["applied", "oa", "interview", "selected"];
                            const currentIndex = statuses.indexOf(app.status);
                            const isActive = idx <= currentIndex;
                            const isCurrent = idx === currentIndex;

                            return (
                              <div key={status} className="flex items-center">
                                <div
                                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium transition-all ${
                                    isActive
                                      ? `${statusColors[status]} text-white`
                                      : "bg-zinc-200 dark:bg-zinc-800 text-zinc-400"
                                  } ${isCurrent ? "ring-4 ring-blue-200 dark:ring-blue-900" : ""}`}
                                >
                                  {idx + 1}
                                </div>
                                {idx < 3 && (
                                  <div
                                    className={`w-12 h-1 ${
                                      isActive
                                        ? "bg-blue-500"
                                        : "bg-zinc-200 dark:bg-zinc-800"
                                    }`}
                                  />
                                )}
                              </div>
                            );
                          }
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge
                        className={`${statusColors[app.status]} text-white border-none`}
                      >
                        {statusLabels[app.status]}
                      </Badge>
                      <p className="text-sm font-semibold text-zinc-900 dark:text-white mt-2">
                        {app.job.package}
                      </p>
                    </div>
                  </div>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <Card className="p-6 bg-gradient-to-br from-blue-50 to-violet-50 dark:from-blue-950/20 dark:to-violet-950/20 border-blue-200 dark:border-blue-900">
          <div className="flex items-center gap-3 mb-4">
            <TrendingUp className="w-6 h-6 text-blue-600" />
            <h3 className="text-lg font-semibold text-zinc-900 dark:text-white">
              Recommended for You
            </h3>
          </div>
          <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-4">
            Based on your profile, we found {eligibleJobsCount} jobs that match your
            criteria
          </p>
          <Link to="/student/jobs">
            <Button className="bg-blue-600 hover:bg-blue-700">
              Explore Jobs <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </Card>
      </motion.div>
    </div>
  );
}

import { useParams, Link } from "react-router";
import { mockJobs, mockReviews, checkEligibility } from "../../services/mockData";
import { useAuth } from "../../contexts/AuthContext";
import { Card } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { Progress } from "../../components/ui/progress";
import {
  ArrowLeft,
  MapPin,
  Building2,
  Users,
  CheckCircle,
  Star,
  Clock,
  X,
} from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner";

export function JobDetailPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const job = mockJobs.find((j) => j.id === id);

  if (!job) {
    return (
      <div className="p-6">
        <Card className="p-12 text-center">
          <p className="text-zinc-500">Job not found</p>
        </Card>
      </div>
    );
  }

  const eligibility = checkEligibility(job, {
    tenth: user?.tenth,
    twelfth: user?.twelfth,
    cgpa: user?.cgpa,
  });

  const jobReviews = mockReviews.filter((r) => r.company === job.company);

  return (
    <div className="p-6 space-y-6">
      <Link to="/student/jobs">
        <Button variant="ghost" size="sm">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Jobs
        </Button>
      </Link>

      {/* Job Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="p-8">
          <div className="flex items-start gap-6">
            <div className="text-7xl">{job.logo}</div>
            <div className="flex-1">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-3xl font-bold text-zinc-900 dark:text-white mb-2">
                    {job.role}
                  </h1>
                  <p className="text-xl text-zinc-600 dark:text-zinc-400">
                    {job.company}
                  </p>
                </div>
                {eligibility.eligible ? (
                  <Badge className="bg-green-500 text-white border-none text-base px-4 py-2">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    You're Eligible
                  </Badge>
                ) : (
                  <Badge
                    variant="outline"
                    className="text-red-600 border-red-300 text-base px-4 py-2"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Not Eligible
                  </Badge>
                )}
              </div>

              <div className="flex flex-wrap gap-4 text-sm text-zinc-600 dark:text-zinc-400 mb-6">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  {job.location}
                </div>
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4" />
                  {job.industry}
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  {job.applicants} applicants
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Deadline: {new Date(job.deadline).toLocaleDateString()}
                </div>
              </div>

              <div className="flex items-center gap-4 mb-6">
                <div className="flex-1">
                  <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-2">
                    Selection Progress
                  </p>
                  <Progress
                    value={(job.selected / job.applicants) * 100}
                    className="h-2"
                  />
                  <p className="text-xs text-zinc-500 mt-1">
                    {job.selected} selected out of {job.applicants} applicants
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold text-zinc-900 dark:text-white">
                    {job.package}
                  </p>
                  <p className="text-sm text-zinc-500">Package</p>
                </div>
              </div>

              {!eligibility.eligible && (
                <div className="mb-6 p-4 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900 rounded-lg">
                  <p className="text-sm text-red-600 dark:text-red-400 font-medium">
                    {eligibility.reason}
                  </p>
                </div>
              )}

              <div className="flex gap-3">
                <Button
                  className="bg-blue-600 hover:bg-blue-700 px-8"
                  disabled={!eligibility.eligible}
                  onClick={() => {
                    if (eligibility.eligible) {
                      toast.success(`Applied to ${job.company}!`);
                    }
                  }}
                >
                  {eligibility.eligible ? "Apply Now" : "Cannot Apply"}
                </Button>
                <Link to={`/student/companies/${job.id}`}>
                  <Button variant="outline">View Company</Button>
                </Link>
              </div>
            </div>
          </div>
        </Card>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Job Description */}
          <Card className="p-6">
            <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-4">
              Job Description
            </h2>
            <p className="text-zinc-600 dark:text-zinc-400 leading-relaxed">
              {job.jd}
            </p>
          </Card>

          {/* Selection Process */}
          <Card className="p-6">
            <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-4">
              Selection Process
            </h2>
            <div className="space-y-3">
              {job.rounds.map((round, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-950 flex items-center justify-center text-blue-600 dark:text-blue-400 font-semibold">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-zinc-900 dark:text-white">{round}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Interview Experiences */}
          {jobReviews.length > 0 && (
            <Card className="p-6">
              <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-4">
                Interview Experiences
              </h2>
              <div className="space-y-4">
                {jobReviews.map((review) => (
                  <div key={review.id} className="p-4 bg-zinc-50 dark:bg-zinc-900 rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-semibold text-zinc-900 dark:text-white">
                          {review.studentName}
                        </p>
                        <p className="text-sm text-zinc-500">{review.role}</p>
                      </div>
                      <div className="flex items-center gap-1 text-yellow-500">
                        {Array.from({ length: review.rating }).map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-current" />
                        ))}
                      </div>
                    </div>
                    <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-2">
                      {review.experience}
                    </p>
                    <p className="text-xs text-zinc-500">{review.rounds}</p>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>

        {/* Right Column - Eligibility */}
        <div className="space-y-6">
          <Card className="p-6">
            <h2 className="text-lg font-bold text-zinc-900 dark:text-white mb-4">
              Eligibility Criteria
            </h2>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-zinc-600 dark:text-zinc-400">
                  10th Percentage
                </span>
                <span className="font-semibold text-zinc-900 dark:text-white">
                  ≥ {job.eligibility.tenth}%
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-zinc-600 dark:text-zinc-400">
                  12th Percentage
                </span>
                <span className="font-semibold text-zinc-900 dark:text-white">
                  ≥ {job.eligibility.twelfth}%
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-zinc-600 dark:text-zinc-400">CGPA</span>
                <span className="font-semibold text-zinc-900 dark:text-white">
                  ≥ {job.eligibility.cgpa}
                </span>
              </div>
              <div>
                <span className="text-sm text-zinc-600 dark:text-zinc-400 block mb-2">
                  Eligible Branches
                </span>
                <div className="flex flex-wrap gap-2">
                  {job.eligibility.branches.map((branch) => (
                    <Badge key={branch} variant="secondary">
                      {branch}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-blue-50 to-violet-50 dark:from-blue-950/20 dark:to-violet-950/20">
            <h3 className="font-semibold text-zinc-900 dark:text-white mb-2">
              Your Profile
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-zinc-600 dark:text-zinc-400">10th</span>
                <span className="font-medium text-zinc-900 dark:text-white">
                  {user?.tenth}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-600 dark:text-zinc-400">12th</span>
                <span className="font-medium text-zinc-900 dark:text-white">
                  {user?.twelfth}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-600 dark:text-zinc-400">CGPA</span>
                <span className="font-medium text-zinc-900 dark:text-white">
                  {user?.cgpa}
                </span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

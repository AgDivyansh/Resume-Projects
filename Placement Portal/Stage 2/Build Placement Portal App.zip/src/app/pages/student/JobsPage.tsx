import { useState, useEffect } from "react";
import { Link, useSearchParams, useNavigate } from "react-router";
import { mockJobs, mockApplications, checkEligibility } from "../../services/mockData";
import { useAuth } from "../../contexts/AuthContext";
import { Card } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { Input } from "../../components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../components/ui/select";
import { Search, MapPin, Building2, Clock, Users, CheckCircle, X } from "lucide-react";
import { motion } from "motion/react";
import { toast } from "sonner";

export function JobsPage() {
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [industryFilter, setIndustryFilter] = useState("all");
  const [locationFilter, setLocationFilter] = useState("all");

  const filter = searchParams.get("filter");

  // Apply dashboard filter
  let baseJobs = mockJobs;

  if (filter === "applied") {
    const appliedJobIds = mockApplications.map((app) => app.jobId);
    baseJobs = mockJobs.filter((job) => appliedJobIds.includes(job.id));
  } else if (filter === "eligible") {
    baseJobs = mockJobs.filter((job) => {
      const result = checkEligibility(job, {
        tenth: user?.tenth,
        twelfth: user?.twelfth,
        cgpa: user?.cgpa,
      });
      return result.eligible;
    });
  } else if (filter === "upcoming") {
    baseJobs = mockJobs.filter((job) => new Date(job.deadline) > new Date());
  }

  const filteredJobs = baseJobs.filter((job) => {
    const matchesSearch =
      job.company.toLowerCase().includes(search.toLowerCase()) ||
      job.role.toLowerCase().includes(search.toLowerCase());
    const matchesIndustry =
      industryFilter === "all" || job.industry === industryFilter;
    const matchesLocation =
      locationFilter === "all" || job.location.includes(locationFilter);

    return matchesSearch && matchesIndustry && matchesLocation;
  });

  const industries = Array.from(new Set(mockJobs.map((j) => j.industry)));
  const locations = Array.from(
    new Set(mockJobs.flatMap((j) => j.location.split(", ")))
  );

  const eligibleJobs = filteredJobs.map((job) => ({
    job,
    eligibility: checkEligibility(job, {
      tenth: user?.tenth,
      twelfth: user?.twelfth,
      cgpa: user?.cgpa,
    }),
  }));

  const sortedJobs = eligibleJobs.sort((a, b) => {
    if (a.eligibility.eligible && !b.eligibility.eligible) return -1;
    if (!a.eligibility.eligible && b.eligibility.eligible) return 1;
    return 0;
  });

  const getPageTitle = () => {
    if (filter === "applied") return "Applied Jobs";
    if (filter === "eligible") return "Eligible Jobs";
    if (filter === "upcoming") return "Upcoming Jobs";
    return "Browse Jobs";
  };

  const getPageSubtitle = () => {
    if (filter === "applied") return `You have applied to ${sortedJobs.length} jobs`;
    if (filter === "eligible")
      return `${sortedJobs.length} jobs match your eligibility criteria`;
    if (filter === "upcoming")
      return `${sortedJobs.length} jobs with upcoming deadlines`;
    return `${sortedJobs.filter((j) => j.eligibility.eligible).length} jobs match your profile`;
  };

  return (
    <div className="p-4 sm:p-6 space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-zinc-900 dark:text-white mb-2">
          {getPageTitle()}
        </h1>
        <p className="text-sm sm:text-base text-zinc-600 dark:text-zinc-400">
          {getPageSubtitle()}
        </p>
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
              <Input
                placeholder="Search by company or role..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <Select value={industryFilter} onValueChange={setIndustryFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Industry" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Industries</SelectItem>
              {industries.map((industry) => (
                <SelectItem key={industry} value={industry}>
                  {industry}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={locationFilter} onValueChange={setLocationFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Location" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Locations</SelectItem>
              {locations.map((location) => (
                <SelectItem key={location} value={location}>
                  {location}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Jobs Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {sortedJobs.map(({ job, eligibility }, index) => (
          <motion.div
            key={job.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <Card
              className={`p-6 hover:shadow-lg transition-all cursor-pointer ${
                !eligibility.eligible ? "opacity-60" : ""
              }`}
              onClick={() => navigate(`/student/jobs/${job.id}`)}
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="text-5xl">{job.logo}</div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="text-xl font-bold text-zinc-900 dark:text-white">
                        {job.company}
                      </h3>
                      <p className="text-zinc-600 dark:text-zinc-400">{job.role}</p>
                    </div>
                    {eligibility.eligible ? (
                      <Badge className="bg-green-500 text-white border-none">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Eligible
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-red-600 border-red-300">
                        <X className="w-3 h-3 mr-1" />
                        Not Eligible
                      </Badge>
                    )}
                  </div>

                  <div className="flex flex-wrap gap-3 text-sm text-zinc-600 dark:text-zinc-400 mb-4">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {job.location}
                    </div>
                    <div className="flex items-center gap-1">
                      <Building2 className="w-4 h-4" />
                      {job.industry}
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      {job.applicants} applied
                    </div>
                  </div>

                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="text-2xl font-bold text-zinc-900 dark:text-white">
                        {job.package}
                      </p>
                      <p className="text-xs text-zinc-500">Package</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-zinc-900 dark:text-white">
                        Deadline
                      </p>
                      <p className="text-xs text-zinc-500 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(job.deadline).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  {!eligibility.eligible && (
                    <div className="mb-4 p-3 bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900 rounded-lg">
                      <p className="text-sm text-red-600 dark:text-red-400">
                        {eligibility.reason}
                      </p>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/student/jobs/${job.id}`);
                      }}
                    >
                      View Details
                    </Button>
                    <Button
                      className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-zinc-300 dark:disabled:bg-zinc-700 disabled:cursor-not-allowed"
                      disabled={!eligibility.eligible}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (eligibility.eligible) {
                          toast.success(`Applied to ${job.company}!`);
                        }
                      }}
                    >
                      {eligibility.eligible ? "Apply Now" : "Cannot Apply"}
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      {sortedJobs.length === 0 && (
        <Card className="p-12 text-center">
          <p className="text-zinc-500">No jobs found matching your filters</p>
        </Card>
      )}
    </div>
  );
}

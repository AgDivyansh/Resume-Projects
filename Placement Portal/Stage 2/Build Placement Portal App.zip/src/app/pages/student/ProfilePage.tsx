import { useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { Card } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Progress } from "../../components/ui/progress";
import { User, Mail, Phone, FileText, Award, Upload } from "lucide-react";
import { toast } from "sonner";

export function ProfilePage() {
  const { user } = useAuth();
  const [editing, setEditing] = useState(false);

  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    phone: user?.phone || "",
    rollNo: user?.rollNo || "",
    tenth: user?.tenth || 0,
    twelfth: user?.twelfth || 0,
    cgpa: user?.cgpa || 0,
    resume: user?.resume || "",
  });

  const handleSave = () => {
    toast.success("Profile updated successfully!");
    setEditing(false);
  };

  const profileFields = [
    { key: "name", label: "Name", filled: !!formData.name },
    { key: "email", label: "Email", filled: !!formData.email },
    { key: "phone", label: "Phone", filled: !!formData.phone },
    { key: "rollNo", label: "Roll No", filled: !!formData.rollNo },
    { key: "tenth", label: "10th %", filled: formData.tenth > 0 },
    { key: "twelfth", label: "12th %", filled: formData.twelfth > 0 },
    { key: "cgpa", label: "CGPA", filled: formData.cgpa > 0 },
    { key: "resume", label: "Resume", filled: !!formData.resume },
  ];

  const filledCount = profileFields.filter((f) => f.filled).length;
  const completeness = Math.round((filledCount / profileFields.length) * 100);

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-zinc-900 dark:text-white mb-2">
          My Profile
        </h1>
        <p className="text-zinc-600 dark:text-zinc-400">
          Manage your profile information
        </p>
      </div>

      {/* Profile Completeness */}
      <Card className="p-6 bg-gradient-to-br from-blue-50 to-violet-50 dark:from-blue-950/20 dark:to-violet-950/20">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-zinc-900 dark:text-white">
            Profile Completeness
          </h3>
          <span className="text-2xl font-bold text-blue-600">{completeness}%</span>
        </div>
        <Progress value={completeness} className="h-2 mb-2" />
        <p className="text-sm text-zinc-600 dark:text-zinc-400">
          {filledCount} of {profileFields.length} fields completed
        </p>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Form */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-zinc-900 dark:text-white">
                Personal Information
              </h2>
              <Button
                variant={editing ? "outline" : "default"}
                onClick={() => (editing ? handleSave() : setEditing(true))}
              >
                {editing ? "Save Changes" : "Edit Profile"}
              </Button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    disabled={!editing}
                  />
                </div>
                <div>
                  <Label htmlFor="rollNo">Roll Number</Label>
                  <Input
                    id="rollNo"
                    value={formData.rollNo}
                    onChange={(e) =>
                      setFormData({ ...formData, rollNo: e.target.value })
                    }
                    disabled={!editing}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="email">College Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) =>
                    setFormData({ ...formData, email: e.target.value })
                  }
                  disabled={!editing}
                />
              </div>

              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) =>
                    setFormData({ ...formData, phone: e.target.value })
                  }
                  disabled={!editing}
                />
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-6">
              Academic Information
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="tenth">10th Percentage</Label>
                <Input
                  id="tenth"
                  type="number"
                  value={formData.tenth}
                  onChange={(e) =>
                    setFormData({ ...formData, tenth: parseFloat(e.target.value) })
                  }
                  disabled={!editing}
                />
              </div>
              <div>
                <Label htmlFor="twelfth">12th Percentage</Label>
                <Input
                  id="twelfth"
                  type="number"
                  value={formData.twelfth}
                  onChange={(e) =>
                    setFormData({ ...formData, twelfth: parseFloat(e.target.value) })
                  }
                  disabled={!editing}
                />
              </div>
              <div>
                <Label htmlFor="cgpa">CGPA</Label>
                <Input
                  id="cgpa"
                  type="number"
                  step="0.01"
                  value={formData.cgpa}
                  onChange={(e) =>
                    setFormData({ ...formData, cgpa: parseFloat(e.target.value) })
                  }
                  disabled={!editing}
                />
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-bold text-zinc-900 dark:text-white mb-6">
              Resume
            </h2>

            {formData.resume ? (
              <div className="flex items-center justify-between p-4 bg-zinc-50 dark:bg-zinc-900 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-950 flex items-center justify-center">
                    <FileText className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium text-zinc-900 dark:text-white">
                      {formData.resume}
                    </p>
                    <p className="text-xs text-zinc-500">Uploaded</p>
                  </div>
                </div>
                {editing && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      toast.success("Resume upload simulated");
                    }}
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Replace
                  </Button>
                )}
              </div>
            ) : (
              <div className="border-2 border-dashed border-zinc-300 dark:border-zinc-700 rounded-lg p-8 text-center">
                <Upload className="w-8 h-8 mx-auto mb-3 text-zinc-400" />
                <p className="text-sm text-zinc-600 dark:text-zinc-400 mb-3">
                  Upload your resume (PDF, DOC, DOCX)
                </p>
                <Button
                  variant="outline"
                  disabled={!editing}
                  onClick={() => {
                    setFormData({ ...formData, resume: "resume_upload.pdf" });
                    toast.success("Resume uploaded successfully!");
                  }}
                >
                  Choose File
                </Button>
              </div>
            )}
          </Card>
        </div>

        {/* Profile Summary Sidebar */}
        <div className="space-y-6">
          <Card className="p-6">
            <div className="text-center mb-6">
              <div className="w-24 h-24 mx-auto mb-3 rounded-full bg-gradient-to-br from-blue-500 to-violet-500 flex items-center justify-center text-white text-3xl font-bold">
                {formData.name.charAt(0)}
              </div>
              <h3 className="text-lg font-bold text-zinc-900 dark:text-white">
                {formData.name}
              </h3>
              <p className="text-sm text-zinc-500">{formData.rollNo}</p>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm">
                <Mail className="w-4 h-4 text-zinc-400" />
                <span className="text-zinc-600 dark:text-zinc-400">
                  {formData.email}
                </span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <Phone className="w-4 h-4 text-zinc-400" />
                <span className="text-zinc-600 dark:text-zinc-400">
                  {formData.phone || "Not provided"}
                </span>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="font-semibold text-zinc-900 dark:text-white mb-4 flex items-center gap-2">
              <Award className="w-5 h-5 text-blue-600" />
              Academic Stats
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-zinc-600 dark:text-zinc-400">10th</span>
                <span className="font-semibold text-zinc-900 dark:text-white">
                  {formData.tenth}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-zinc-600 dark:text-zinc-400">12th</span>
                <span className="font-semibold text-zinc-900 dark:text-white">
                  {formData.twelfth}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-zinc-600 dark:text-zinc-400">CGPA</span>
                <span className="font-semibold text-zinc-900 dark:text-white">
                  {formData.cgpa}
                </span>
              </div>
            </div>
          </Card>

          {completeness < 100 && (
            <Card className="p-6 bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-950/20 dark:to-amber-950/20">
              <h3 className="font-semibold text-orange-900 dark:text-orange-100 mb-2">
                Complete Your Profile
              </h3>
              <p className="text-sm text-orange-700 dark:text-orange-300 mb-3">
                A complete profile increases your chances of getting selected
              </p>
              <ul className="text-xs space-y-1 text-orange-600">
                {profileFields
                  .filter((f) => !f.filled)
                  .map((f) => (
                    <li key={f.key}>• {f.label} is missing</li>
                  ))}
              </ul>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

import { createBrowserRouter } from "react-router";
import { RootLayout } from "./layouts/RootLayout";
import { StudentLayout } from "./layouts/StudentLayout";
import { AdminLayout } from "./layouts/AdminLayout";

// Auth Pages
import { LoginPage } from "./pages/auth/LoginPage";

// Student Pages
import { StudentDashboard } from "./pages/student/Dashboard";
import { JobsPage } from "./pages/student/JobsPage";
import { JobDetailPage } from "./pages/student/JobDetailPage";
import { CompaniesPage } from "./pages/student/CompaniesPage";
import { CompanyDetailPage } from "./pages/student/CompanyDetailPage";
import { AlumniConnectPage } from "./pages/student/AlumniConnectPage";
import { ProfilePage } from "./pages/student/ProfilePage";

// Admin Pages
import { AdminDashboard } from "./pages/admin/Dashboard";
import { ManageJobsPage } from "./pages/admin/ManageJobsPage";
import { AnalyticsPage } from "./pages/admin/AnalyticsPage";
import { AdminProfilePage } from "./pages/admin/ProfilePage";

// 404
import { NotFound } from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: RootLayout,
    children: [
      { index: true, Component: LoginPage },
      { path: "login", Component: LoginPage },

      // Student Routes
      {
        path: "student",
        Component: StudentLayout,
        children: [
          { index: true, Component: StudentDashboard },
          { path: "dashboard", Component: StudentDashboard },
          { path: "jobs", Component: JobsPage },
          { path: "jobs/:id", Component: JobDetailPage },
          { path: "companies", Component: CompaniesPage },
          { path: "companies/:id", Component: CompanyDetailPage },
          { path: "alumni", Component: AlumniConnectPage },
          { path: "profile", Component: ProfilePage },
        ],
      },

      // Admin Routes
      {
        path: "admin",
        Component: AdminLayout,
        children: [
          { index: true, Component: AdminDashboard },
          { path: "dashboard", Component: AdminDashboard },
          { path: "jobs", Component: ManageJobsPage },
          { path: "analytics", Component: AnalyticsPage },
          { path: "profile", Component: AdminProfilePage },
        ],
      },

      { path: "*", Component: NotFound },
    ],
  },
]);

export interface Job {
  id: string;
  company: string;
  logo: string;
  role: string;
  package: string;
  location: string;
  industry: string;
  jd: string;
  eligibility: {
    tenth: number;
    twelfth: number;
    cgpa: number;
    branches: string[];
  };
  rounds: string[];
  posted: string;
  deadline: string;
  applicants: number;
  selected: number;
}

export interface Application {
  id: string;
  jobId: string;
  status: "applied" | "oa" | "interview" | "selected" | "rejected";
  appliedDate: string;
}

export interface Company {
  id: string;
  name: string;
  logo: string;
  industry: string;
  description: string;
  hiringHistory: {
    year: number;
    roles: string[];
    avgPackage: string;
    selected: number;
  }[];
}

export interface Alumni {
  id: string;
  name: string;
  company: string;
  role: string;
  package: string;
  year: number;
  rating: number;
  avatar: string;
  available: boolean;
}

export interface Review {
  id: string;
  studentName: string;
  company: string;
  role: string;
  rating: number;
  experience: string;
  rounds: string;
  date: string;
}

export const mockJobs: Job[] = [
  {
    id: "1",
    company: "Google",
    logo: "🔍",
    role: "Software Engineer",
    package: "₹42 LPA",
    location: "Bangalore",
    industry: "Technology",
    jd: "We are looking for talented software engineers to join our team. You will work on cutting-edge technologies and solve complex problems at scale.",
    eligibility: { tenth: 75, twelfth: 75, cgpa: 7.5, branches: ["CSE", "IT", "ECE"] },
    rounds: ["Online Assessment", "Technical Round 1", "Technical Round 2", "HR Round"],
    posted: "2026-04-15",
    deadline: "2026-05-01",
    applicants: 342,
    selected: 8,
  },
  {
    id: "2",
    company: "Microsoft",
    logo: "Ⓜ️",
    role: "SDE Intern",
    package: "₹1.2L/month",
    location: "Hyderabad",
    industry: "Technology",
    jd: "Summer internship opportunity for aspiring software developers. Work on real-world projects and learn from the best.",
    eligibility: { tenth: 70, twelfth: 70, cgpa: 7.0, branches: ["CSE", "IT"] },
    rounds: ["Coding Test", "Technical Interview", "Manager Round"],
    posted: "2026-04-18",
    deadline: "2026-04-30",
    applicants: 287,
    selected: 12,
  },
  {
    id: "3",
    company: "Amazon",
    logo: "📦",
    role: "Frontend Developer",
    package: "₹28 LPA",
    location: "Bangalore, Mumbai",
    industry: "E-commerce",
    jd: "Build next-gen web applications for millions of users. Work with React, TypeScript, and modern web technologies.",
    eligibility: { tenth: 70, twelfth: 70, cgpa: 7.0, branches: ["CSE", "IT", "ECE"] },
    rounds: ["Online Test", "Technical Round", "Bar Raiser", "HR"],
    posted: "2026-04-10",
    deadline: "2026-04-28",
    applicants: 425,
    selected: 15,
  },
  {
    id: "4",
    company: "Goldman Sachs",
    logo: "💼",
    role: "Analyst - Technology",
    package: "₹35 LPA",
    location: "Bangalore",
    industry: "Finance",
    jd: "Work on cutting-edge financial technology solutions. High-performance systems and distributed computing.",
    eligibility: { tenth: 95, twelfth: 95, cgpa: 9.0, branches: ["CSE", "IT"] },
    rounds: ["Aptitude Test", "Technical Round 1", "Technical Round 2", "HR"],
    posted: "2026-04-12",
    deadline: "2026-04-25",
    applicants: 198,
    selected: 6,
  },
  {
    id: "5",
    company: "Flipkart",
    logo: "🛒",
    role: "SDE-1",
    package: "₹24 LPA",
    location: "Bangalore",
    industry: "E-commerce",
    jd: "Join India's leading e-commerce platform. Build scalable microservices and work on high-traffic applications.",
    eligibility: { tenth: 65, twelfth: 65, cgpa: 6.5, branches: ["CSE", "IT", "ECE", "EEE"] },
    rounds: ["Online Coding", "Technical Round 1", "Technical Round 2", "HR"],
    posted: "2026-04-20",
    deadline: "2026-05-05",
    applicants: 512,
    selected: 20,
  },
  {
    id: "6",
    company: "Adobe",
    logo: "🎨",
    role: "Software Engineer",
    package: "₹32 LPA",
    location: "Noida",
    industry: "Technology",
    jd: "Join the creative cloud team. Build products used by millions of creative professionals worldwide.",
    eligibility: { tenth: 80, twelfth: 80, cgpa: 8.0, branches: ["CSE", "IT"] },
    rounds: ["Online Assessment", "Technical Round 1", "Technical Round 2", "Hiring Manager"],
    posted: "2026-04-14",
    deadline: "2026-04-29",
    applicants: 267,
    selected: 10,
  },
  {
    id: "7",
    company: "Uber",
    logo: "🚗",
    role: "Backend Engineer",
    package: "₹30 LPA",
    location: "Bangalore",
    industry: "Technology",
    jd: "Build highly scalable backend systems. Work with Go, Java, and distributed systems.",
    eligibility: { tenth: 60, twelfth: 60, cgpa: 6.0, branches: ["CSE", "IT", "ECE"] },
    rounds: ["Coding Challenge", "System Design", "Technical Interview", "HR"],
    posted: "2026-04-16",
    deadline: "2026-05-03",
    applicants: 389,
    selected: 14,
  },
  {
    id: "8",
    company: "Atlassian",
    logo: "⚡",
    role: "Full Stack Developer",
    package: "₹26 LPA",
    location: "Bangalore",
    industry: "Technology",
    jd: "Work on Jira, Confluence, and other collaboration tools. Full-stack development with modern frameworks.",
    eligibility: { tenth: 75, twelfth: 75, cgpa: 7.5, branches: ["CSE", "IT"] },
    rounds: ["Online Test", "Technical Round 1", "Technical Round 2", "Cultural Fit"],
    posted: "2026-04-19",
    deadline: "2026-05-06",
    applicants: 298,
    selected: 11,
  },
  {
    id: "9",
    company: "Salesforce",
    logo: "☁️",
    role: "Cloud Engineer",
    package: "₹38 LPA",
    location: "Hyderabad",
    industry: "Technology",
    jd: "Build cloud-native applications. Work with AWS, Kubernetes, and microservices architecture.",
    eligibility: { tenth: 85, twelfth: 85, cgpa: 8.5, branches: ["CSE", "IT", "ECE"] },
    rounds: ["Technical Assessment", "System Design", "Coding Interview", "Behavioral"],
    posted: "2026-04-13",
    deadline: "2026-04-27",
    applicants: 234,
    selected: 7,
  },
  {
    id: "10",
    company: "Netflix",
    logo: "🎬",
    role: "Software Engineer",
    package: "₹50 LPA",
    location: "Mumbai",
    industry: "Entertainment",
    jd: "Build streaming infrastructure at massive scale. Work on video encoding, CDN, and recommendation systems.",
    eligibility: { tenth: 90, twelfth: 90, cgpa: 9.2, branches: ["CSE"] },
    rounds: ["Online Assessment", "System Design", "Technical Round 1", "Technical Round 2", "Bar Raiser"],
    posted: "2026-04-11",
    deadline: "2026-04-26",
    applicants: 156,
    selected: 3,
  },
];

export const mockApplications: Application[] = [
  { id: "1", jobId: "1", status: "interview", appliedDate: "2026-04-16" },
  { id: "2", jobId: "2", status: "oa", appliedDate: "2026-04-19" },
  { id: "3", jobId: "3", status: "applied", appliedDate: "2026-04-11" },
];

export const mockCompanies: Company[] = [
  {
    id: "1",
    name: "Google",
    logo: "🔍",
    industry: "Technology",
    description: "Google LLC is an American multinational technology company...",
    hiringHistory: [
      { year: 2025, roles: ["SDE", "SDE Intern"], avgPackage: "₹40L", selected: 12 },
      { year: 2024, roles: ["SDE", "Research Intern"], avgPackage: "₹38L", selected: 10 },
    ],
  },
  {
    id: "2",
    name: "Microsoft",
    logo: "Ⓜ️",
    industry: "Technology",
    description: "Microsoft Corporation is an American multinational technology corporation...",
    hiringHistory: [
      { year: 2025, roles: ["SDE Intern"], avgPackage: "₹1.2L/mo", selected: 15 },
      { year: 2024, roles: ["SDE", "SDE Intern"], avgPackage: "₹32L", selected: 18 },
    ],
  },
];

export const mockAlumni: Alumni[] = [
  {
    id: "1",
    name: "Rahul Sharma",
    company: "Google",
    role: "SDE-2",
    package: "₹52 LPA",
    year: 2023,
    rating: 4.8,
    avatar: "👨‍💼",
    available: true,
  },
  {
    id: "2",
    name: "Priya Singh",
    company: "Microsoft",
    role: "SDE-1",
    package: "₹35 LPA",
    year: 2024,
    rating: 4.9,
    avatar: "👩‍💼",
    available: true,
  },
  {
    id: "3",
    name: "Amit Patel",
    company: "Amazon",
    role: "Frontend Engineer",
    package: "₹30 LPA",
    year: 2023,
    rating: 4.7,
    avatar: "👨‍💻",
    available: false,
  },
  {
    id: "4",
    name: "Sneha Reddy",
    company: "Goldman Sachs",
    role: "Technology Analyst",
    package: "₹38 LPA",
    year: 2024,
    rating: 4.6,
    avatar: "👩‍💻",
    available: true,
  },
];

export const mockReviews: Review[] = [
  {
    id: "1",
    studentName: "Karan Mehta",
    company: "Google",
    role: "SDE",
    rating: 5,
    experience: "Great interview experience. Focus on DSA and system design...",
    rounds: "OA had 2 coding questions. Technical rounds focused on problem solving.",
    date: "2026-03-15",
  },
  {
    id: "2",
    studentName: "Anjali Gupta",
    company: "Microsoft",
    role: "SDE Intern",
    rating: 4,
    experience: "Very collaborative environment. Interviewers were friendly...",
    rounds: "Coding test followed by 2 technical interviews.",
    date: "2026-03-20",
  },
];

export const mockAnalytics = {
  totalApplications: 1247,
  totalJobs: 28,
  selectionRate: 12.4,
  avgPackage: "₹28.5 LPA",
  branchWise: [
    { branch: "CSE", applications: 542, selected: 78 },
    { branch: "IT", applications: 398, selected: 52 },
    { branch: "ECE", applications: 187, selected: 18 },
    { branch: "EEE", applications: 120, selected: 8 },
  ],
  companyTrends: [
    { company: "Google", applicants: 342, selected: 8 },
    { company: "Microsoft", applicants: 287, selected: 12 },
    { company: "Amazon", applicants: 425, selected: 15 },
    { company: "Goldman Sachs", applicants: 198, selected: 6 },
  ],
  monthlyTrends: [
    { month: "Jan", applications: 145, selections: 18 },
    { month: "Feb", applications: 234, selections: 28 },
    { month: "Mar", applications: 312, selections: 42 },
    { month: "Apr", applications: 556, selections: 68 },
  ],
};

// Eligibility checker
export function checkEligibility(
  job: Job,
  student: { tenth?: number; twelfth?: number; cgpa?: number; branch?: string }
): { eligible: boolean; reason?: string } {
  if (!student.tenth || student.tenth < job.eligibility.tenth) {
    return { eligible: false, reason: `10th percentage must be ≥ ${job.eligibility.tenth}%` };
  }
  if (!student.twelfth || student.twelfth < job.eligibility.twelfth) {
    return { eligible: false, reason: `12th percentage must be ≥ ${job.eligibility.twelfth}%` };
  }
  if (!student.cgpa || student.cgpa < job.eligibility.cgpa) {
    return { eligible: false, reason: `CGPA must be ≥ ${job.eligibility.cgpa}` };
  }
  // Assuming CSE branch for demo student
  const branch = student.branch || "CSE";
  if (!job.eligibility.branches.includes(branch)) {
    return {
      eligible: false,
      reason: `Branch must be one of: ${job.eligibility.branches.join(", ")}`,
    };
  }
  return { eligible: true };
}
